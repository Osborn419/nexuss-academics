/**
 * Build a complete single-file offline version from the current PostgreSQL data.
 * Run: npm run build:offline
 */
import fs from "node:fs";
import path from "node:path";
import { Client } from "pg";
import { renderMarkdown } from "../src/lib/markdown.ts";

const root = path.resolve(import.meta.dirname, "..");
const outputName = "nexus-academics-offline.html";
const client = new Client({
  connectionString: process.env.DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/app_db",
});

function text(value) {
  return String(value ?? "").trim();
}

function json(value, fallback) {
  if (value === null || value === undefined) return fallback;
  if (typeof value === "object") return value;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

async function first(query, params = []) {
  const rows = await client.query(query, params);
  return rows.rows;
}

try {
  await client.connect();

  const [courseRows, materialRows, quizRows, questionRows, cardRows, newsRows, settingRows, fileRows] = await Promise.all([
    first(`SELECT id, code, title, summary, description, track, credits, level, position
           FROM courses ORDER BY position, id`),
    first(`SELECT id, course_id, title, description, kind, week, url, content, posted_by, created_at
           FROM materials WHERE published = true ORDER BY id`),
    first(`SELECT id, course_id, title, description, mode, time_limit_minutes, week
           FROM quizzes WHERE published = true ORDER BY id`),
    first(`SELECT id, quiz_id, prompt, type, options, correct, explanation, points, position
           FROM questions ORDER BY quiz_id, position, id`),
    first(`SELECT id, course_id, week, front, back FROM flashcards ORDER BY course_id, id`),
    first(`SELECT id, title, body, created_at FROM announcements ORDER BY created_at DESC LIMIT 30`),
    first(`SELECT key, value FROM settings`),
    first(`SELECT m.id AS material_id, f.filename, f.mime_type, f.size_bytes, f.data
           FROM materials m
           JOIN files f ON f.id = m.file_id
           WHERE m.published = true
           ORDER BY m.id`),
  ]);


  const settings = Object.fromEntries(settingRows.map((x) => [x.key, x.value]));
  const fileByMaterial = new Map(
    fileRows.map((row) => [
      Number(row.material_id),
      {
        fileName: text(row.filename),
        fileMime: row.mime_type || "application/octet-stream",
        fileSize: Number(row.size_bytes || 0),
        fileData: row.data ? Buffer.from(row.data).toString("base64") : null,
      },
    ]),
  );
  const questionsByQuiz = new Map();
  for (const row of questionRows) {
    const q = {
      id: Number(row.id),
      prompt: text(row.prompt),
      type: row.type || "single",
      options: json(row.options, []),
      correct: json(row.correct, ""),
      explanation: text(row.explanation),
      points: Number(row.points || 1),
    };
    if (!questionsByQuiz.has(row.quiz_id)) questionsByQuiz.set(row.quiz_id, []);
    questionsByQuiz.get(row.quiz_id).push(q);
  }

  const data = {
    version: 1,
    generatedAt: new Date().toISOString(),
    label: settings.semester_label || "Offline snapshot · University of Ghana",
    semesterStart: settings.semester_start || "2026-10-26",
    weeks: Math.max(1, Number(settings.semester_weeks || 13)),
    creator: "Osborn Kobi Frimpong",
    courses: courseRows.map((row) => ({
      id: Number(row.id),
      code: text(row.code),
      title: text(row.title),
      summary: text(row.summary),
      description: text(row.description),
      descriptionHtml: row.description ? renderMarkdown(text(row.description)) : "",
      track: row.track || "core",
      credits: Number(row.credits || 3),
      level: Number(row.level || 100),
    })),
    materials: materialRows.map((row) => {
      const content = text(row.content);
      const attached = fileByMaterial.get(Number(row.id)) || {};
      return {
        ...attached,
        id: Number(row.id),
        courseId: Number(row.course_id),
        title: text(row.title),
        desc: text(row.description),
        kind: row.kind || "notes",
        week: row.week === null ? null : Number(row.week),
        link: row.url ? text(row.url) : null,
        plain: content,
        html: content ? renderMarkdown(content) : "",
        slides: row.kind === "slides" && content
          ? content
              .split(/\n\s*---\s*\n/)
              .map((slide) => slide.trim())
              .filter(Boolean)
              .map((slide) => renderMarkdown(slide))
          : [],
        source: text(row.posted_by) || "Nexus Academics",
      };
    }),
    quizzes: quizRows.map((row) => ({
      id: Number(row.id),
      courseId: Number(row.course_id),
      title: text(row.title),
      desc: text(row.description),
      mode: row.mode || "practice",
      week: row.week === null ? null : Number(row.week),
      timeLimitMinutes: Math.max(1, Number(row.time_limit_minutes || 15)),
      questions: questionsByQuiz.get(row.id) || [],
    })).filter((quiz) => quiz.questions.length > 0),
    flashcards: cardRows.map((row) => ({
      id: Number(row.id),
      courseId: Number(row.course_id),
      week: row.week === null ? null : Number(row.week),
      front: text(row.front),
      back: text(row.back),
    })),
    announcements: newsRows.map((row) => ({
      id: Number(row.id),
      title: text(row.title),
      body: text(row.body),
      createdAt: row.created_at,
    })),
  };

  const packed = Buffer.from(JSON.stringify(data), "utf8").toString("base64");
  const template = fs.readFileSync(path.join(root, "scripts/offline-template.html"), "utf8");
  if (!template.includes("__DATA__")) throw new Error("Offline template is missing the __DATA__ placeholder.");
  const html = template.replace("__DATA__", packed);

  fs.mkdirSync(path.join(root, "public/downloads"), { recursive: true });
  for (const target of [path.join(root, "public", outputName), path.join(root, "public/downloads", outputName)]) {
    fs.writeFileSync(target, html, "utf8");
  }

  const size = Buffer.byteLength(html);
  console.log(
    `Offline HTML built: ${size.toLocaleString()} bytes · ` +
    `${data.courses.length} courses, ${data.materials.length} materials, ` +
    `${data.quizzes.length} quizzes, ${data.flashcards.length} flashcards.`,
  );
  console.log(`Open: /${outputName}`);
  console.log(`Download: /downloads/${outputName}`);
} catch (error) {
  console.error(error);
  process.exitCode = 1;
} finally {
  await client.end();
}
