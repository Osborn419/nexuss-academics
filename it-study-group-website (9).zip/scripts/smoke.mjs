import assert from "node:assert/strict";

const base = process.env.TEST_BASE_URL || "http://127.0.0.1:3000";
const paths = [
  "/", "/api/health", "/courses", "/courses/dcit-101", "/courses/dcit-103",
  "/courses/dcit-105", "/courses/stat-111", "/courses/econ-101", "/courses/ugrc-110",
  "/courses/ugrc-150", "/materials", "/quizzes", "/leaderboard", "/calendar",
  "/flashcards", "/forum", "/assignments", "/presentations", "/announcements",
  "/assistant", "/register", "/login",
];

for (const path of paths) {
  const response = await fetch(`${base}${path}`, { redirect: "manual" });
  assert.equal(response.status, 200, `${path} returned ${response.status}`);
  console.log(`OK ${path}`);
}

for (const [path, payload] of [
  ["/api/attempts", { quizId: 1, answers: {} }],
  ["/api/forum?kind=thread", { title: "unauthorised", body: "not allowed" }],
  ["/api/admin/courses", { code: "BAD 101", title: "Not allowed" }],
  ["/api/admin/materials", {}],
  ["/api/me?action=bookmark", { materialId: 1 }],
]) {
  const response = await fetch(`${base}${path}`, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
  });
  assert.ok(response.status === 401 || response.status === 403, `${path} not protected: ${response.status}`);
  console.log(`Protected ${path} (${response.status})`);
}

const csrf = await fetch(`${base}/api/auth?action=register`, {
  method: "POST", headers: { "Content-Type": "application/json", Origin: "https://attacker.example" },
  body: JSON.stringify({ name: "Intruder", email: "intruder@example.com", password: "notAllowed123" }),
});
assert.equal(csrf.status, 403, `Cross-origin request was not rejected: ${csrf.status}`);
console.log("Cross-origin mutation rejected");
console.log("HTTP smoke checks passed (no accounts or content created).");
