# Get your own public Nexus Academics link

This guide is for Osborn Kobi Frimpong, Founder & Developer.

The goal is simple: your study group should visit a link like this:

```text
https://nexus-academics-osborn.vercel.app
```

They should not need to visit Arena AI or Gift Hub.

You must create the live website using your own free Vercel, GitHub and Neon accounts. The coding assistant can prepare the application, but it cannot create those outside accounts on your behalf.

## Option A — fastest professional-looking link

This uses Vercel’s free address. It looks independent and is the best starting point.

1. Download the completed project from this development environment:

```text
/downloads/nexus-academics-source.zip
```

2. Extract the ZIP to a folder named `nexus-academics`.
3. Create a free GitHub account at `https://github.com`.
4. On GitHub, choose **New repository**.
5. Name it `nexus-academics`.
6. Upload all extracted files to that repository.
7. Create a free Neon account at `https://neon.tech`.
8. Create a project named `nexus-academics` and copy the **pooled** connection string.
9. Create a free Vercel account at `https://vercel.com`.
10. In Vercel, choose **Add New → Project** and import your GitHub repository.
11. Set these environment variables in Vercel:

```text
DATABASE_URL
ADMIN_SETUP_TOKEN
NEXT_PUBLIC_SITE_URL
```

For `ADMIN_SETUP_TOKEN`, use a random value. You can create one at `https://www.miniwebtool.com/uuid-generator/` or use this command if you have a terminal:

```bash
openssl rand -hex 32
```

For `NEXT_PUBLIC_SITE_URL`, use your final Vercel address. If Vercel suggests `nexus-academics-osborn.vercel.app`, enter:

```text
https://nexus-academics-osborn.vercel.app
```

12. In the Neon SQL Editor, paste the entire contents of:

```text
migrations/001_schema.sql
```

Then run it. This creates the database tables.
13. Return to Vercel and deploy.
14. Open your Vercel address followed by `/setup`:

```text
https://nexus-academics-osborn.vercel.app/setup
```

15. Create the administrator account using:

```text
Email: okfrimpong002@st.ug.edu.gh
Name: Osborn Kobi Frimpong
Setup token: the value you entered for ADMIN_SETUP_TOKEN
```

Choose your own strong administrator password. You will use it to sign in at `/login`.

16. Once the owner account is created, remove `ADMIN_SETUP_TOKEN` from Vercel environment variables and redeploy. This prevents anyone else from using `/setup`.
17. Send this link to the group:

```text
https://nexus-academics-osborn.vercel.app
```

## Option B — best impression

Use a personal domain instead of the Vercel address. Examples:

```text
https://nexusacademics.com
https://learnwithosborn.com
https://osbornacademics.com
```

A `.com` domain commonly costs around $10–$15 per year. Purchase it from Namecheap, Porkbun or Cloudflare Registrar, then open Vercel:

```text
Project → Settings → Domains → Add
```

Follow the DNS instructions shown by Vercel. After the domain is verified, update this Vercel environment variable:

```text
NEXT_PUBLIC_SITE_URL=https://nexusacademics.com
```

Use the exact domain you own.

## No-hosting fallback: single HTML app

If you do not want to create a hosted website yet, run:

```bash
npm run build:offline
```

Then send:

```text
public/downloads/nexus-academics-offline.html
```

Students can open it directly in Chrome or Safari. It contains the current written courses, slides, tests, flashcards and progress tools in one file. It does not need Vercel, GitHub, Arena or Gift Hub.

However, it is a local file—not a public website URL. Each student’s progress is stored only on their device, and your local edits do not reach them automatically. For a shared live site, use Option A or B above.

## What to say to the study group

A good WhatsApp message:

> Nexus Academics is now live. It has our DCIT, STAT, ECON and UGRC materials, practice exams, timetable, calendar and progress tracking. Sign up with your student details and choose either UGRC 110 or UGRC 150.  
> Website: https://your-link

Do not send them the Arena development preview address.

## Make it look properly yours

After deployment:

1. Sign in at `/login`.
2. Open `/admin/materials`.
3. Upload your genuine lecture notes and past questions for each course.
4. Remove or unpublish the example starter notes.
5. Add the correct Week 5 materials and the real course outline.
6. Create an announcement in `/admin/announcements`.
7. Add the group meeting schedule in `/admin/sessions`.
8. Add at least one practice paper in `/admin/quizzes`.
9. Check the website on a phone before sending the link.

## Important privacy warning

The project currently contains your personal phone number and email addresses because you requested creator branding. Before inviting all students:

1. Open `src/config/site.ts`.
2. Decide whether you want your phone number public.
3. Set:

```ts
showPhone: false
```

4. If you want, replace the personal Gmail with only your school address.
5. Commit the change and redeploy.

## Make the WhatsApp link preview professional

The project already includes:

```text
public/opengraph.jpg
```

It is the card image students see when you paste the link into WhatsApp. For it to appear, your Vercel project must have:

```text
NEXT_PUBLIC_SITE_URL=https://your-exact-vercel-or-custom-domain
```

Deploy, then paste the URL into a private chat. WhatsApp may cache the first preview, so wait for deployment and, if necessary, restart WhatsApp.

## Things that must not be shared publicly

Keep these private:

- your GitHub repository password;
- your Vercel password;
- the Neon `DATABASE_URL`;
- `ADMIN_SETUP_TOKEN`;
- your administrator password;
- any OpenAI key.

Never put a database password in the project files. Vercel environment variables are the correct place.

## Quick troubleshooting

### The site loads but shows a database error

`DATABASE_URL` is wrong or the Neon branch is paused. Reactivate the Neon database and redeploy.

### `/setup` says setup is not configured

`ADMIN_SETUP_TOKEN` is missing from Vercel, or Vercel has not been redeployed after adding it.

### `/setup` says an administrator already exists

Sign in with the owner account. Do not create a second administrator. If you forgot your password, use the recovery process available in the administrator tools or reset the administrator password directly through a trusted database tool.

### The link contains a random Vercel URL

Change the Vercel project name:

```text
Project → Settings → General → Project Name
```

For example:

```text
nexus-academics-osborn
```

### Students cannot sign up

Check the GitHub Actions CI result and confirm the Vercel deployment is Production, not only Preview. A preview deployment is for testing; the public production deployment is the link to share.

### You want an even more official address

The best option is a custom domain, not another free generator. A custom domain gives the website its own identity and makes it immediately clear that it is not an Arena-generated preview.
