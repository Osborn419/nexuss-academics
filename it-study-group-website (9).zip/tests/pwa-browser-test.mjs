/**
 * Nexus Academics hybrid PWA browser test.
 * Requires the production server running (TEST_BASE_URL) and Playwright Chromium.
 *
 *   TEST_BASE_URL=http://127.0.0.1:3400 node tests/pwa-browser-test.mjs
 */
import { chromium } from "playwright";
import assert from "node:assert/strict";
import { Client } from "pg";

const BASE = process.env.TEST_BASE_URL || "http://127.0.0.1:3400";
const DB_URL = process.env.DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/app_db";

const results = [];
async function check(name, fn) {
  try {
    await fn();
    results.push({ name, ok: true });
    console.log(`PASS  ${name}`);
  } catch (error) {
    results.push({ name, ok: false, error: error?.message ?? String(error) });
    console.log(`FAIL  ${name}\n      ${error?.message ?? error}`);
  }
}

const browser = await chromium.launch();
const context = await browser.newContext();
const page = await context.newPage();
const db = new Client({ connectionString: DB_URL });
await db.connect();

const stamp = Date.now();
const studentEmail = `pwa.test.${stamp}@example.org`;
const studentPassword = "HybridTest123";
let materialUrl = null;
let progressTarget = null; // {courseId, week} created while online, used by the conflict test

try {
  await check("1. Website opens online", async () => {
    const response = await page.goto(`${BASE}/`, { waitUntil: "load" });
    assert.equal(response.status(), 200);
    assert.match(await page.title(), /Nexus Academics/);
    // Next.js streams the page shell first; wait for the hero to be rendered.
    await page.locator("h1").first().waitFor({ state: "visible", timeout: 20000 });
  });

  await check("2. Manifest and service worker are served", async () => {
    const sw = await page.request.get(`${BASE}/sw.js`);
    assert.equal(sw.status(), 200);
    assert.match(sw.headers()["content-type"], /javascript/);
    const manifest = await page.request.get(`${BASE}/manifest.json`);
    assert.equal(manifest.status(), 200);
    const body = await manifest.json();
    assert.equal(body.name, "Nexus Academics");
    assert.ok(body.icons.length >= 2, "manifest needs icons");
    const html = await page.content();
    assert.match(html, /<link rel="manifest" href="\/manifest\.json">/);
    const offlinePage = await page.request.get(`${BASE}/offline.html`);
    assert.equal(offlinePage.status(), 200);
    assert.match(await offlinePage.text(), /You are offline/);
  });

  await check("3. Service worker installs and controls the page", async () => {
    const ready = await page.evaluate(
      () => navigator.serviceWorker.ready.then((reg) => Boolean(reg.active)),
    );
    assert.equal(ready, true, "no active service worker");
    await page.waitForFunction(() => navigator.serviceWorker.controller !== null, {
      timeout: 20000,
    });
  });

  await check("4. Precache finished (offline fallback + offline app stored)", async () => {
    const cached = await page.evaluate(async () => {
      const names = await caches.keys();
      const pre = names.find((n) => n.includes("-precache"));
      if (!pre) return [];
      const cache = await caches.open(pre);
      return (await cache.keys()).map((r) => new URL(r.url).pathname);
    });
    assert.ok(cached.includes("/offline.html"), `missing /offline.html in ${cached}`);
    assert.ok(cached.includes("/nexus-academics-offline.html"), "offline app not precached");
    assert.ok(cached.includes("/manifest.json"), "manifest not precached");
  });

  await check("5. API responses are never written to cache storage", async () => {
    // Visit a private page first so personal data exists in memory only.
    await page.goto(`${BASE}/register`, { waitUntil: "load" });
    await page.getByPlaceholder("e.g. Osborn Frimpong").fill("PWA Test Student");
    await page.getByPlaceholder("you@st.ug.edu.gh").fill(studentEmail);
    await page.locator('input[type="password"]').first().fill(studentPassword);
    await page.getByRole("button", { name: /Create your account/ }).click();
    await page.waitForURL("**/dashboard", { timeout: 20000 });

    const apiCached = await page.evaluate(async () => {
      const names = await caches.keys();
      const urls = [];
      for (const name of names) {
        const cache = await caches.open(name);
        for (const req of await cache.keys()) {
          const path = new URL(req.url).pathname;
          if (path.startsWith("/api/")) urls.push(path);
        }
      }
      return urls;
    });
    assert.deepEqual(apiCached, [], `API responses cached: ${apiCached}`);
  });

  await check("6. Student registration works (account created, dashboard opens)", async () => {
    assert.ok(page.url().includes("/dashboard"), `expected dashboard, got ${page.url()}`);
    const rows = await db.query("select id, role from profiles where email = $1", [studentEmail]);
    assert.equal(rows.rowCount, 1, "student row missing");
    assert.equal(rows.rows[0].role, "student", "registration must never create an admin");
  });

  await check("7. Login works after logout", async () => {
    await page.goto(`${BASE}/profile`, { waitUntil: "load" });
    await page.evaluate(() => fetch("/api/auth?action=logout", { method: "POST" }));
    await page.goto(`${BASE}/login`, { waitUntil: "load" });
    await page.getByPlaceholder("you@st.ug.edu.gh").fill(studentEmail);
    await page.locator('input[type="password"]').first().fill(studentPassword);
    await page.getByRole("button", { name: /^Sign in$/ }).click();
    await page.waitForURL("**/dashboard", { timeout: 20000 });
    assert.ok(page.url().includes("/dashboard"));
  });

  await check("8. Online progress persists after reload (server-side)", async () => {
    await page.goto(`${BASE}/weeks`, { waitUntil: "load" });
    const toggle = page.getByRole("button", { name: /Week \d+ done/ }).first();
    await toggle.waitFor({ timeout: 15000 });
    const before = await toggle.getAttribute("aria-pressed");
    await toggle.click();
    await page.waitForTimeout(1200);
    await page.reload({ waitUntil: "load" });
    const afterToggle = page.getByRole("button", { name: /Week \d+ done|Completed/ }).first();
    const pressed = await afterToggle.getAttribute("aria-pressed");
    assert.notEqual(pressed, before, "progress state did not change");

    const rows = await db.query(
      `select cp.course_id, cp.week from course_progress cp
       join profiles p on p.id = cp.profile_id where p.email = $1
       order by cp.updated_at desc limit 1`,
      [studentEmail],
    );
    assert.ok(rows.rowCount >= 1, "no progress row stored server-side");
    progressTarget = { courseId: rows.rows[0].course_id, week: rows.rows[0].week };
  });

  await check("9. AI endpoint answers honestly online (no fake success, no key leak)", async () => {
    await page.goto(`${BASE}/assistant`, { waitUntil: "load" });
    await page.getByRole("button", { name: /Big-O notation/ }).click();
    await page.waitForFunction(
      () => /provider returned an error|provider rejected|could not reach|rate limit|not available/i.test(document.body.innerText),
      { timeout: 30000 },
    );
    const text = await page.locator("#app, main").first().innerText();
    assert.doesNotMatch(text, /sk-dummy/, "AI key leaked into the page");
    // Without a valid provider key the assistant must report failure, not fabricate an answer.
    assert.match(
      text,
      /provider returned an error|provider rejected|could not reach|rate limit|assistant_unreachable/i,
      "expected a truthful failure message, not a simulated answer",
    );
  });

  // ---------------------------------------------------------------- offline
  await check("10. Material page is cached while online (for offline reading)", async () => {
    await page.goto(`${BASE}/materials`, { waitUntil: "load" });
    const href = await page.evaluate(() => {
      const link = [...document.querySelectorAll("a")].find((a) => /^\/materials\/\d+$/.test(a.getAttribute("href") || ""));
      return link ? link.getAttribute("href") : null;
    });
    assert.ok(href, "no material link found");
    materialUrl = `${BASE}${href}`;
    await page.goto(materialUrl, { waitUntil: "load" });
    assert.ok((await page.locator("h1").first().innerText()).length > 3);
  });

  await check("11. Website opens offline after being cached", async () => {
    await context.setOffline(true);
    await page.goto(`${BASE}/`, { waitUntil: "load" });
    const heading = await page.locator("h1").first().innerText();
    assert.match(heading, /Nexus|Learn together/i, `unexpected offline home: ${heading}`);
    const pill = await page.locator("text=Offline").first().isVisible();
    assert.ok(pill, "offline indicator not visible");
  });

  await check("12. Previously visited material stays readable offline", async () => {
    await page.goto(materialUrl, { waitUntil: "load" });
    const heading = await page.locator("h1").first().innerText();
    assert.ok(heading.length > 3, "material heading missing offline");
    const body = await page.locator("main").innerText();
    assert.match(body, /Material|Week|Open|Bookmark/i);
  });

  await check("13. Uncached page falls back to the offline page", async () => {
    await page.goto(`${BASE}/admin/attempts`, { waitUntil: "load" });
    const text = await page.locator("main").innerText();
    // The fallback uses uppercase styling; match case-insensitively.
    assert.match(text, /you are offline/i);
    assert.match(text, /offline study app/i);
  });

  await check("14. Complete offline app opens with no internet", async () => {
    await page.goto(`${BASE}/nexus-academics-offline.html`, { waitUntil: "load" });
    const text = await page.locator("body").innerText();
    assert.match(text, /Nexus Academics/);
    assert.match(text, /Courses|Library|Exams/);
  });

  await check("15. AI assistant shows a friendly offline message", async () => {
    await page.goto(`${BASE}/assistant`, { waitUntil: "load" });
    const suggestion = page.getByRole("button", { name: /Big-O notation/ });
    if (await suggestion.count()) {
      await suggestion.click();
    } else {
      await page.locator('input[placeholder*="Ask about"]').fill("What is Big-O?");
      await page.locator('input[placeholder*="Ask about"]').press("Enter");
    }
    await page.waitForTimeout(800);
    const text = await page.locator("main").innerText();
    assert.match(text, /You are offline/i, "offline assistant message missing");
    assert.match(text, /cannot reach the AI assistant/i);
  });

  await check("16. Offline change is queued instead of failing silently", async () => {
    assert.ok(progressTarget, "no online progress row was recorded");
    await page.goto(`${BASE}/weeks`, { waitUntil: "load" });
    // The row created online shows as completed; toggling it offline queues "un-complete".
    const toggle = page
      .locator('button[aria-pressed="true"]')
      .filter({ hasText: new RegExp(`Week ${progressTarget.week} done|Completed`) })
      .first();
    await toggle.waitFor({ timeout: 15000 });
    await toggle.click();
    await page.waitForTimeout(800);
    const queued = await page.evaluate(() => {
      try {
        return JSON.parse(localStorage.getItem("nexus_pending_sync_v1") || "[]");
      } catch {
        return [];
      }
    });
    assert.equal(queued.length, 1, `queue length ${queued.length}, expected exactly 1`);
    assert.equal(Number(queued[0].payload.courseId), Number(progressTarget.courseId), "queued wrong course");
    assert.equal(Number(queued[0].payload.week), Number(progressTarget.week), "queued wrong week");
    const notice = await page.locator("text=Offline").first().isVisible();
    assert.ok(notice, "offline indicator missing while queued");
  });

  await check("17. Reconnect syncs the queue without overwriting newer online data", async () => {
    // Simulate another device writing a NEWER change while this one was offline.
    const rows = await db.query(
      `select cp.id from course_progress cp
       join profiles p on p.id = cp.profile_id
       where p.email = $1 and cp.course_id = $2 and cp.week = $3`,
      [studentEmail, progressTarget.courseId, progressTarget.week],
    );
    assert.ok(rows.rowCount >= 1, "expected the queued progress row to exist before conflict");
    await db.query(
      "update course_progress set updated_at = now() + interval '1 hour' where id = $1",
      [rows.rows[0].id],
    );
    const beforeRow = await db.query("select id from course_progress where id = $1", [rows.rows[0].id]);
    assert.equal(beforeRow.rowCount, 1, "server row disappeared before sync");

    await context.setOffline(false);
    await page.waitForTimeout(2500);
    await page.waitForFunction(
      () => {
        try {
          return JSON.parse(localStorage.getItem("nexus_pending_sync_v1") || "[]").length === 0;
        } catch {
          return false;
        }
      },
      { timeout: 20000 },
    );

    const text = await page.locator("main").innerText();
    const body = await page.locator("body").innerText();
    assert.match(
      `${text}\n${body}`,
      /newest online state|another device/i,
      "conflict notice not shown to the student",
    );

    const afterRow = await db.query("select id from course_progress where id = $1", [rows.rows[0].id]);
    assert.equal(afterRow.rowCount, 1, "offline change silently overwrote newer online data");
    const pressed = await page
      .locator('button[aria-pressed="true"]')
      .filter({ hasText: new RegExp(`Week ${progressTarget.week} done|Completed`) })
      .first()
      .getAttribute("aria-pressed");
    assert.equal(pressed, "true", "UI did not restore the newest online state after conflict");
  });

  await check("18. Administrator area is protected (anonymous and student)", async () => {
    const anon = await browser.newContext();
    const anonPage = await anon.newPage();
    // The middleware must answer with a real redirect before any admin rendering.
    const raw = await anonPage.request.get(`${BASE}/admin`, { maxRedirects: 0 });
    assert.equal(raw.status(), 307, `anonymous /admin returned ${raw.status()}`);
    await anonPage.goto(`${BASE}/admin`, { waitUntil: "load" });
    assert.match(anonPage.url(), /\/login/, `anonymous reached ${anonPage.url()}`);
    const anonHtml = await anonPage.content();
    assert.doesNotMatch(anonHtml, /Manage the platform|Group roster/, "admin content leaked");
    const anonApi = await anonPage.request.post(`${BASE}/api/admin/courses`, {
      data: { code: "HACK 101", title: "Should fail" },
    });
    assert.ok([401, 403].includes(anonApi.status()), `anon admin API status ${anonApi.status()}`);
    await anon.close();

    await page.goto(`${BASE}/admin`, { waitUntil: "load" });
    await page.waitForTimeout(800);
    assert.match(page.url(), /\/dashboard|\/login/, `student reached ${page.url()}`);
    const studentApi = await page.request.post(`${BASE}/api/admin/courses`, {
      data: { code: "HACK 102", title: "Should fail" },
    });
    assert.ok([401, 403].includes(studentApi.status()), `student admin API status ${studentApi.status()}`);
    const count = await db.query("select count(*)::int as n from courses where code like 'HACK%'");
    assert.equal(count.rows[0].n, 0, "unauthorised course created");
  });

  await check("19. Service worker still controls the app after reconnection", async () => {
    await page.goto(`${BASE}/`, { waitUntil: "load" });
    const controlled = await page.evaluate(() => navigator.serviceWorker.controller !== null);
    assert.equal(controlled, true);
  });
} finally {
  await context.close();
  await browser.close();
  await db.end();
}

const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
if (failed.length) {
  console.log("FAILED:");
  for (const f of failed) console.log(` - ${f.name}: ${f.error}`);
  process.exit(1);
}
