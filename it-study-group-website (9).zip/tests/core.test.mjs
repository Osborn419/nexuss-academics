import test from "node:test";
import assert from "node:assert/strict";
import { gradeQuiz, answersMatch } from "../src/lib/grading.ts";
import { renderMarkdown } from "../src/lib/markdown.ts";
import { getSemesterStatus } from "../src/lib/semester.ts";
import { isAllowedBlobUrl, maxUploadBytes } from "../src/lib/uploads.ts";

const example = [
  { id: 1, type: "single", options: ["A", "B"], correct: "B", points: 2 },
  { id: 2, type: "multiple", options: ["A", "B", "C"], correct: ["A", "C"], points: 3 },
  { id: 3, type: "boolean", options: [], correct: false, points: 1 },
  { id: 4, type: "short", options: [], correct: ["two", "2"], points: 1 },
];

test("server grading awards exactly the configured points", () => {
  const result = gradeQuiz(example, { 1: "B", 2: ["C", "A"], 3: false, 4: "Two!" });
  assert.equal(result.score, 7);
  assert.equal(result.maxScore, 7);
  assert.deepEqual(Object.values(result.results), [true, true, true, true]);
});

test("wrong, partial and blank answers score zero", () => {
  const result = gradeQuiz(example, { 1: "A", 2: ["A"], 3: true });
  assert.equal(result.score, 0);
  assert.deepEqual(Object.values(result.results), [false, false, false, false]);
});

test("symbolic multiple choices must match exactly", () => {
  const q = { id: 5, type: "multiple", options: ["¬q → ¬p", "¬p ∨ q", "q → p"], correct: ["¬q → ¬p", "¬p ∨ q"], points: 1 };
  assert.equal(answersMatch(q, ["q → p", "¬p ∨ q"]), false);
  assert.equal(answersMatch(q, ["¬p ∨ q", "¬q → ¬p"]), true);
});

test("week 5 starts on Monday 23 November 2026", () => {
  const semester = { start: "2026-10-26", weeks: 13, label: "First Semester" };
  const result = getSemesterStatus(semester, new Date("2026-11-23T12:00:00Z"));
  assert.equal(result.currentWeek, 5);
  assert.equal(result.focusWeek, 5);
});

test("only public Vercel Blob URLs are accepted", () => {
  assert.equal(isAllowedBlobUrl("https://my-store.blob.vercel-storage.com/uploads/lecture.pdf"), true);
  assert.equal(isAllowedBlobUrl("https://evil.example/x.pdf"), false);
  assert.equal(isAllowedBlobUrl("http://my-store.blob.vercel-storage.com/uploads/x.pdf"), false);
  assert.equal(isAllowedBlobUrl("https://blob.vercel-storage.com.evil.example/x.pdf"), false);
  assert.equal(maxUploadBytes(), 50 * 1024 * 1024);
  const original = { ...process.env };
  try {
    process.env.VERCEL = "1";
    process.env.MAX_UPLOAD_MB = "10";
    delete process.env.BLOB_READ_WRITE_TOKEN;
    assert.equal(maxUploadBytes(), 4 * 1024 * 1024);
    process.env.BLOB_READ_WRITE_TOKEN = "test-blob-token";
    assert.equal(maxUploadBytes(), 10 * 1024 * 1024);
  } finally {
    process.env = original;
  }
});

test("raw HTML and javascript URLs are stripped from rendered Markdown", () => {
  const html = renderMarkdown('# Notes\n\n<script>alert(1)</script>\n\n[bad](javascript:alert(1))\n\n<a href="javascript:alert(2)" onclick="alert(3)">bad</a>');
  assert.match(html, /<h1>Notes<\/h1>/);
  assert.doesNotMatch(html, /<script|onclick=|javascript:/i);
});
