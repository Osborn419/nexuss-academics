/*
 * Nexus Academics service worker.
 *
 * Strategy
 *  - never caches: non-GET requests, /api/* responses, cross-origin requests
 *  - cache-first: immutable build assets and images
 *  - network-first with cached fallback: page navigations and RSC payloads,
 *    falling back to /offline.html when neither network nor cache has them
 *  - precaches: offline page, manifest, icons, artwork and the complete
 *    offline study app so downloaded materials remain available with no internet
 */
const VERSION = "nexus-pwa-v2";
const PRECACHE = `${VERSION}-precache`;
const RUNTIME = `${VERSION}-runtime`;

const OFFLINE_URL = "/offline.html";
const OFFLINE_APP_URL = "/nexus-academics-offline.html";
const MAX_RUNTIME_ENTRIES = 120;

const PRECACHE_ASSETS = [
  OFFLINE_URL,
  OFFLINE_APP_URL,
  "/manifest.json",
  "/opengraph.jpg",
  "/icons/nexus-192.png",
  "/icons/nexus-512.png",
  "/",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(PRECACHE);
      await Promise.allSettled(
        PRECACHE_ASSETS.map((url) =>
          cache.add(new Request(url, { cache: "reload" })),
        ),
      );
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((key) => !key.startsWith(VERSION)).map((key) => caches.delete(key)),
      );
      await self.clients.claim();
    })(),
  );
});

self.addEventListener("message", (event) => {
  if (event.data === "nexus-skip-waiting") self.skipWaiting();
});

function isCacheableStatic(pathname) {
  return (
    pathname.startsWith("/_next/static/") ||
    pathname.startsWith("/icons/") ||
    /\.(?:png|jpg|jpeg|webp|svg|ico|woff2?|ttf|otf)$/i.test(pathname)
  );
}

async function putInRuntime(request, response) {
  if (!response || !response.ok || response.status === 206) return;
  const cache = await caches.open(RUNTIME);
  await cache.put(request, response.clone());
  const keys = await cache.keys();
  for (let i = 0; i < keys.length - MAX_RUNTIME_ENTRIES; i += 1) {
    await cache.delete(keys[i]);
  }
}

async function networkFirst(request, fallbackUrl) {
  try {
    const response = await fetch(request);
    if (response && response.ok) await putInRuntime(request, response.clone());
    return response;
  } catch (networkError) {
    const cached =
      (await caches.match(request)) ||
      (fallbackUrl ? await caches.match(fallbackUrl) : undefined);
    if (cached) return cached;
    throw networkError;
  }
}

async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response && response.ok) await putInRuntime(request, response.clone());
  return response;
}

self.addEventListener("fetch", (event) => {
  const request = event.request;

  // Mutations and anything non-GET must reach the network untouched.
  if (request.method !== "GET") return;

  let url;
  try {
    url = new URL(request.url);
  } catch {
    return;
  }

  // Cross-origin (AI provider, Blob CDN, external links) is never cached here.
  if (url.origin !== self.location.origin) return;

  // Personal API responses must never be written to device storage.
  if (url.pathname.startsWith("/api/")) return;

  if (isCacheableStatic(url.pathname)) {
    event.respondWith(cacheFirst(request));
    return;
  }

  // Navigations (HTML) and App Router RSC fetches (URL carries ?_rsc=).
  event.respondWith(
    networkFirst(request, request.mode === "navigate" ? OFFLINE_URL : undefined),
  );
});
