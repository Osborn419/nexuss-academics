# Supabase for Nexus Academics

This document states exactly what is connected, what is prepared, and what has
been tested. Nothing here is simulated.

## 1. What works with Supabase today (no code changes)

Nexus Academics talks to plain PostgreSQL. Supabase's hosted PostgreSQL works
as the application database:

1. Create a Supabase project.
2. Copy the **pooled** connection string (Project Settings → Database).
   For the transaction pooler keep `?pgbouncer=true` in the URL.
3. Set it as `DATABASE_URL` in Vercel/your server environment.
4. Run the schema:
   ```bash
   npx drizzle-kit push
   # or, on a brand new empty database:
   psql "$DATABASE_URL" -f migrations/001_schema.sql
   ```
5. Set `ADMIN_SETUP_TOKEN`, deploy, then open `/setup` once to create the
   owner account and remove the token.

The database layer already handles:

- TLS for hosted (non-localhost) servers by default (`PGSSLMODE=require|no-verify|disable`);
- connection pooling and timeouts;
- `?pgbouncer=true` URLs.

**Honest status:** the driver configuration is unit-verified and the app is
tested against local PostgreSQL. It was **not** run against a live Supabase
instance in this environment, because no Supabase project credentials were
available here. Supabase's pooled endpoint is standard PostgreSQL over TLS, so
the expected failure modes are connection-string mistakes, not protocol ones.

## 2. Row Level Security

`supabase/rls_policies.sql` contains complete RLS policies for every table:

- public read for courses, published materials, announcements, sessions,
  presentations and flashcards;
- **answer keys (`questions.correct`) are never publicly readable**;
- owner-only access for profiles, attempts, bookmarks, progress, notifications,
  enrolments, forum content and assignment submissions;
- administrator-only writes, with `is_admin()` derived from `auth.uid()`;
- no client-side updates or deletes on exam attempts.

**Honest status:** the file is written for the standard Supabase Auth model
(`auth.uid()` and the `anon`/`authenticated` roles). It has **not** been applied
to this build and must not be applied to it.

Why: this application authorizes every request in its own server routes using
its own database-backed sessions, and it connects as a single database role.
RLS with one shared role cannot distinguish students from the administrator.
Applying these policies now would lock the application out of its own tables.

## 3. Authentication — the real current state

| Capability | Status |
| --- | --- |
| Secure student registration, login, logout | Implemented and tested (scrypt hashes, random 30-day DB session cookies) |
| One owner administrator, private setup token, one-admin DB constraint | Implemented and tested |
| Password change, one-time admin-issued reset links | Implemented and tested |
| Supabase Auth (email/password, magic link, OAuth) | **Not implemented** |
| Supabase Realtime (live forum/notifications) | **Not implemented** |
| Supabase Storage | **Not used** — files use Vercel Blob or PostgreSQL `bytea` |

Replacing the tested custom auth with Supabase Auth means swapping the session
and profile layer and then applying the RLS file above. It is a deliberate,
testable migration — not something to bolt on and claim complete. If you want
it, do it as its own stage against a real Supabase project.

## 4. Recommended migration path (later, on your own Supabase project)

1. Keep Supabase **Postgres** as `DATABASE_URL` (stage 1 above) — you get the
   hosted database immediately with the tested application.
2. Create a non-owner database role for the app, and store its password as
   `DATABASE_URL`.
3. Add `profiles.supabase_user_id uuid` and migrate sign-in to Supabase Auth.
4. Apply `supabase/rls_policies.sql`.
5. Verify with the checklist: anonymous visitor can read published material but
   not `/questions`; a student cannot read another student's attempt; a student
   cannot write to `profiles.role`.
6. Only then consider Supabase Realtime for the forum and notifications.

## 5. What Supabase is NOT required for

The hosted application, PWA offline caching, the AI assistant endpoint, Vercel
Blob uploads, custom domains and every tested feature run with plain
PostgreSQL. Supabase is an upgrade path, not a dependency.
