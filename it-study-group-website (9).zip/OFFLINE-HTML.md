# Nexus Academics — single-file offline version

## File to use

```text
public/nexus-academics-offline.html
public/downloads/nexus-academics-offline.html
```

Both are the same self-contained file. Send the copy from `public/downloads`.

## What it contains

This HTML file includes the current database snapshot:

- seven course pages;
- written lecture notes and study material;
- rendered slide decks with next/previous controls;
- practice tests and formal offline tests;
- questions, answer explanations and local automatic marking;
- flashcards;
- announcements;
- course enrolment;
- weekly progress;
- bookmarks;
- personal study profile;
- local exam attempt history;
- calendar/semester view;
- local study-session planner;
- local content manager, export, import and reset.

It has no external JavaScript, external stylesheet, framework or API key. Open it in Chrome, Safari or any modern browser. It is approximately 285 KB.

## How to give it to your study group

1. Send `nexus-academics-offline.html` through WhatsApp, email or Google Drive.
2. Tell them to download it, then open it from their Files app.
3. On Android, choose **Chrome**. On iPhone, choose **Open in Safari**.
4. Their progress is stored in their own browser.

This is genuinely independent of Vercel, GitHub, Arena AI and Gift Hub. It does **not** give you a public website address by itself. If someone double-clicks the file, the address begins with `file:///`, meaning it is on that device.

## Why a real link is still different

A normal website link, such as `https://nexus-academics.com`, must point at a computer that is online and receiving requests. The file can be opened without internet, but that only makes it an offline personal app.

For a shared live website with student accounts, shared scores, central assignments and real security, the hosted Next.js application in this project is the correct version. The HTML file is the standalone fallback you requested.

## Honest limitations

The HTML version is not equivalent to the full server application.

- Data is local to each phone/browser.
- Osborn’s edits in Local admin do not reach students automatically.
- Students must send or export their local JSON file for you to collect their progress.
- There is no real login because a local file cannot verify identities.
- Exam answer keys are embedded and cannot be protected.
- There is no shared forum or central leaderboard.
- Attached uploaded files are embedded as base64 and reconstructed by the offline **Save / open file** button. This makes the file grow with every attachment and can exceed browser/local-storage limits, so it is practical for a normal study bundle rather than a huge archive. The builder was tested with a small PDF, while the current live database contains zero binary files.
- Progress disappears if browser storage is cleared.

## Regenerate it from the live database

From the project folder:

```bash
npm run build:offline
```

This rebuilds both copies from the PostgreSQL database configured in `.env`. Run it again after you add or change materials.
