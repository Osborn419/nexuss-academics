-- ============================================================================
-- Nexus Academics · Row Level Security policies for Supabase
-- ============================================================================
--
-- READ THIS FIRST — when is this file active?
--
-- This build enforces authorization in the application's server routes using
-- its own database-backed sessions, with a single PostgreSQL role (DATABASE_URL).
-- The application's queries run as that one role, so RLS cannot tell "student"
-- from "admin" on its own. For that reason the policies below are written for
-- the standard Supabase pattern: Supabase Auth (auth.uid()) + the `anon` /
-- `authenticated` roles. They are NOT applied to the current build and have
-- NOT been executed against a live Supabase instance in this development
-- environment.
--
-- Apply this file only after you have:
--   1. created a Supabase project,
--   2. migrated sign-in to Supabase Auth (see SUPABASE.md), and
--   3. connected the app with a non-owner, non-superuser database role.
--
-- Applying it earlier WILL lock the application out of its own tables.
-- ============================================================================

begin;

-- Helper: does the current Supabase Auth user own an administrator profile?
-- Requires profiles.supabase_user_id (added by the Supabase Auth migration).
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from profiles p
    where p.supabase_user_id = auth.uid()
      and p.role = 'admin'
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- ---------------------------------------------------------------------------
-- Public learning content: readable by everyone, writable only by admins.
-- NOTE: questions.correct (answer keys) is deliberately NOT publicly readable.
-- ---------------------------------------------------------------------------
alter table courses enable row level security;
alter table materials enable row level security;
alter table announcements enable row level security;
alter table study_sessions enable row level security;
alter table presentations enable row level security;
alter table flashcards enable row level security;

create policy "public can read courses"
  on courses for select using (true);
create policy "admins can write courses"
  on courses for all using (public.is_admin()) with check (public.is_admin());

create policy "public can read published materials"
  on materials for select using (published = true or public.is_admin());
create policy "admins can write materials"
  on materials for all using (public.is_admin()) with check (public.is_admin());

create policy "public can read announcements"
  on announcements for select using (true);
create policy "admins can write announcements"
  on announcements for all using (public.is_admin()) with check (public.is_admin());

create policy "public can read study sessions"
  on study_sessions for select using (true);
create policy "admins can write study sessions"
  on study_sessions for all using (public.is_admin()) with check (public.is_admin());

create policy "public can read presentations"
  on presentations for select using (true);
create policy "admins can write presentations"
  on presentations for all using (public.is_admin()) with check (public.is_admin());

create policy "public can read flashcards"
  on flashcards for select using (true);
create policy "admins can write flashcards"
  on flashcards for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- Assessment catalogue is public; the question bank (with answers) is not.
-- ---------------------------------------------------------------------------
alter table quizzes enable row level security;
alter table questions enable row level security;
alter table attempts enable row level security;

create policy "public can read published quizzes"
  on quizzes for select using (published = true or public.is_admin());
create policy "admins can write quizzes"
  on quizzes for all using (public.is_admin()) with check (public.is_admin());

create policy "admins can read question bank"
  on questions for select using (public.is_admin());
create policy "admins can write question bank"
  on questions for all using (public.is_admin()) with check (public.is_admin());

-- Students see only their own exam records; admins see everything.
create policy "students read own attempts"
  on attempts for select
  using (profile_id = (select id from profiles where supabase_user_id = auth.uid()) or public.is_admin());
create policy "students create own attempts"
  on attempts for insert
  with check (profile_id = (select id from profiles where supabase_user_id = auth.uid()));
create policy "no client updates to attempts"
  on attempts for update using (false);
create policy "no client deletes from attempts"
  on attempts for delete using (false);

-- ---------------------------------------------------------------------------
-- Personal data: strictly owner-only (or administrator).
-- ---------------------------------------------------------------------------
alter table profiles enable row level security;
alter table sessions enable row level security;
alter table password_reset_tokens enable row level security;
alter table enrolments enable row level security;
alter table course_progress enable row level security;
alter table bookmarks enable row level security;
alter table notifications enable row level security;
alter table forum_threads enable row level security;
alter table forum_replies enable row level security;
alter table forum_reports enable row level security;
alter table assignment_submissions enable row level security;

create policy "profile visibility"
  on profiles for select
  using (supabase_user_id = auth.uid() or public.is_admin());
create policy "profile self update"
  on profiles for update
  using (supabase_user_id = auth.uid())
  with check (supabase_user_id = auth.uid() and role = 'student');
create policy "profiles are created by the app, not by clients"
  on profiles for insert with check (false);

create policy "no client access to sessions"
  on sessions for all using (false);
create policy "no client access to reset tokens"
  on password_reset_tokens for all using (false);

create policy "own enrolments"
  on enrolments for select using (profile_id = (select id from profiles where supabase_user_id = auth.uid()) or public.is_admin());
create policy "own enrolment writes"
  on enrolments for insert with check (profile_id = (select id from profiles where supabase_user_id = auth.uid()));
create policy "own enrolment deletes"
  on enrolments for delete using (profile_id = (select id from profiles where supabase_user_id = auth.uid()));

create policy "own progress"
  on course_progress for select using (profile_id = (select id from profiles where supabase_user_id = auth.uid()) or public.is_admin());
create policy "own progress writes"
  on course_progress for insert with check (profile_id = (select id from profiles where supabase_user_id = auth.uid()));
create policy "own progress deletes"
  on course_progress for delete using (profile_id = (select id from profiles where supabase_user_id = auth.uid()));

create policy "own bookmarks"
  on bookmarks for select using (profile_id = (select id from profiles where supabase_user_id = auth.uid()) or public.is_admin());
create policy "own bookmark writes"
  on bookmarks for insert with check (profile_id = (select id from profiles where supabase_user_id = auth.uid()));
create policy "own bookmark deletes"
  on bookmarks for delete using (profile_id = (select id from profiles where supabase_user_id = auth.uid()));

create policy "own notifications"
  on notifications for select using (profile_id = (select id from profiles where supabase_user_id = auth.uid()));
create policy "own notification updates"
  on notifications for update using (profile_id = (select id from profiles where supabase_user_id = auth.uid()));

-- Forum: readable by signed-in users, authored by themselves, moderated by admin.
create policy "signed-in users read threads"
  on forum_threads for select
  using (auth.uid() is not null or public.is_admin());
create policy "signed-in users create threads"
  on forum_threads for insert with check (author_id = (select id from profiles where supabase_user_id = auth.uid()));
create policy "admin moderates threads"
  on forum_threads for delete using (public.is_admin());

create policy "signed-in users read replies"
  on forum_replies for select using (auth.uid() is not null or public.is_admin());
create policy "signed-in users create replies"
  on forum_replies for insert with check (author_id = (select id from profiles where supabase_user_id = auth.uid()));
create policy "admin moderates replies"
  on forum_replies for delete using (public.is_admin());

create policy "signed-in users report"
  on forum_reports for insert with check (reporter_id = (select id from profiles where supabase_user_id = auth.uid()));
create policy "admin reads reports"
  on forum_reports for select using (public.is_admin());
create policy "admin updates reports"
  on forum_reports for update using (public.is_admin());

-- Assignment submissions: only the submitting student and the administrator.
create policy "own submissions"
  on assignment_submissions for select
  using (profile_id = (select id from profiles where supabase_user_id = auth.uid()) or public.is_admin());
create policy "own submission writes"
  on assignment_submissions for insert
  with check (profile_id = (select id from profiles where supabase_user_id = auth.uid()));
create policy "own submission updates"
  on assignment_submissions for update
  using (profile_id = (select id from profiles where supabase_user_id = auth.uid()));

-- ---------------------------------------------------------------------------
-- Course materials: readable through the public policies above.
-- ---------------------------------------------------------------------------
alter table files enable row level security;
create policy "public can read published files"
  on files for select using (exists (
    select 1 from materials m
    where m.file_id = files.id and (m.published = true or public.is_admin())
  ));
create policy "admins can write files"
  on files for all using (public.is_admin()) with check (public.is_admin());

alter table settings enable row level security;
create policy "public can read settings"
  on settings for select using (true);
create policy "admins can write settings"
  on settings for all using (public.is_admin()) with check (public.is_admin());

alter table app_meta enable row level security;
create policy "no client access to app_meta"
  on app_meta for all using (public.is_admin());

commit;
