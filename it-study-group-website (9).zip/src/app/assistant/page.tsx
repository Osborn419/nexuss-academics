import Link from "next/link";
import { Bot } from "lucide-react";
import { AssistantChat } from "@/components/assistant-chat";
import { getCurrentProfile } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "AI academic assistant",
  description: "Ask about any of the seven courses — grounded in the materials the administrator uploads.",
};

export default async function AssistantPage() {
  const profile = await getCurrentProfile();
  const configured = Boolean(process.env.OPENAI_API_KEY || process.env.AI_API_KEY);

  return (
    <div className="mx-auto max-w-3xl space-y-6 pt-6">
      <header>
        <p className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
          <Bot className="h-4 w-4" /> AI academic assistant
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Your revision partner</h1>
        <p className="mt-2 text-sm text-slate-400">
          Explanations, simplifications and practice questions for DCIT 101, DCIT 103, DCIT 105, STAT 111, ECON 101, UGRC 110 and UGRC 150.
        </p>
      </header>

      {!profile ? (
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-8 text-center">
          <p className="text-sm text-slate-400">Sign in to use the assistant — it uses your account so usage can be managed.</p>
          <Link href="/login?next=/assistant" className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-sky-400 px-5 py-2.5 text-sm font-semibold text-canvas">
            Sign in to continue
          </Link>
        </div>
      ) : (
        <AssistantChat configured={configured} />
      )}

      <p className="text-center text-xs text-slate-600">
        AI answers can be wrong — check against your lecturers&apos; materials. The administrator reviews what the assistant is grounded on.
      </p>
    </div>
  );
}
