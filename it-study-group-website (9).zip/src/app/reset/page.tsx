import { ResetPasswordForm } from "@/components/auth-forms";

export const dynamic = "force-dynamic";

export const metadata = { title: "Set a new password" };

export default async function ResetPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string }>;
}) {
  const { token } = await searchParams;

  return (
    <div className="mx-auto max-w-md pt-14">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-semibold tracking-tight text-white">Choose a new password</h1>
        <p className="mt-2 text-sm text-slate-400">This link works once and expires one hour after it was created.</p>
      </div>
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6">
        {token ? (
          <ResetPasswordForm token={token} />
        ) : (
          <p className="rounded-lg bg-rose-500/10 px-4 py-3 text-sm text-rose-300 ring-1 ring-rose-400/25">
            No reset token was provided — ask the administrator for a fresh link.
          </p>
        )}
      </div>
    </div>
  );
}
