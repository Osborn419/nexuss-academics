import { Suspense } from "react";
import { redirect } from "next/navigation";
import { LogIn } from "lucide-react";
import { LoginForm } from "@/components/auth-forms";
import { getCurrentProfile } from "@/lib/auth";
import { site } from "@/config/site";

export const dynamic = "force-dynamic";

export const metadata = { title: "Sign in" };

export default async function LoginPage() {
  const profile = await getCurrentProfile();
  if (profile) redirect(profile.role === "admin" ? "/admin" : "/dashboard");

  return (
    <div className="mx-auto max-w-md pt-14">
      <div className="mb-8 text-center">
        <span className="inline-grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-emerald-400 to-sky-500 text-canvas">
          <LogIn className="h-6 w-6" />
        </span>
        <h1 className="mt-4 text-2xl font-semibold tracking-tight text-white">Sign in to {site.projectName}</h1>
        <p className="mt-2 text-sm text-slate-400">Use your account to sit exams, save progress, bookmark resources and join discussions.</p>
      </div>
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6">
        <Suspense fallback={<p className="text-sm text-slate-500">Loading…</p>}>
          <LoginForm />
        </Suspense>
      </div>
    </div>
  );
}
