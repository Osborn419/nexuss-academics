import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Download, ExternalLink, Presentation } from "lucide-react";
import { SlideDeck } from "@/components/slide-deck";
import { getCourseById, getMaterialById } from "@/lib/queries";
import { slugify } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const material = await getMaterialById(Number(id));
  if (!material) return { title: "Deck not found" };
  return { title: material.title, description: material.description };
}

function splitSlides(content: string): string[] {
  return content
    .split(/\n\s*---\s*\n/)
    .map((slide) => slide.trim())
    .filter((slide) => slide.length > 0);
}

export default async function SlidePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const material = await getMaterialById(Number(id));
  if (!material) notFound();

  const course = await getCourseById(material.courseId);
  const slides = material.content ? splitSlides(material.content) : [];

  return (
    <div className="space-y-8 pt-6">
      <Link
        href={`/courses/${slugify(course?.code ?? "")}`}
        className="inline-flex items-center gap-1.5 text-sm text-slate-400 transition hover:text-emerald-300"
      >
        <ArrowLeft className="h-4 w-4" /> Back to {course?.code ?? "course"}
      </Link>

      <header className="max-w-3xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400/90">
          Slide deck · {course?.code ?? ""}
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          {material.title}
        </h1>
        {material.description ? (
          <p className="mt-3 text-base leading-relaxed text-slate-400">
            {material.description}
          </p>
        ) : null}

        <div className="mt-5 flex flex-wrap gap-3">
          {material.fileId ? (
            <a
              href={`/api/files/${material.fileId}`}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-400/15 px-4 py-2.5 text-sm font-semibold text-emerald-200 ring-1 ring-emerald-400/30 transition hover:bg-emerald-400/25"
            >
              <Download className="h-4 w-4" /> Download the file
            </a>
          ) : null}
          {material.url ? (
            <a
              href={material.url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm font-semibold text-slate-100 transition hover:bg-white/10"
            >
              <ExternalLink className="h-4 w-4" /> Open the source
            </a>
          ) : null}
        </div>
      </header>

      {slides.length > 0 ? (
        <SlideDeck slides={slides} title={material.title} />
      ) : (
        <div className="rounded-2xl border border-dashed border-white/12 p-12 text-center">
          <Presentation className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm text-slate-400">
            This deck has no slides yet.
          </p>
        </div>
      )}

      <p className="text-xs text-slate-500">
        Use the arrow keys to move between slides.
      </p>
    </div>
  );
}
