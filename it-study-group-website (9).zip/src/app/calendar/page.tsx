import Link from "next/link";
import { ChevronLeft, ChevronRight, CalendarDays, ExternalLink } from "lucide-react";
import { getAssignments, getPresentations, getStudySessions } from "@/lib/queries";
import { formatShortDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Academic calendar",
  description: "Study sessions, assignment deadlines and presentation dates in one calendar.",
};

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

interface CalendarEvent {
  day: number;
  label: string;
  tone: "session" | "assignment" | "presentation";
  href?: string;
}

export default async function CalendarPage({
  searchParams,
}: {
  searchParams: Promise<{ m?: string }>;
}) {
  const { m } = await searchParams;
  const match = /^(\d{4})-(\d{2})$/.exec(m ?? "");
  const base = new Date();
  const year = match ? Number(match[1]) : base.getUTCFullYear();
  const month = match ? Number(match[2]) - 1 : base.getUTCMonth();

  const [sessions, assignments, presentations] = await Promise.all([
    getStudySessions(true),
    getAssignments(),
    getPresentations(),
  ]);

  const events: CalendarEvent[] = [];
  const inMonth = (date: Date) => date.getUTCFullYear() === year && date.getUTCMonth() === month;

  for (const { session } of sessions) {
    const date = new Date(session.sessionAt);
    if (inMonth(date)) events.push({ day: date.getUTCDate(), label: `Session: ${session.title}`, tone: "session", href: session.meetingUrl || undefined });
  }
  for (const { assignment } of assignments) {
    if (!assignment.dueDate) continue;
    const date = new Date(assignment.dueDate);
    if (inMonth(date)) events.push({ day: date.getUTCDate(), label: `Due: ${assignment.title}`, tone: "assignment", href: "/assignments" });
  }
  for (const { presentation } of presentations) {
    if (!presentation.sessionDate) continue;
    const date = new Date(presentation.sessionDate);
    if (inMonth(date)) events.push({ day: date.getUTCDate(), label: `Talk: ${presentation.title}`, tone: "presentation", href: presentation.materialId ? `/slides/${presentation.materialId}` : "/presentations" });
  }

  const firstWeekday = (new Date(Date.UTC(year, month, 1)).getUTCDay() + 6) % 7; // Monday = 0
  const daysInMonth = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  const cells: (number | null)[] = [];
  for (let i = 0; i < firstWeekday; i += 1) cells.push(null);
  for (let day = 1; day <= daysInMonth; day += 1) cells.push(day);
  while (cells.length % 7 !== 0) cells.push(null);

  const prevMonth = new Date(Date.UTC(year, month - 1, 1));
  const nextMonth = new Date(Date.UTC(year, month + 1, 1));
  const key = (date: Date) => `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
  const today = new Date();
  const isCurrentMonth = today.getUTCFullYear() === year && today.getUTCMonth() === month;

  const toneClasses: Record<CalendarEvent["tone"], string> = {
    session: "bg-sky-400/15 text-sky-200 ring-sky-400/30",
    assignment: "bg-amber-400/15 text-amber-200 ring-amber-400/30",
    presentation: "bg-violet-400/15 text-violet-200 ring-violet-400/30",
  };

  const nowMs = new Date().getTime();
  const upcoming = sessions.filter(({ session }) => new Date(session.sessionAt).getTime() >= nowMs).slice(0, 3);

  return (
    <div className="space-y-6 pt-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Academic calendar</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">{MONTHS[month]} {year}</h1>
          <p className="mt-2 text-sm text-slate-400">Study sessions, deadlines and presentations in one place.</p>
        </div>
        <div className="flex items-center gap-2">
          <Link href={`/calendar?m=${key(prevMonth)}`} aria-label="Previous month" className="rounded-xl bg-white/5 p-2.5 text-slate-300 ring-1 ring-white/10 hover:bg-white/10"><ChevronLeft className="h-4 w-4" /></Link>
          <Link href="/calendar" className="rounded-xl bg-white/5 px-4 py-2.5 text-sm font-medium text-slate-200 ring-1 ring-white/10 hover:bg-white/10">Today</Link>
          <Link href={`/calendar?m=${key(nextMonth)}`} aria-label="Next month" className="rounded-xl bg-white/5 p-2.5 text-slate-300 ring-1 ring-white/10 hover:bg-white/10"><ChevronRight className="h-4 w-4" /></Link>
        </div>
      </header>

      <div className="overflow-hidden rounded-2xl border border-white/10">
        <div className="grid grid-cols-7 border-b border-white/10 bg-white/[0.03] text-center text-[10px] font-semibold uppercase tracking-wider text-slate-500">
          {WEEKDAYS.map((day) => <div key={day} className="px-2 py-2">{day}</div>)}
        </div>
        <div className="grid grid-cols-7">
          {cells.map((day, index) => {
            const dayEvents = day ? events.filter((event) => event.day === day) : [];
            const isToday = isCurrentMonth && day === today.getUTCDate();
            return (
              <div key={index} className={`min-h-24 border-b border-r border-white/5 p-1.5 sm:min-h-28 sm:p-2 ${day ? "bg-white/[0.015]" : "bg-transparent"}`}>
                {day ? (
                  <>
                    <span className={`grid h-6 w-6 place-items-center rounded-full text-xs ${isToday ? "bg-emerald-400 font-bold text-canvas" : "text-slate-400"}`}>{day}</span>
                    <div className="mt-1 space-y-1">
                      {dayEvents.map((event, eventIndex) => {
                        const content = (
                          <span className={`block truncate rounded px-1.5 py-1 text-[10px] font-medium ring-1 ${toneClasses[event.tone]}`} title={event.label}>
                            {event.label}
                          </span>
                        );
                        return event.href && event.href.startsWith("http") ? (
                          <a key={eventIndex} href={event.href} target="_blank" rel="noreferrer">{content}</a>
                        ) : (
                          <Link key={eventIndex} href={event.href ?? "/calendar"}>{content}</Link>
                        );
                      })}
                    </div>
                  </>
                ) : null}
              </div>
            );
          })}
        </div>
      </div>

      {upcoming.length > 0 ? (
        <section className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <h2 className="flex items-center gap-2 text-base font-semibold text-white"><CalendarDays className="h-5 w-5 text-sky-400" /> Upcoming study sessions</h2>
          <ul className="mt-3 grid gap-3 sm:grid-cols-3">
            {upcoming.map(({ session, courseCode }) => (
              <li key={session.id} className="rounded-xl border border-sky-400/20 bg-sky-400/5 p-4 text-sm">
                <p className="font-mono text-[10px] uppercase text-sky-300">{courseCode ?? "General"}</p>
                <p className="mt-1 font-semibold text-slate-100">{session.title}</p>
                <p className="mt-0.5 text-xs text-slate-400">{formatShortDate(new Date(session.sessionAt))}</p>
                {session.meetingUrl ? (
                  <a href={session.meetingUrl} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-sky-300 hover:text-sky-200">
                    Join the call <ExternalLink className="h-3 w-3" />
                  </a>
                ) : null}
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
