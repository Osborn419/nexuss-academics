import Link from "next/link";
import { Clock, ClipboardCheck, FileQuestion, ShieldCheck, Sparkles } from "lucide-react";
import { getCourses, getQuizzes } from "@/lib/queries";
import { formatDate } from "@/lib/format";
import { getCurrentProfile } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Examinations & practice tests",
  description: "Timed, auto-marked exams and practice quizzes for all seven courses.",
};

export default async function QuizzesPage({
  searchParams,
}: {
  searchParams: Promise<{ course?: string; mode?: string }>;
}) {
  const { course, mode } = await searchParams;
  const activeMode = mode === "exam" || mode === "practice" ? mode : undefined;
  const [courses, quizzes, profile] = await Promise.all([
    getCourses(),
    getQuizzes(activeMode),
    getCurrentProfile(),
  ]);
  const courseMap = new Map(courses.map((item) => [item.id, item]));
  const visible = course
    ? quizzes.filter((quiz) => quiz.courseId === Number(course))
    : quizzes;

  const tab = (value: string | undefined, label: string) => {
    const active = activeMode === value;
    const params = new URLSearchParams();
    if (course) params.set("course", course);
    if (value) params.set("mode", value);
    const href = params.toString() ? `/quizzes?${params}` : "/quizzes";
    return (
      <Link
        href={href}
        className={`rounded-lg px-3.5 py-2 text-sm font-medium ring-1 transition ${
          active ? "bg-white/10 text-white ring-white/20" : "bg-white/5 text-slate-300 ring-white/10 hover:bg-white/10"
        }`}
      >
        {label}
      </Link>
    );
  };

  return (
    <div className="space-y-8 pt-6">
      <header className="max-w-3xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Assessments</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">Examinations &amp; practice tests</h1>
        <p className="mt-3 text-base leading-relaxed text-slate-400">
          Two modes: <span className="text-slate-200">practice quizzes</span> for low-stakes revision, and{" "}
          <span className="text-slate-200">formal examinations</span> marked under timed conditions. Sign in to sit either —
          results and rankings are stored against your account.
        </p>
        {!profile ? (
          <Link href="/login?next=/quizzes" className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-sky-400 px-5 py-2.5 text-sm font-semibold text-canvas">
            Sign in to sit an exam
          </Link>
        ) : null}
      </header>

      <div className="flex flex-wrap items-center gap-2">
        {tab(undefined, "All")}
        {tab("practice", "Practice quizzes")}
        {tab("exam", "Formal examinations")}
      </div>

      <div className="flex flex-wrap gap-2">
        <Link href={activeMode ? `/quizzes?mode=${activeMode}` : "/quizzes"} className={`rounded-lg px-3 py-1.5 font-mono text-[11px] ring-1 ${!course ? "bg-white/10 text-white ring-white/20" : "bg-white/5 text-slate-400 ring-white/10 hover:bg-white/10"}`}>ALL</Link>
        {courses.map((item) => (
          <Link key={item.id} href={`/quizzes?${new URLSearchParams({ ...(course === String(item.id) ? {} : { course: String(item.id) }), ...(activeMode ? { mode: activeMode } : {}) })}`} className={`rounded-lg px-3 py-1.5 font-mono text-[11px] ring-1 ${course === String(item.id) ? "bg-white/10 text-white ring-white/20" : "bg-white/5 text-slate-400 ring-white/10 hover:bg-white/10"}`}>
            {item.code}
          </Link>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/12 p-12 text-center">
          <FileQuestion className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm text-slate-400">Nothing here yet.</p>
        </div>
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2">
          {visible.map((quiz) => {
            const parent = courseMap.get(quiz.courseId);
            const isExam = quiz.mode === "exam";
            return (
              <li key={quiz.id}>
                <Link
                  href={`/quizzes/${quiz.id}`}
                  className="group flex h-full flex-col rounded-2xl border border-white/10 bg-white/[0.03] p-5 transition hover:-translate-y-0.5 hover:border-emerald-400/40 hover:bg-emerald-400/5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="rounded-md bg-white/5 px-2 py-1 font-mono text-[11px] text-slate-400">{parent?.code}</span>
                    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider ring-1 ${isExam ? "bg-amber-400/10 text-amber-300 ring-amber-400/30" : "bg-sky-400/10 text-sky-300 ring-sky-400/30"}`}>
                      {isExam ? <ShieldCheck className="h-3 w-3" /> : <Sparkles className="h-3 w-3" />}
                      {isExam ? "Examination" : "Practice"}
                    </span>
                  </div>
                  <h2 className="mt-3 text-lg font-semibold leading-snug text-white">{quiz.title}</h2>
                  {quiz.description ? <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-400">{quiz.description}</p> : null}
                  <p className="mt-4 flex flex-wrap items-center gap-3 text-xs text-slate-500">
                    {quiz.week ? <span>Week {quiz.week}</span> : null}
                    <span className="inline-flex items-center gap-1"><ClipboardCheck className="h-3.5 w-3.5" />{quiz.questionCount} questions</span>
                    <span className="inline-flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{quiz.timeLimitMinutes} min</span>
                    <span>{quiz.attemptCount} attempts</span>
                    <span>{formatDate(quiz.createdAt)}</span>
                  </p>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
