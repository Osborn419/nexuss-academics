import Link from "next/link";
import { randomInt } from "node:crypto";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft, ClipboardCheck, Clock, Info, ShieldCheck, Sparkles } from "lucide-react";
import { QuizPlayer } from "@/components/quiz-player";
import { getCourseById, getQuizById, getAttempts } from "@/lib/queries";
import { getCurrentProfile } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const quiz = await getQuizById(Number(id));
  if (!quiz) return { title: "Test not found" };
  return { title: quiz.title, description: quiz.description };
}

export default async function QuizPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const quizId = Number(id);
  if (!Number.isFinite(quizId)) notFound();

  const quiz = await getQuizById(quizId);
  if (!quiz || !quiz.published) notFound();

  // Sign-in required to sit any test — results are stored against the account.
  const profile = await getCurrentProfile();
  if (!profile) redirect(`/login?next=/quizzes/${quizId}`);

  const course = await getCourseById(quiz.courseId);
  const isExam = quiz.mode === "exam";
  const previous = isExam ? await getAttempts(quiz.id, profile.id) : [];

  // Randomise question order for every sitting (answers are always marked server-side).
  const shuffled = [...quiz.questions];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }

  return (
    <div className="space-y-8 pt-6">
      <Link
        href="/quizzes"
        className="inline-flex items-center gap-1.5 text-sm text-slate-400 transition hover:text-emerald-300"
      >
        <ArrowLeft className="h-4 w-4" /> All tests
      </Link>

      <header className="max-w-3xl">
        <p className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
          {course?.code ?? "Assessment"} ·{" "}
          {course?.track === "elective" ? "UGRC elective" : "Core course"} ·{" "}
          <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] ring-1 ${isExam ? "bg-amber-400/10 text-amber-300 ring-amber-400/30" : "bg-sky-400/10 text-sky-300 ring-sky-400/30"}`}>
            {isExam ? <ShieldCheck className="h-3 w-3" /> : <Sparkles className="h-3 w-3" />}
            {isExam ? "Formal examination" : "Practice quiz"}
          </span>
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          {quiz.title}
        </h1>
        {quiz.description ? (
          <p className="mt-3 text-base leading-relaxed text-slate-400">
            {quiz.description}
          </p>
        ) : null}

        <div className="mt-5 flex flex-wrap gap-3 text-sm text-slate-400">
          <span className="inline-flex items-center gap-2 rounded-lg bg-white/5 px-3 py-2">
            <ClipboardCheck className="h-4 w-4 text-emerald-400" />
            {quiz.questions.length} questions
          </span>
          <span className="inline-flex items-center gap-2 rounded-lg bg-white/5 px-3 py-2">
            <Clock className="h-4 w-4 text-sky-400" />
            {quiz.timeLimitMinutes} minutes
          </span>
        </div>
      </header>

      <div className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-slate-400">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-sky-400" />
        <p>
          Sitting as <span className="text-slate-200">{profile.displayName}</span> — this {isExam ? "examination" : "practice quiz"} is
          marked on the server, questions appear in a random order, and your result is saved to your profile and
          the leaderboard.
        </p>
      </div>

      {isExam && previous.length > 0 ? (
        <div className="rounded-2xl border border-sky-400/25 bg-sky-400/5 p-6 text-sm text-slate-200">
          This formal examination has already been submitted. You can review your own result, but you cannot retake it.
          <Link href={`/quizzes/${quiz.id}/result/${previous[0].id}`} className="ml-2 font-semibold text-sky-300 underline underline-offset-4">Review result</Link>
        </div>
      ) : <QuizPlayer
        quizId={quiz.id}
        title={quiz.title}
        timeLimitMinutes={quiz.timeLimitMinutes}
        courseCode={course?.code ?? ""}
        courseTitle={course?.title ?? ""}
        studentName={profile.displayName}
        modeLabel={isExam ? "Formal examination" : "Practice quiz"}
        questions={quiz.questions.map((question) => ({
          id: question.id,
          prompt: question.prompt,
          type: question.type as "single" | "multiple" | "boolean" | "short",
          options: Array.isArray(question.options) ? question.options : [],
          points: question.points,
        }))}
      />}
    </div>
  );
}
