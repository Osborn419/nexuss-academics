import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  RotateCcw,
  Trophy,
  XCircle,
} from "lucide-react";
import { redirect } from "next/navigation";
import { getAttemptById, getQuizById } from "@/lib/queries";
import { getCurrentProfile } from "@/lib/auth";
import { formatDuration, gradeLabel, percent } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Your result" };

export default async function ResultPage({
  params,
}: {
  params: Promise<{ id: string; attemptId: string }>;
}) {
  const { id, attemptId } = await params;
  const quiz = await getQuizById(Number(id));
  const attempt = await getAttemptById(Number(attemptId));
  if (!quiz || !attempt || attempt.quizId !== quiz.id) notFound();

  // Results are private to the student who sat the test (or the administrator).
  const profile = await getCurrentProfile();
  if (!profile) redirect(`/login?next=/quizzes/${id}/result/${attemptId}`);
  const isOwner = attempt.profileId !== null && attempt.profileId === profile.id;
  if (!isOwner && profile.role !== "admin") redirect("/leaderboard");

  const answers = (attempt.answers ?? {}) as Record<string, unknown>;
  const results = (attempt.results ?? {}) as Record<string, boolean>;
  const pct = percent(attempt.score, attempt.maxScore);
  const grade = gradeLabel(attempt.score, attempt.maxScore);
  const correctCount = Object.values(results).filter(Boolean).length;

  return (
    <div className="space-y-8 pt-6">
      <Link
        href="/quizzes"
        className="inline-flex items-center gap-1.5 text-sm text-slate-400 transition hover:text-emerald-300"
      >
        <ArrowLeft className="h-4 w-4" /> All tests
      </Link>

      <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-6 sm:p-10">
        <div className="flex flex-col items-center gap-6 text-center sm:flex-row sm:text-left">
          <div
            className={`grid h-32 w-32 shrink-0 place-items-center rounded-full border-4 ${
              pct >= 70
                ? "border-emerald-400/60 bg-emerald-400/10"
                : pct >= 50
                  ? "border-amber-400/60 bg-amber-400/10"
                  : "border-rose-400/60 bg-rose-400/10"
            }`}
          >
            <div>
              <p className="text-3xl font-bold text-white">{pct}%</p>
              <p className="text-xs uppercase tracking-[0.2em] text-slate-400">
                Grade {grade}
              </p>
            </div>
          </div>

          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
              {attempt.studentName}
              {attempt.track ? ` · ${attempt.track}` : ""}
            </p>
            <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">
              {quiz.title}
            </h1>
            <p className="mt-3 text-base text-slate-400">
              You scored{" "}
              <span className="font-semibold text-white">
                {attempt.score} of {attempt.maxScore}
              </span>{" "}
              — {correctCount} of {quiz.questions.length} questions correct.
            </p>

            <div className="mt-5 flex flex-wrap gap-3 text-sm text-slate-400">
              <span className="inline-flex items-center gap-2 rounded-lg bg-white/5 px-3 py-2">
                <Trophy className="h-4 w-4 text-amber-400" />
                {attempt.score} marks
              </span>
              <span className="inline-flex items-center gap-2 rounded-lg bg-white/5 px-3 py-2">
                <Clock className="h-4 w-4 text-sky-400" />
                {formatDuration(attempt.durationSeconds)}
              </span>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              {quiz.mode !== "exam" ? <Link
                href={`/quizzes/${quiz.id}`}
                className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-sky-400 px-5 py-2.5 text-sm font-semibold text-canvas transition hover:brightness-110"
              >
                <RotateCcw className="h-4 w-4" /> Retake the practice test
              </Link> : null}
              <Link
                href="/leaderboard"
                className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-5 py-2.5 text-sm font-semibold text-slate-100 transition hover:bg-white/10"
              >
                See the leaderboard
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-white">Answer review</h2>
        <p className="mt-1.5 text-sm text-slate-400">
          Read the explanation for every question — this is where the marks come
          from.
        </p>

        <ul className="mt-6 space-y-4">
          {quiz.questions.map((question, index) => {
            const key = String(question.id);
            const given = answers[key];
            const isCorrect = Boolean(results[key]);
            const correctAnswer = question.correct;

            const givenText = Array.isArray(given)
              ? given.join(", ")
              : typeof given === "boolean"
                ? String(given)
                : String(given ?? "—");

            const correctText = Array.isArray(correctAnswer)
              ? correctAnswer.join(", ")
              : typeof correctAnswer === "boolean"
                ? String(correctAnswer)
                : String(correctAnswer);

            return (
              <li
                key={question.id}
                className={`rounded-2xl border p-5 ${
                  isCorrect
                    ? "border-emerald-400/25 bg-emerald-400/5"
                    : "border-rose-400/25 bg-rose-400/5"
                }`}
              >
                <div className="flex items-start gap-3">
                  {isCorrect ? (
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-400" />
                  ) : (
                    <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-rose-400" />
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium uppercase tracking-[0.16em] text-slate-500">
                      Question {index + 1} · {question.points} point
                      {question.points === 1 ? "" : "s"}
                    </p>
                    <h3 className="mt-1.5 text-base font-semibold text-white">
                      {question.prompt}
                    </h3>

                    <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
                      <div className="rounded-xl bg-canvas/50 px-3.5 py-2.5">
                        <dt className="text-xs uppercase tracking-wide text-slate-500">
                          Your answer
                        </dt>
                        <dd
                          className={`mt-1 font-medium ${
                            isCorrect ? "text-emerald-300" : "text-rose-300"
                          }`}
                        >
                          {givenText}
                        </dd>
                      </div>
                      <div className="rounded-xl bg-canvas/50 px-3.5 py-2.5">
                        <dt className="text-xs uppercase tracking-wide text-slate-500">
                          Correct answer
                        </dt>
                        <dd className="mt-1 font-medium text-emerald-300">
                          {correctText}
                        </dd>
                      </div>
                    </dl>

                    {question.explanation ? (
                      <div className="mt-3 rounded-xl border border-white/10 bg-canvas/40 px-3.5 py-3">
                        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                          Explanation
                        </p>
                        <p className="mt-1.5 text-sm leading-relaxed text-slate-300">
                          {question.explanation}
                        </p>
                      </div>
                    ) : null}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
