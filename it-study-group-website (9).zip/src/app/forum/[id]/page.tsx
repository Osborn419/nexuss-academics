import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, MessagesSquare } from "lucide-react";
import { ReplyForm, ReportButton } from "@/components/forum-forms";
import { getCurrentProfile } from "@/lib/auth";
import { getForumReplies, getForumThread } from "@/lib/queries";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function ThreadPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const threadId = Number(id);
  if (!Number.isFinite(threadId)) notFound();

  const [profile, row] = await Promise.all([getCurrentProfile(), getForumThread(threadId)]);
  if (!row) notFound();

  const includeHidden = profile?.role === "admin";
  const replies = await getForumReplies(threadId, includeHidden);

  return (
    <div className="mx-auto max-w-3xl space-y-6 pt-6">
      <Link href="/forum" className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-emerald-300">
        <ArrowLeft className="h-4 w-4" /> All discussions
      </Link>

      <article className="rounded-2xl border border-white/10 bg-white/[0.03] p-6">
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
          {row.courseCode ? <span className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-[10px] text-emerald-300">{row.courseCode}</span> : null}
          <span>{row.authorName}</span>
          <span aria-hidden>·</span>
          <span>{formatDate(row.thread.createdAt)}</span>
          {row.thread.hidden ? <span className="rounded bg-rose-500/15 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-rose-300">hidden by admin</span> : null}
        </div>
        <h1 className="mt-3 text-2xl font-semibold tracking-tight text-white">{row.thread.title}</h1>
        <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-slate-300">{row.thread.body}</p>
        <div className="mt-4 border-t border-white/5 pt-3">
          <ReportButton threadId={row.thread.id} />
        </div>
      </article>

      <section>
        <h2 className="flex items-center gap-2 text-base font-semibold text-white"><MessagesSquare className="h-4 w-4 text-sky-400" /> {replies.length} {replies.length === 1 ? "reply" : "replies"}</h2>
        <ul className="mt-3 space-y-3">
          {replies.map(({ reply, authorName }) => (
            <li key={reply.id} className={`rounded-2xl border p-4 text-sm ${reply.hidden ? "border-rose-400/20 bg-rose-500/5" : "border-white/10 bg-white/[0.03]"}`}>
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                <span>{authorName} · {formatDate(reply.createdAt)}{reply.hidden ? " · hidden" : ""}</span>
                <ReportButton replyId={reply.id} />
              </div>
              <p className="mt-2 whitespace-pre-wrap leading-relaxed text-slate-300">{reply.body}</p>
            </li>
          ))}
        </ul>

        {profile ? (
          <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.02] p-4">
            <ReplyForm threadId={row.thread.id} />
          </div>
        ) : (
          <p className="mt-5 rounded-2xl border border-white/10 bg-white/[0.02] p-4 text-center text-sm text-slate-500">
            <Link href={`/login?next=/forum/${threadId}`} className="text-emerald-300 hover:text-emerald-200">Sign in</Link> to reply.
          </p>
        )}
      </section>
    </div>
  );
}
