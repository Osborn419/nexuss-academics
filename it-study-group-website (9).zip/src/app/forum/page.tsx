import Link from "next/link";
import { MessageSquare, MessagesSquare, Search } from "lucide-react";
import { NewThreadForm } from "@/components/forum-forms";
import { getCurrentProfile } from "@/lib/auth";
import { getCourses, getForumThreads } from "@/lib/queries";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Forum",
  description: "Course discussions shared between study group members.",
};

export default async function ForumPage({
  searchParams,
}: {
  searchParams: Promise<{ course?: string; q?: string }>;
}) {
  const { course, q } = await searchParams;
  const [profile, courses, threads] = await Promise.all([
    getCurrentProfile(),
    getCourses(),
    getForumThreads({ courseId: course ? Number(course) : undefined, query: q?.trim() || undefined }),
  ]);

  const selectClass = "rounded-xl border border-white/12 bg-canvas/70 px-3 py-2 text-sm text-white outline-none focus:border-emerald-400/60";

  return (
    <div className="space-y-6 pt-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Discussion forum</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Ask. Discuss. Help each other.</h1>
          <p className="mt-2 text-sm text-slate-400">
            Course-specific discussions between real students — searchable, moderated, and kept on the platform.
          </p>
        </div>
        {profile ? (
          <NewThreadForm courses={courses.map((c) => ({ id: c.id, code: c.code }))} />
        ) : (
          <Link href="/login?next=/forum" className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2.5 text-sm font-medium text-white ring-1 ring-white/15 hover:bg-white/15">
            Sign in to post
          </Link>
        )}
      </header>

      <form method="get" className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-48 flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input name="q" defaultValue={q ?? ""} placeholder="Search threads…" className={`${selectClass} w-full pl-9`} />
        </div>
        <select name="course" defaultValue={course ?? ""} className={selectClass}>
          <option value="">All courses</option>
          {courses.map((item) => (
            <option key={item.id} value={item.id}>{item.code}</option>
          ))}
        </select>
        <button type="submit" className="rounded-xl bg-gradient-to-r from-emerald-400 to-sky-400 px-4 py-2 text-sm font-semibold text-canvas">Search</button>
      </form>

      {threads.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/12 p-12 text-center">
          <MessagesSquare className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm text-slate-400">No threads yet. Be the first to ask a question.</p>
        </div>
      ) : (
        <ul className="divide-y divide-white/5 overflow-hidden rounded-2xl border border-white/10">
          {threads.map(({ thread, authorName, courseCode, replyCount }) => (
            <li key={thread.id}>
              <Link href={`/forum/${thread.id}`} className="flex items-center gap-4 bg-white/[0.02] px-5 py-4 transition hover:bg-white/[0.05]">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/5 text-slate-400">
                  <MessageSquare className="h-5 w-5" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-2">
                    {courseCode ? <span className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-[10px] text-emerald-300">{courseCode}</span> : <span className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-[10px] text-slate-400">GENERAL</span>}
                    <span className="truncate font-medium text-slate-100">{thread.title}</span>
                  </span>
                  <span className="mt-1 block text-xs text-slate-500">
                    {authorName} · {formatDate(thread.createdAt)} · {replyCount} {replyCount === 1 ? "reply" : "replies"}
                  </span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
