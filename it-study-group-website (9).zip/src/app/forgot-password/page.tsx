import Link from "next/link";
import { MessageCircle, KeyRound } from "lucide-react";
import { site } from "@/config/site";

export const dynamic = "force-dynamic";

export const metadata = { title: "Forgot password" };

export default function ForgotPasswordPage() {
  return (
    <div className="mx-auto max-w-md pt-14">
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 text-center sm:p-8">
        <span className="inline-grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-emerald-400 to-sky-500 text-canvas">
          <KeyRound className="h-6 w-6" />
        </span>
        <h1 className="mt-4 text-2xl font-semibold text-white">Reset your password</h1>
        <p className="mt-3 text-sm leading-relaxed text-slate-400">
          For your own security there is no public email reset — nobody can hijack your account from outside.
          Instead, message {site.ownerName.split(" ")[0]} on WhatsApp and ask for a reset link for the email you
          registered with. The link works once and expires in one hour.
        </p>
        <a href={site.contact.whatsapp} target="_blank" rel="noreferrer" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-emerald-500/15 px-5 py-3 text-sm font-semibold text-emerald-200 ring-1 ring-emerald-400/30 hover:bg-emerald-500/25">
          <MessageCircle className="h-4 w-4" /> Message {site.ownerFirstName} on WhatsApp
        </a>
        <p className="mt-6 text-xs text-slate-500">
          Remembered it? <Link href="/login" className="text-emerald-300 hover:text-emerald-200">Go back to sign in</Link>
        </p>
      </div>
    </div>
  );
}
