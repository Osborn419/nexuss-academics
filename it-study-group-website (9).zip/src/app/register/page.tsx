import { redirect } from "next/navigation";
import { UserPlus } from "lucide-react";
import { RegisterForm } from "@/components/auth-forms";
import { getCurrentProfile } from "@/lib/auth";
import { site } from "@/config/site";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Create your account",
  description: "Join the University of Ghana IT study group on Nexus Academics — free for every member of the group.",
};

export default async function RegisterPage() {
  const profile = await getCurrentProfile();
  if (profile) redirect("/dashboard");

  return (
    <div className="mx-auto max-w-md pt-14">
      <div className="mb-8 text-center">
        <span className="inline-grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-emerald-400 to-sky-500 text-canvas">
          <UserPlus className="h-6 w-6" />
        </span>
        <h1 className="mt-4 text-2xl font-semibold tracking-tight text-white">Join {site.projectName}</h1>
        <p className="mt-2 text-sm text-slate-400">Free for the {site.cohort} IT study group. One account, every course.</p>
      </div>
      <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6">
        <RegisterForm />
      </div>
    </div>
  );
}
