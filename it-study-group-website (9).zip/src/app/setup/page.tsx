import { redirect } from "next/navigation";
import { ShieldCheck } from "lucide-react";
import { SetupForm } from "@/components/auth-forms";
import { adminExists, getCurrentProfile } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = { title: "Set up administrator" };

export default async function SetupPage() {
  const [profile, hasAdmin] = await Promise.all([getCurrentProfile(), adminExists()]);
  if (profile) redirect(profile.role === "admin" ? "/admin" : "/dashboard");
  if (hasAdmin) redirect("/login?next=/admin");

  return (
    <div className="mx-auto max-w-md pt-14">
      <div className="mb-8 text-center">
        <span className="inline-grid h-12 w-12 place-items-center rounded-2xl bg-amber-400/20 text-amber-300 ring-1 ring-amber-400/30">
          <ShieldCheck className="h-6 w-6" />
        </span>
        <h1 className="mt-4 text-2xl font-semibold tracking-tight text-white">Set up the administrator</h1>
        <p className="mt-2 text-sm text-slate-400">
          One-time setup for the platform owner. Use your configured email and the private ADMIN_SETUP_TOKEN from the server environment. This page closes after the account is created.
        </p>
      </div>
      <div className="rounded-2xl border border-amber-400/25 bg-amber-400/5 p-6">
        <SetupForm />
      </div>
    </div>
  );
}
