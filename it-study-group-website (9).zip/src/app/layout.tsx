import type { ReactNode } from "react";
import type { Metadata } from "next";
import "./globals.css";
import { site } from "@/config/site";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { getCurrentProfile } from "@/lib/auth";
import { getUnreadCount } from "@/lib/queries";
import { PwaStatus } from "@/components/pwa-status";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL?.trim();

export const metadata: Metadata = {
  ...(siteUrl ? { metadataBase: new URL(siteUrl) } : {}),
  manifest: "/manifest.json",
  icons: {
    icon: [
      { url: "/icons/nexus-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/nexus-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: "/icons/nexus-192.png",
  },
  title: {
    default: `${site.projectName} · ${site.university} IT study group — by ${site.creatorName}`,
    template: `%s · ${site.projectName}`,
  },
  description: site.description,
  applicationName: site.projectName,
  authors: [{ name: site.creatorName, url: `mailto:${site.contact.email}` }],
  creator: site.creatorName,
  publisher: site.creatorName,
  keywords: [
    "Nexus Academics",
    "University of Ghana",
    "UG Legon",
    "study group",
    "DCIT 101",
    "DCIT 103",
    "DCIT 105",
    "ECON 101",
    "STAT 111",
    "UGRC 110",
    "UGRC 150",
    "past questions",
    "examination practice",
  ],
  openGraph: {
    title: `${site.projectName} · created by ${site.creatorName}`,
    description: site.description,
    siteName: site.projectName,
    type: "website",
    images: [
      {
        url: "/opengraph.jpg",
        width: 1200,
        height: 630,
        alt: `${site.projectName}: University of Ghana IT study group, created by ${site.creatorName}`,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: site.projectName,
    description: site.description,
    images: ["/opengraph.jpg"],
  },
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const profile = await getCurrentProfile();
  const unread = profile ? await getUnreadCount(profile.id) : 0;

  return (
    <html lang="en">
      <body className="min-h-screen font-sans text-slate-200 antialiased">
        <div className="pointer-events-none fixed inset-0 -z-10 grid-lines opacity-[0.35] [mask-image:radial-gradient(ellipse_at_top,black,transparent_75%)]" />
        <SiteHeader
          user={profile ? { displayName: profile.displayName, role: profile.role } : null}
          unread={unread}
        />
        <main className="mx-auto w-full max-w-7xl px-4 pb-20 pt-6 sm:px-6 lg:px-8">{children}</main>
        <SiteFooter />
        <PwaStatus />
      </body>
    </html>
  );
}
