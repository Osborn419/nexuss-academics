import { getFileWithData } from "@/lib/queries";
import { db } from "@/db";
import { materials } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { getCurrentProfile } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Types that must never render inline on our origin (script injection risk). */
const FORCE_DOWNLOAD = /^(text\/html|application\/xhtml|image\/svg|text\/xml|application\/xml|text\/javascript|application\/javascript)/i;

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const fileId = Number(id);
  if (!Number.isFinite(fileId)) {
    return new Response("Bad request", { status: 400 });
  }

  const owner = await db.select({ id: materials.id }).from(materials)
    .where(and(eq(materials.fileId, fileId), eq(materials.published, true))).limit(1);
  if (!owner[0]) {
    const profile = await getCurrentProfile();
    if (profile?.role !== "admin") return new Response("File not found", { status: 404 });
  }

  const file = await getFileWithData(fileId);
  if (!file) return new Response("File not found", { status: 404 });
  if (file.storage === "blob") {
    if (!file.publicUrl) return new Response("File storage reference is missing", { status: 410 });
    return Response.redirect(file.publicUrl, 307);
  }
  if (!file.data) return new Response("File not found", { status: 404 });

  const mimeType = file.mimeType || "application/octet-stream";
  const wantsDownload = new URL(request.url).searchParams.get("download") === "1";
  const disposition = wantsDownload || FORCE_DOWNLOAD.test(mimeType) ? "attachment" : "inline";
  const asciiName = file.filename.replace(/[^\x20-\x7E]/g, "_").replace(/["\\]/g, "");
  const body = new Uint8Array(file.data);

  return new Response(body, {
    headers: {
      "Content-Type": mimeType,
      "Content-Length": String(body.byteLength),
      "Content-Disposition": `${disposition}; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(file.filename)}`,
      "Cache-Control": "private, max-age=3600",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
