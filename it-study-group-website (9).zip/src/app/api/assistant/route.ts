import { NextResponse } from "next/server";
import { ilike, or, sql } from "drizzle-orm";
import { requireApiProfile } from "@/lib/admin-guard";
import { db } from "@/db";
import { materials, courses } from "@/db/schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const KEY = process.env.OPENAI_API_KEY || process.env.AI_API_KEY || "";
const MODEL = process.env.AI_MODEL || "gpt-4o-mini";
const BASE = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");

function keywords(text: string): string[] {
  const stop = new Set(["what", "when", "where", "which", "would", "there", "their", "about", "could", "should", "question", "explain", "please", "does", "from", "with", "that", "this", "them", "then", "than"]);
  return [...new Set(text.toLowerCase().match(/[a-z][a-z-]{3,}/g) || [])]
    .filter((word) => !stop.has(word))
    .slice(0, 6);
}

export async function POST(request: Request) {
  const { profile, response } = await requireApiProfile();
  if (response) return response;

  if (!KEY) {
    return NextResponse.json(
      {
        error: "assistant_not_configured",
        message:
          "The AI assistant is not switched on yet. The administrator needs to set OPENAI_API_KEY (or AI_API_KEY) in the server environment. Nothing is simulated — until a key is configured this feature stays off.",
      },
      { status: 503 },
    );
  }

  let payload: { question?: string; courseId?: number } = {};
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const question = (payload.question ?? "").trim().slice(0, 2000);
  if (question.length < 6) return NextResponse.json({ error: "Ask a fuller question." }, { status: 400 });

  // Ground answers in administrator-uploaded materials where possible.
  const terms = keywords(question);
  let context = "";
  if (terms.length) {
    const clauses = terms.slice(0, 4).flatMap((term) => [
      ilike(materials.title, `%${term}%`),
      ilike(materials.description, `%${term}%`),
      ilike(materials.content, `%${term}%`),
    ]);
    const rows = await db
      .select({ title: materials.title, content: materials.content, description: materials.description, courseCode: courses.code })
      .from(materials)
      .innerJoin(courses, sql`${materials.courseId} = ${courses.id}`)
      .where(or(...clauses))
      .limit(4);
    context = rows
      .map((row) => `### ${row.courseCode} — ${row.title}\n${(row.content || row.description || "").slice(0, 1800)}`)
      .join("\n\n");
  }

  const system = [
    "You are the Nexus Academics study assistant for University of Ghana Level 100 IT students.",
    "Courses: DCIT 101, DCIT 103, DCIT 105, STAT 111, ECON 101, UGRC 110 and UGRC 150.",
    "Answer clearly and briefly, in an encouraging tone. Use Ghanaian examples where natural.",
    "Prefer the course materials provided below when they are relevant; say when you are unsure.",
    "Never invent exam answers marked as official — this is revision help.",
    context ? `\nCourse materials provided by the administrator:\n${context}` : "\nNo matching course materials found — answer from general knowledge and say so.",
  ].join("\n");

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 25_000);
    const upstream = await fetch(`${BASE}/chat/completions`, {
      method: "POST",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${KEY}` },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: system },
          { role: "user", content: question },
        ],
        temperature: 0.3,
        max_tokens: 700,
      }),
    });
    clearTimeout(timer);

    if (!upstream.ok) {
      // Never forward the provider's response body: some providers echo the
      // presented API key inside error payloads.
      const status = upstream.status;
      await upstream.text().catch(() => "");
      const message =
        status === 401 || status === 403
          ? "The AI provider rejected the configured API key. The administrator must fix OPENAI_API_KEY on the server."
          : status === 429
            ? "The AI provider rate limit has been reached. Try again in a few minutes."
            : `The AI provider returned an error (HTTP ${status}). Please try again later.`;
      return NextResponse.json(
        { error: "assistant_upstream_error", message },
        { status: 502 },
      );
    }
    const data = (await upstream.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const answer = data.choices?.[0]?.message?.content?.trim();
    if (!answer) return NextResponse.json({ error: "Empty response from the AI provider." }, { status: 502 });
    return NextResponse.json({ ok: true, answer, grounded: Boolean(context) });
  } catch (error) {
    // Redact anything key-shaped before any error text can reach the browser.
    const raw = error instanceof Error ? error.message : "Could not reach the AI provider.";
    const clean = raw.replace(/sk-[A-Za-z0-9_\-*/]{6,}/g, "[redacted]").slice(0, 300);
    return NextResponse.json(
      { error: "assistant_unreachable", message: clean },
      { status: 502 },
    );
  }
}
