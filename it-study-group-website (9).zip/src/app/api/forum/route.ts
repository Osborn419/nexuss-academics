import { NextResponse } from "next/server";
import { db } from "@/db";
import { forumReplies, forumThreads, forumReports } from "@/db/schema";
import { requireApiProfile, requireApiAdmin } from "@/lib/admin-guard";
import { eq } from "drizzle-orm";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const body = (text: string, min = 1, max = 4000) =>
  text.trim().length >= min && text.trim().length <= max;

export async function POST(request: Request) {
  const kind = new URL(request.url).searchParams.get("kind") || "thread";
  const { profile, response } = await requireApiProfile();
  if (response) return response;

  let payload: { courseId?: number | null; title?: string; body?: string; threadId?: number; reason?: string; replyId?: number; threadIdRef?: number } = {};
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  if (kind === "thread") {
    const title = (payload.title ?? "").trim().slice(0, 160);
    const content = (payload.body ?? "").trim().slice(0, 4000);
    if (title.length < 4) return NextResponse.json({ error: "Give the thread a proper title." }, { status: 400 });
    if (content.length < 3) return NextResponse.json({ error: "Write a little more — what do you need?" }, { status: 400 });
    const courseId = payload.courseId ? Number(payload.courseId) : null;
    const [thread] = await db
      .insert(forumThreads)
      .values({ courseId: courseId && Number.isFinite(courseId) ? courseId : null, authorId: profile!.id, title, body: content })
      .returning({ id: forumThreads.id });
    return NextResponse.json({ ok: true, id: thread.id });
  }

  if (kind === "reply") {
    const threadId = Number(payload.threadId);
    const content = (payload.body ?? "").trim().slice(0, 4000);
    if (!Number.isFinite(threadId)) return NextResponse.json({ error: "Missing thread." }, { status: 400 });
    if (content.length < 1) return NextResponse.json({ error: "Say something first." }, { status: 400 });
    const thread = await db.select({ id: forumThreads.id }).from(forumThreads).where(eq(forumThreads.id, threadId)).limit(1);
    if (!thread[0]) return NextResponse.json({ error: "That thread does not exist." }, { status: 404 });
    const [reply] = await db
      .insert(forumReplies)
      .values({ threadId, authorId: profile!.id, body: content })
      .returning({ id: forumReplies.id });
    return NextResponse.json({ ok: true, id: reply.id });
  }

  if (kind === "report") {
    const reason = (payload.reason ?? "").trim().slice(0, 500);
    const threadId = payload.threadId ? Number(payload.threadId) : null;
    const replyId = payload.replyId ? Number(payload.replyId) : null;
    if (!threadId && !replyId) return NextResponse.json({ error: "Nothing to report." }, { status: 400 });
    await db.insert(forumReports).values({
      threadId: threadId !== null && Number.isFinite(threadId) ? threadId : null,
      replyId: replyId !== null && Number.isFinite(replyId) ? replyId : null,
      reporterId: profile!.id,
      reason: reason || "No reason given",
    });
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Unknown kind." }, { status: 400 });
}

/** Admin moderation: delete a thread/reply or dismiss a report. */
export async function DELETE(request: Request) {
  const { response } = await requireApiAdmin();
  if (response) return response;
  const params = new URL(request.url).searchParams;
  const kind = params.get("kind") || "";
  const id = Number(params.get("id"));
  if (!Number.isFinite(id)) return NextResponse.json({ error: "Missing id." }, { status: 400 });

  if (kind === "thread") await db.delete(forumThreads).where(eq(forumThreads.id, id));
  else if (kind === "reply") await db.delete(forumReplies).where(eq(forumReplies.id, id));
  else if (kind === "report") await db.update(forumReports).set({ status: "dismissed" }).where(eq(forumReports.id, id));
  else return NextResponse.json({ error: "Unknown kind." }, { status: 400 });
  return NextResponse.json({ ok: true });
}
