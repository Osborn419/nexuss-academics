import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles, passwordResetTokens } from "@/db/schema";
import { validatePassword, verifyPassword, hashPassword } from "@/lib/auth";
import { requireApiProfile } from "@/lib/admin-guard";
import { consumePasswordResetToken } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const action = new URL(request.url).searchParams.get("action") || "change";
  let payload: { password?: string; newPassword?: string; token?: string; currentPassword?: string; name?: string } = {};
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  if (action === "change") {
    const { profile, response } = await requireApiProfile();
    if (response) return response;
    const current = payload.currentPassword ?? "";
    const next = payload.newPassword ?? "";
    const rows = await db.select().from(profiles).where(eq(profiles.id, profile!.id)).limit(1);
    const full = rows[0];
    if (!full || !verifyPassword(current, full.passwordHash)) {
      return NextResponse.json({ error: "Your current password is incorrect." }, { status: 403 });
    }
    const weak = validatePassword(next);
    if (weak) return NextResponse.json({ error: weak }, { status: 400 });
    await db.update(profiles).set({ passwordHash: hashPassword(next) }).where(eq(profiles.id, full.id));
    return NextResponse.json({ ok: true });
  }

  if (action === "profile") {
    const { profile, response } = await requireApiProfile();
    if (response) return response;
    const name = (payload.name ?? "").trim().replace(/\s+/g, " ").slice(0, 60);
    if (name.length < 2) return NextResponse.json({ error: "Name is too short." }, { status: 400 });
    await db.update(profiles).set({ name, displayName: name }).where(eq(profiles.id, profile!.id));
    return NextResponse.json({ ok: true });
  }

  if (action === "reset") {
    const token = payload.token ?? "";
    const next = payload.newPassword ?? payload.password ?? "";
    if (!token) return NextResponse.json({ error: "Missing token." }, { status: 400 });
    const weak = validatePassword(next);
    if (weak) return NextResponse.json({ error: weak }, { status: 400 });
    const profileId = await consumePasswordResetToken(token);
    if (!profileId) {
      return NextResponse.json({ error: "That link is invalid or has expired." }, { status: 400 });
    }
    await db.update(profiles).set({ passwordHash: hashPassword(next) }).where(eq(profiles.id, profileId));
    // drop any other outstanding reset links for this account
    await db.delete(passwordResetTokens).where(eq(passwordResetTokens.profileId, profileId));
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Unknown action." }, { status: 400 });
}
