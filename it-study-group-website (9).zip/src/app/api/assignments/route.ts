import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { assignments, assignmentSubmissions, courses } from "@/db/schema";
import { requireApiAdmin, requireApiProfile } from "@/lib/admin-guard";
import { notifyStudents } from "@/lib/notify";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_SUBMISSION_BYTES = 25 * 1024 * 1024;
const MIME_BY_EXT: Record<string, string> = {
  pdf: "application/pdf", doc: "application/msword", docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ppt: "application/vnd.ms-powerpoint", pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  xls: "application/vnd.ms-excel", xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", txt: "text/plain", csv: "text/csv", zip: "application/zip",
};
function safeMime(filename: string, bytes: Buffer): string | null {
  const ext = filename.toLowerCase().split(".").pop() ?? "";
  const mime = MIME_BY_EXT[ext];
  if (!mime) return null;
  if (ext === "pdf" && bytes.subarray(0, 5).toString() !== "%PDF-") return null;
  if (["docx", "pptx", "xlsx", "zip"].includes(ext) && bytes.subarray(0, 2).toString() !== "PK") return null;
  if (ext === "png" && bytes.subarray(0, 8).toString("hex") !== "89504e470d0a1a0a") return null;
  if (["jpg", "jpeg"].includes(ext) && bytes.subarray(0, 3).toString("hex") !== "ffd8ff") return null;
  if (["doc", "ppt", "xls"].includes(ext) && bytes.subarray(0, 8).toString("hex") !== "d0cf11e0a1b11ae1") return null;
  return mime;
}

export async function POST(request: Request) {
  const action = new URL(request.url).searchParams.get("action") || "submit";

  if (action === "create") {
    const { profile, response } = await requireApiAdmin();
    if (response) return response;

    let payload: { courseId?: number; title?: string; description?: string; dueDate?: string; maxPoints?: number } = {};
    try {
      payload = await request.json();
    } catch {
      return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
    }
    const title = (payload.title ?? "").trim().slice(0, 200);
    const courseId = Number(payload.courseId);
    if (!title || !Number.isFinite(courseId)) {
      return NextResponse.json({ error: "Assignment needs a title and a course." }, { status: 400 });
    }
    const course = await db.select().from(courses).where(eq(courses.id, courseId)).limit(1);
    if (!course[0]) return NextResponse.json({ error: "Course not found." }, { status: 404 });

    const dueDate = payload.dueDate ? new Date(payload.dueDate) : null;
    const [created] = await db
      .insert(assignments)
      .values({
        courseId,
        title,
        description: (payload.description ?? "").trim().slice(0, 4000),
        dueDate: dueDate && !Number.isNaN(dueDate.getTime()) ? dueDate : null,
        maxPoints: Math.min(1000, Math.max(1, Math.round(payload.maxPoints ?? 100))),
        createdBy: profile!.id,
      })
      .returning({ id: assignments.id });

    await notifyStudents({
      title: `New assignment: ${title}`,
      body: `${course[0].code} assignment posted${dueDate ? ` — due ${dueDate.toUTCString().slice(5, 16)}` : ""}.`,
      link: "/assignments",
      courseId,
    });

    return NextResponse.json({ ok: true, id: created.id });
  }

  // student submission (multipart)
  const { profile, response } = await requireApiProfile();
  if (response) return response;

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: "Could not read the upload." }, { status: 400 });
  }

  const assignmentId = Number(form.get("assignmentId"));
  const note = String(form.get("note") ?? "").trim().slice(0, 1000);
  const file = form.get("file");
  if (!Number.isFinite(assignmentId)) {
    return NextResponse.json({ error: "Missing assignment." }, { status: 400 });
  }
  if (!(file instanceof File) || file.size === 0) {
    return NextResponse.json({ error: "Attach your file first." }, { status: 400 });
  }
  if (file.size > MAX_SUBMISSION_BYTES) {
    return NextResponse.json({ error: "That file is over 25 MB." }, { status: 413 });
  }

  const target = await db.select().from(assignments).where(eq(assignments.id, assignmentId)).limit(1);
  if (!target[0]) return NextResponse.json({ error: "Assignment not found." }, { status: 404 });
  if (target[0].dueDate && target[0].dueDate.getTime() < Date.now()) {
    return NextResponse.json({ error: "The submission deadline has passed." }, { status: 403 });
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const mimeType = safeMime(file.name, buffer);
  if (!mimeType) return NextResponse.json({ error: "Unsupported or invalid file. Use PDF, Office document, image, TXT, CSV or ZIP." }, { status: 400 });

  await db
    .insert(assignmentSubmissions)
    .values({
      assignmentId,
      profileId: profile!.id,
      fileName: file.name.slice(0, 200),
      mimeType,
      sizeBytes: buffer.byteLength,
      data: buffer,
      note,
      grade: null,
      feedback: null,
      submittedAt: new Date(),
      gradedAt: null,
    })
    .onConflictDoUpdate({
      target: [assignmentSubmissions.assignmentId, assignmentSubmissions.profileId],
      set: {
        fileName: file.name.slice(0, 200),
        mimeType,
        sizeBytes: buffer.byteLength,
        data: buffer,
        note,
        grade: null,
        feedback: null,
        submittedAt: new Date(),
        gradedAt: null,
      },
    });

  return NextResponse.json({ ok: true });
}

export async function PATCH(request: Request) {
  const { response } = await requireApiAdmin();
  if (response) return response;
  let payload: { submissionId?: number; grade?: number | null; feedback?: string } = {};
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const submissionId = Number(payload.submissionId);
  if (!Number.isFinite(submissionId)) return NextResponse.json({ error: "Missing submission." }, { status: 400 });

  const row = await db.select({ maxPoints: assignments.maxPoints })
    .from(assignmentSubmissions)
    .innerJoin(assignments, eq(assignmentSubmissions.assignmentId, assignments.id))
    .where(eq(assignmentSubmissions.id, submissionId)).limit(1);
  if (!row[0]) return NextResponse.json({ error: "Submission not found." }, { status: 404 });
  const grade = payload.grade === null || payload.grade === undefined ? null : Number(payload.grade);
  if (grade !== null && (!Number.isInteger(grade) || grade < 0 || grade > row[0].maxPoints)) {
    return NextResponse.json({ error: `Grade must be between 0 and ${row[0].maxPoints}.` }, { status: 400 });
  }
  await db
    .update(assignmentSubmissions)
    .set({ grade, feedback: (payload.feedback ?? "").slice(0, 4000), gradedAt: new Date() })
    .where(eq(assignmentSubmissions.id, submissionId));
  return NextResponse.json({ ok: true });
}

export async function DELETE(request: Request) {
  const { response } = await requireApiAdmin();
  if (response) return response;
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isFinite(id)) return NextResponse.json({ error: "Missing id." }, { status: 400 });
  await db.delete(assignments).where(eq(assignments.id, id));
  return NextResponse.json({ ok: true });
}
