import { NextResponse } from "next/server";
import { db } from "@/db";
import { attempts } from "@/db/schema";
import { gradeQuiz, type AnswerValue } from "@/lib/grading";
import { getQuestionsForQuiz, getQuizById } from "@/lib/queries";
import { getCurrentProfile } from "@/lib/auth";
import { and, eq } from "drizzle-orm";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const profile = await getCurrentProfile();
  if (!profile) {
    return NextResponse.json({ error: "Please sign in to sit an exam." }, { status: 401 });
  }

  let payload: {
    quizId?: number;
    studentName?: string;
    studentEmail?: string;
    track?: string;
    answers?: Record<string, AnswerValue>;
    durationSeconds?: number;
  };

  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const quizId = Number(payload.quizId);
  if (!Number.isFinite(quizId)) {
    return NextResponse.json({ error: "A quiz id is required." }, { status: 400 });
  }

  const quiz = await getQuizById(quizId);
  if (!quiz || !quiz.published) {
    return NextResponse.json({ error: "That test is not available." }, { status: 404 });
  }

  const questions = await getQuestionsForQuiz(quizId);
  if (questions.length === 0) {
    return NextResponse.json(
      { error: "That test has no questions yet." },
      { status: 400 },
    );
  }

  if (!payload.answers || typeof payload.answers !== "object" || Array.isArray(payload.answers)) {
    return NextResponse.json({ error: "Answers must be a question-to-answer object." }, { status: 400 });
  }
  const answers = payload.answers as Record<string, AnswerValue>;
  if (Object.keys(answers).length > questions.length || JSON.stringify(answers).length > 30_000) {
    return NextResponse.json({ error: "Invalid or oversized answer set." }, { status: 400 });
  }
  const allowed = new Set(questions.map((question) => String(question.id)));
  for (const [id, answer] of Object.entries(answers)) {
    if (!allowed.has(id) || (typeof answer !== "string" && typeof answer !== "boolean" && answer !== null && !Array.isArray(answer)) ||
        (typeof answer === "string" && answer.length > 500) ||
        (Array.isArray(answer) && (answer.length > 20 || answer.some((value) => typeof value !== "string" || value.length > 300)))) {
      return NextResponse.json({ error: "Invalid answer value." }, { status: 400 });
    }
  }
  if (quiz.mode === "exam") {
    const existing = await db.select({ id: attempts.id }).from(attempts)
      .where(and(eq(attempts.profileId, profile.id), eq(attempts.quizId, quizId))).limit(1);
    if (existing.length) return NextResponse.json({ error: "You have already submitted this formal examination." }, { status: 409 });
  }
  const { score, maxScore, results } = gradeQuiz(questions, answers);

  const studentName = profile.displayName;
  const studentEmail = profile.email;

  const [attempt] = await db
    .insert(attempts)
    .values({
      quizId,
      profileId: profile.id,
      studentName: studentName.slice(0, 120),
      studentEmail,
      track: (payload.track ?? "").trim().slice(0, 60),
      score,
      maxScore,
      answers,
      results,
      durationSeconds: Math.min(quiz.timeLimitMinutes * 60, Math.max(0,
        Number.isFinite(Number(payload.durationSeconds)) ? Math.round(Number(payload.durationSeconds)) : 0)), 
    })
    .returning({ id: attempts.id });

  return NextResponse.json({
    attemptId: attempt.id,
    score,
    maxScore,
    percentage: maxScore ? Math.round((score / maxScore) * 100) : 0,
  });
}
