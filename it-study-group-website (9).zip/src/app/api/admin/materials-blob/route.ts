import { NextResponse } from "next/server";
import { db } from "@/db";
import { courses, files, materials } from "@/db/schema";
import { isAdmin } from "@/lib/admin-guard";
import { detectKind } from "@/lib/materials";
import { site } from "@/config/site";
import { blobConfigured, isAllowedBlobUrl, maxUploadBytes } from "@/lib/uploads";
import { eq } from "drizzle-orm";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

function safeFileName(value: string): string {
  return value.replace(/[\\/]/g, "_").replace(/\s+/g, " ").trim().slice(0, 200);
}

function parseWeek(value: unknown): number | null {
  const week = Number(value);
  return Number.isInteger(week) && week >= 1 && week <= 30 ? week : null;
}

/** Records a file already uploaded directly from the browser to Vercel Blob. */
export async function POST(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Administrator access required." }, { status: 403 });
  }
  if (!blobConfigured()) {
    return NextResponse.json({ error: "Vercel Blob is not configured on this server." }, { status: 503 });
  }

  let payload: {
    blobUrl?: string; filename?: string; sizeBytes?: number; courseId?: number;
    title?: string; description?: string; week?: number | null;
  };
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const blobUrl = String(payload.blobUrl ?? "");
  const filename = safeFileName(String(payload.filename ?? ""));
  const size = Number(payload.sizeBytes);
  const courseId = Number(payload.courseId);
  const title = String(payload.title ?? "").trim().slice(0, 200);
  const description = String(payload.description ?? "").trim().slice(0, 2000);
  const week = parseWeek(payload.week);

  if (!filename || !title || !Number.isInteger(courseId) || courseId < 1) {
    return NextResponse.json({ error: "Filename, title and course are required." }, { status: 400 });
  }
  if (!Number.isSafeInteger(size) || size <= 0 || size > maxUploadBytes()) {
    return NextResponse.json({ error: `File must be between 1 byte and ${maxUploadBytes() / 1024 / 1024} MB.` }, { status: 400 });
  }
  if (!isAllowedBlobUrl(blobUrl)) {
    return NextResponse.json({ error: "Invalid blob URL." }, { status: 400 });
  }
  const course = await db.select({ id: courses.id }).from(courses).where(eq(courses.id, courseId)).limit(1);
  if (!course[0]) return NextResponse.json({ error: "Course not found." }, { status: 404 });

  try {
    const created = await db.transaction(async (tx) => {
      const [file] = await tx.insert(files).values({
        filename,
        mimeType: "application/octet-stream",
        sizeBytes: size,
        storage: "blob",
        publicUrl: blobUrl,
        data: null,
      }).returning({ id: files.id });
      const [material] = await tx.insert(materials).values({
        courseId,
        title,
        description,
        kind: detectKind(filename),
        week,
        fileId: file.id,
        sizeBytes: size,
        postedBy: site.ownerName,
        published: true,
      }).returning({ id: materials.id });
      return material;
    });
    return NextResponse.json({ ok: true, id: created.id });
  } catch (error) {
    console.error("blob material record failed", error);
    return NextResponse.json({ error: "Could not record the uploaded file." }, { status: 500 });
  }
}
