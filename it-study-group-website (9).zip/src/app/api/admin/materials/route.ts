import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { files, materials } from "@/db/schema";
import { isAdmin } from "@/lib/admin-guard";
import { detectKind, materialKinds, type MaterialKind } from "@/lib/materials";
import { site } from "@/config/site";
import { blobConfigured, maxUploadBytes } from "@/lib/uploads";
import { del } from "@vercel/blob";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const MIME_BY_EXT: Record<string, string> = {
  pdf: "application/pdf",
  doc: "application/msword",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ppt: "application/vnd.ms-powerpoint",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  xls: "application/vnd.ms-excel",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  csv: "text/csv",
  txt: "text/plain",
  zip: "application/zip",
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  webp: "image/webp",

};

function validatedMime(name: string, data: Buffer): string | null {
  const ext = name.toLowerCase().split(".").pop() ?? "";
  const mime = MIME_BY_EXT[ext];
  if (!mime) return null;
  const first = data.subarray(0, 8);
  if (ext === "pdf" && data.subarray(0, 5).toString() !== "%PDF-") return null;
  if (["docx", "pptx", "xlsx", "zip"].includes(ext) && data.subarray(0, 2).toString() !== "PK") return null;
  if (ext === "png" && first.toString("hex") !== "89504e470d0a1a0a") return null;
  if (["jpg", "jpeg"].includes(ext) && data.subarray(0, 3).toString("hex") !== "ffd8ff") return null;
  if (ext === "gif" && !["GIF87a", "GIF89a"].includes(data.subarray(0, 6).toString())) return null;
  if (ext === "webp" && (data.subarray(0, 4).toString() !== "RIFF" || data.subarray(8, 12).toString() !== "WEBP")) return null;
  if (["doc", "ppt", "xls"].includes(ext) && first.toString("hex") !== "d0cf11e0a1b11ae1") return null;
  return mime;
}

function parseWeek(value: FormDataEntryValue | null): number | null {
  const week = Number(value);
  if (!value || !Number.isFinite(week) || week < 1 || week > 30) return null;
  return Math.round(week);
}

export async function POST(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Not authorised." }, { status: 401 });
  }

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: "Could not read the upload." }, { status: 400 });
  }

  const courseId = Number(form.get("courseId"));
  const rawKind = String(form.get("kind") ?? "auto").trim();
  const description = String(form.get("description") ?? "").trim();
  const url = String(form.get("url") ?? "").trim();
  const content = String(form.get("content") ?? "").trim();
  const postedBy = site.ownerName;
  const week = parseWeek(form.get("week"));
  const upload = form.get("file");
  const file = upload instanceof File && upload.size > 0 ? upload : null;

  let title = String(form.get("title") ?? "").trim();
  if (!title && file) title = file.name.replace(/\.[^.]+$/, "");

  if (!title) {
    return NextResponse.json({ error: "A title is required." }, { status: 400 });
  }
  if (!Number.isFinite(courseId) || courseId <= 0) {
    return NextResponse.json({ error: "Pick a course." }, { status: 400 });
  }
  const limit = maxUploadBytes();
  if (file && file.size > limit) {
    return NextResponse.json(
      { error: `"${file.name}" is larger than ${Math.floor(limit / 1024 / 1024)} MB on this server. Configure Vercel Blob for larger files or split the upload.` },
      { status: 413 },
    );
  }
  if (file && blobConfigured()) {
    return NextResponse.json({ error: "Vercel Blob is configured; upload browser-direct instead of through this endpoint." }, { status: 400 });
  }
  if (url && !/^https?:\/\//i.test(url)) {
    return NextResponse.json({ error: "Only http(s) links are supported." }, { status: 400 });
  }
  if (!file && !url && !content) {
    return NextResponse.json(
      { error: "Add a file, a link or some written content." },
      { status: 400 },
    );
  }

  const kind =
    rawKind === "auto" || !rawKind
      ? file
        ? detectKind(file.name)
        : url
          ? "link"
          : "notes"
      : materialKinds.includes(rawKind as MaterialKind)
        ? rawKind
        : "notes";

  try {
    let fileId: number | null = null;
    let sizeBytes = 0;

    const buffer = file ? Buffer.from(await file.arrayBuffer()) : null;
    const mime = file && buffer ? validatedMime(file.name, buffer) : null;
    if (file && !mime) {
      return NextResponse.json(
        { error: "Unsupported or invalid file. Use PDF, Office document, ZIP, image, CSV or TXT." },
        { status: 400 },
      );
    }
    const material = await db.transaction(async (tx) => {
      if (file && buffer && mime) {
        const [row] = await tx.insert(files).values({
          filename: file.name.slice(0, 200),
          mimeType: mime,
          sizeBytes: buffer.byteLength,
          data: buffer,
        }).returning({ id: files.id });
        fileId = row.id;
        sizeBytes = buffer.byteLength;
      }
      const [created] = await tx.insert(materials).values({
        courseId,
        title: title.slice(0, 200),
        description: description.slice(0, 2000),
        kind,
        week,
        fileId,
        url: url || null,
        content: content || null,
        sizeBytes,
        postedBy,
      }).returning({ id: materials.id });
      return created;
    });

    return NextResponse.json({ ok: true, id: material.id, kind, week });
  } catch (error) {
    console.error("material upload failed", error);
    return NextResponse.json(
      { error: "Could not save that material. Check the course still exists and try again." },
      { status: 500 },
    );
  }
}

export async function PATCH(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Not authorised." }, { status: 401 });
  let payload: { id?: number; title?: string; description?: string; url?: string; content?: string; week?: number | null; published?: boolean };
  try { payload = await request.json(); }
  catch { return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 }); }
  const id = Number(payload.id);
  if (!Number.isInteger(id) || id < 1) return NextResponse.json({ error: "Invalid material id." }, { status: 400 });
  const existing = await db.select({ id: materials.id }).from(materials).where(eq(materials.id, id)).limit(1);
  if (!existing[0]) return NextResponse.json({ error: "Material not found." }, { status: 404 });
  if (payload.url && !/^https?:\/\//i.test(payload.url)) {
    return NextResponse.json({ error: "Only http(s) links are supported." }, { status: 400 });
  }
  const week = payload.week === null || payload.week === undefined || payload.week === 0 ? null : Number(payload.week);
  if (week !== null && (!Number.isInteger(week) || week < 1 || week > 30)) {
    return NextResponse.json({ error: "Week must be between 1 and 30." }, { status: 400 });
  }
  if (typeof payload.title !== "string" || payload.title.trim().length < 2) {
    return NextResponse.json({ error: "A title is required." }, { status: 400 });
  }
  await db.update(materials).set({
    title: payload.title.trim().slice(0, 200),
    description: String(payload.description ?? "").trim().slice(0, 2000),
    url: payload.url?.trim() || null,
    content: typeof payload.content === "string" ? payload.content.slice(0, 500_000) || null : undefined,
    week,
    published: payload.published === true,
  }).where(eq(materials.id, id));
  return NextResponse.json({ ok: true });
}

export async function DELETE(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Not authorised." }, { status: 401 });
  }

  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isFinite(id)) {
    return NextResponse.json({ error: "A material id is required." }, { status: 400 });
  }

  const rows = await db
    .select({ id: materials.id, fileId: materials.fileId })
    .from(materials)
    .where(eq(materials.id, id))
    .limit(1);
  const material = rows[0];
  if (!material) {
    return NextResponse.json({ error: "Material not found." }, { status: 404 });
  }

  const fileRows = material.fileId
    ? await db.select({ storage: files.storage, publicUrl: files.publicUrl, filename: files.filename })
        .from(files).where(eq(files.id, material.fileId)).limit(1)
    : [];

  await db.delete(materials).where(eq(materials.id, id));
  if (material.fileId) {
    await db.delete(files).where(eq(files.id, material.fileId));
  }
  const fileRow = fileRows[0];
  if (fileRow?.storage === "blob" && fileRow.publicUrl) {
    try { await del(fileRow.publicUrl); } catch (error) {
      // Do not fail a local deletion if the remote cleanup is temporarily unavailable.
      console.error("Could not delete Vercel Blob file", fileRow.filename, error);
    }
  }

  return NextResponse.json({ ok: true });
}
