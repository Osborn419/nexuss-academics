import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { courses } from "@/db/schema";
import { isAdmin } from "@/lib/admin-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Not authorised." }, { status: 401 });
  }

  const payload = (await request.json()) as {
    id?: number;
    code?: string;
    title?: string;
    summary?: string;
    description?: string;
    track?: string;
    level?: number;
    credits?: number;
    accent?: string;
    icon?: string;
  };

  const code = (payload.code ?? "").trim().toUpperCase();
  const title = (payload.title ?? "").trim();
  if (!code || !title) {
    return NextResponse.json(
      { error: "Course code and title are required." },
      { status: 400 },
    );
  }

  const values = {
    code,
    title: title.slice(0, 200),
    summary: (payload.summary ?? "").slice(0, 500),
    description: (payload.description ?? "").slice(0, 4000),
    track: payload.track === "elective" ? "elective" : "core",
    level: Math.min(900, Math.max(100, Math.round(payload.level ?? 100))),
    credits: Math.min(12, Math.max(1, Math.round(payload.credits ?? 3))),
    accent: payload.accent ?? "emerald",
    icon: payload.icon ?? "book-open",
  };

  if (payload.id) {
    await db.update(courses).set(values).where(eq(courses.id, payload.id));
    return NextResponse.json({ ok: true, id: payload.id });
  }

  const [created] = await db.insert(courses).values(values).returning({
    id: courses.id,
  });
  return NextResponse.json({ ok: true, id: created.id });
}

export async function DELETE(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Not authorised." }, { status: 401 });
  }

  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isFinite(id)) {
    return NextResponse.json({ error: "A course id is required." }, { status: 400 });
  }

  await db.delete(courses).where(eq(courses.id, id));
  return NextResponse.json({ ok: true });
}
