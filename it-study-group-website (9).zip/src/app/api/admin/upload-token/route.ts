import { NextResponse } from "next/server";
import { handleUpload, type HandleUploadBody } from "@vercel/blob/client";
import { isAdmin } from "@/lib/admin-guard";
import { blobConfigured, maxUploadBytes } from "@/lib/uploads";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

const ALLOWED_CONTENT_TYPES = [
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "text/csv",
  "text/plain",
  "application/zip",
  "image/png",
  "image/jpeg",
  "image/gif",
  "image/webp",
];

/** Issues a short-lived token for browser-to-Blob uploads. It never exposes the read-write token. */
export async function POST(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Administrator access required." }, { status: 403 });
  }
  if (!blobConfigured()) {
    return NextResponse.json({ error: "Vercel Blob is not configured on this server." }, { status: 503 });
  }

  try {
    const body = (await request.json()) as HandleUploadBody;
    const result = await handleUpload({
      body,
      request,
      onBeforeGenerateToken: async () => ({
        allowedContentTypes: ALLOWED_CONTENT_TYPES,
        maxUploadSize: maxUploadBytes(),
        addRandomSuffix: true,
        tokenExpirationInSeconds: 600,
      }),
      onUploadCompleted: async () => {
        // The browser confirms the resulting URL through /api/admin/materials-blob.
        // Keeping DB writes out of this callback avoids localhost webhook races.
      },
    });
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not start the upload." },
      { status: 400 },
    );
  }
}
