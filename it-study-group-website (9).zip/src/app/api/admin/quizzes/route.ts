import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { questions, quizzes, courses } from "@/db/schema";
import { isAdmin } from "@/lib/admin-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface IncomingQuestion {
  prompt?: string;
  type?: string;
  options?: string[];
  correct?: string | string[] | boolean;
  explanation?: string;
  points?: number;
}

export async function POST(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Not authorised." }, { status: 401 });
  let payload: {
    courseId?: number; title?: string; description?: string; timeLimitMinutes?: number;
    published?: boolean; week?: number | null; mode?: string; questions?: IncomingQuestion[];
  };
  try { payload = await request.json(); }
  catch { return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 }); }

  const title = typeof payload.title === "string" ? payload.title.trim().slice(0, 200) : "";
  const courseId = Number(payload.courseId);
  if (!title || !Number.isInteger(courseId) || courseId < 1) {
    return NextResponse.json({ error: "Choose a course and enter a title." }, { status: 400 });
  }
  const course = await db.select({ id: courses.id }).from(courses).where(eq(courses.id, courseId)).limit(1);
  if (!course[0]) return NextResponse.json({ error: "Course not found." }, { status: 404 });
  const minutes = Number(payload.timeLimitMinutes ?? 15);
  if (!Number.isInteger(minutes) || minutes < 1 || minutes > 180) {
    return NextResponse.json({ error: "Duration must be 1–180 minutes." }, { status: 400 });
  }
  if (!Array.isArray(payload.questions) || payload.questions.length < 1 || payload.questions.length > 100) {
    return NextResponse.json({ error: "Add 1–100 questions." }, { status: 400 });
  }
  const validated: { prompt: string; type: string; options: string[]; correct: string | string[] | boolean; explanation: string; points: number; position: number }[] = [];
  for (const [index, question] of payload.questions.entries()) {
    if (!question || typeof question !== "object") return NextResponse.json({ error: `Question ${index + 1} is invalid.` }, { status: 400 });
    const prompt = typeof question.prompt === "string" ? question.prompt.trim().slice(0, 1000) : "";
    const type = question.type;
    const points = Number(question.points ?? 1);
    const options = Array.isArray(question.options) ? question.options.map((value) => String(value).trim()) : [];
    const correct = question.correct;
    if (!prompt || !["single", "multiple", "boolean", "short"].includes(type ?? "") ||
        !Number.isInteger(points) || points < 1 || points > 20) {
      return NextResponse.json({ error: `Question ${index + 1} needs a prompt, type and 1–20 points.` }, { status: 400 });
    }
    if (["single", "multiple"].includes(type!) &&
        (options.length < 2 || options.length > 10 || options.some((value) => !value || value.length > 300) || new Set(options).size !== options.length)) {
      return NextResponse.json({ error: `Question ${index + 1} needs 2–10 distinct non-empty options.` }, { status: 400 });
    }
    if (type === "single" && (typeof correct !== "string" || !options.includes(correct))) {
      return NextResponse.json({ error: `Select a valid correct answer for question ${index + 1}.` }, { status: 400 });
    }
    if (type === "multiple" && (!Array.isArray(correct) || correct.length < 1 ||
        correct.some((value) => typeof value !== "string" || !options.includes(value)) || new Set(correct).size !== correct.length)) {
      return NextResponse.json({ error: `Select valid correct answers for question ${index + 1}.` }, { status: 400 });
    }
    if (type === "boolean" && typeof correct !== "boolean") {
      return NextResponse.json({ error: `Choose true or false for question ${index + 1}.` }, { status: 400 });
    }
    if (type === "short" &&
        !(typeof correct === "string" && correct.trim() || Array.isArray(correct) && correct.length > 0 && correct.every((value) => typeof value === "string" && value.trim()))) {
      return NextResponse.json({ error: `Enter at least one accepted answer for question ${index + 1}.` }, { status: 400 });
    }
    validated.push({ prompt, type: type!, options, correct: correct!,
      explanation: typeof question.explanation === "string" ? question.explanation.slice(0, 2000) : "",
      points, position: index });
  }

  const quizId = await db.transaction(async (tx) => {
    const [quiz] = await tx.insert(quizzes).values({
      courseId, title, description: typeof payload.description === "string" ? payload.description.slice(0, 2000) : "",
      week: payload.week && Number.isInteger(Number(payload.week)) ? Math.min(30, Math.max(1, Number(payload.week))) : null,
      mode: payload.mode === "exam" ? "exam" : "practice", timeLimitMinutes: minutes,
      published: payload.published !== false,
    }).returning({ id: quizzes.id });
    await tx.insert(questions).values(validated.map((question) => ({ ...question, quizId: quiz.id })));
    return quiz.id;
  });
  return NextResponse.json({ ok: true, id: quizId });
}

export async function DELETE(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Not authorised." }, { status: 401 });
  }

  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isFinite(id)) {
    return NextResponse.json({ error: "A quiz id is required." }, { status: 400 });
  }

  await db.delete(quizzes).where(eq(quizzes.id, id));

  return NextResponse.json({ ok: true });
}

export async function PATCH(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Not authorised." }, { status: 401 });
  }

  const payload = (await request.json()) as {
    id?: number;
    published?: boolean;
    title?: string;
  };
  const id = Number(payload.id);
  if (!Number.isFinite(id)) {
    return NextResponse.json({ error: "A quiz id is required." }, { status: 400 });
  }

  await db
    .update(quizzes)
    .set({
      published: payload.published,
      title: payload.title?.slice(0, 200),
    })
    .where(and(eq(quizzes.id, id)));

  return NextResponse.json({ ok: true });
}
