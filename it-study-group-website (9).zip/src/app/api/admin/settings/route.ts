import { NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { isAdmin } from "@/lib/admin-guard";
import { mondayOf, parseISODate, toISODate } from "@/lib/semester";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Not authorised." }, { status: 401 });
  }

  let payload: { semesterStart?: string; semesterWeeks?: number; semesterLabel?: string };
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const updates: Record<string, string> = {};

  if (payload.semesterStart !== undefined) {
    const date = parseISODate(String(payload.semesterStart));
    if (!date) {
      return NextResponse.json({ error: "Use a valid date (YYYY-MM-DD)." }, { status: 400 });
    }
    // Weeks always begin on a Monday.
    updates.semester_start = toISODate(mondayOf(date));
  }

  if (payload.semesterWeeks !== undefined) {
    const weeks = Math.round(Number(payload.semesterWeeks));
    if (!Number.isFinite(weeks) || weeks < 1 || weeks > 26) {
      return NextResponse.json(
        { error: "Teaching weeks must be between 1 and 26." },
        { status: 400 },
      );
    }
    updates.semester_weeks = String(weeks);
  }

  if (payload.semesterLabel !== undefined) {
    const label = String(payload.semesterLabel).trim().slice(0, 80);
    if (label) updates.semester_label = label;
  }

  for (const [key, value] of Object.entries(updates)) {
    await db
      .insert(settings)
      .values({ key, value })
      .onConflictDoUpdate({
        target: settings.key,
        set: { value, updatedAt: new Date() },
      });
  }

  return NextResponse.json({ ok: true, updated: updates });
}
