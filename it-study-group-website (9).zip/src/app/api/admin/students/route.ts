import { NextResponse } from "next/server";
import { and, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { passwordResetTokens, profiles } from "@/db/schema";
import { requireApiAdmin } from "@/lib/admin-guard";
import { createPasswordResetToken } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Issue a one-time password reset link for a student. Shown once, valid 1 hour. */
export async function POST(request: Request) {
  const { profile, response } = await requireApiAdmin();
  if (response) return response;

  let payload: { profileId?: number } = {};
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const targetId = Number(payload.profileId);
  if (!Number.isFinite(targetId)) return NextResponse.json({ error: "Missing student." }, { status: 400 });

  const rows = await db.select().from(profiles).where(eq(profiles.id, targetId)).limit(1);
  const target = rows[0];
  if (!target) return NextResponse.json({ error: "Student not found." }, { status: 404 });

  const token = await createPasswordResetToken(target.id);
  return NextResponse.json({ ok: true, path: `/reset?token=${token}` });
}

export async function DELETE(request: Request) {
  const { profile, response } = await requireApiAdmin();
  if (response) return response;
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isFinite(id)) return NextResponse.json({ error: "Missing id." }, { status: 400 });
  if (id === profile!.id) return NextResponse.json({ error: "You cannot delete your own administrator account." }, { status: 400 });

  const target = await db.select().from(profiles).where(eq(profiles.id, id)).limit(1);
  if (!target[0]) return NextResponse.json({ error: "Not found." }, { status: 404 });
  if (target[0].role === "admin") {
    return NextResponse.json({ error: "Refusing to delete another administrator." }, { status: 400 });
  }
  await db.delete(profiles).where(eq(profiles.id, id));
  return NextResponse.json({ ok: true });
}
