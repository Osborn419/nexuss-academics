import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  bookmarks,
  courseProgress,
  enrolments,
  notifications,
} from "@/db/schema";
import { requireApiProfile } from "@/lib/admin-guard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Current server truth for this student. Used by the client after a sync
 * conflict so the UI shows the newest online state instead of the stale
 * offline intent.
 */
export async function GET() {
  const { profile, response } = await requireApiProfile();
  if (response) return response;

  const [progressRows, bookmarkRows] = await Promise.all([
    db
      .select({ courseId: courseProgress.courseId, week: courseProgress.week })
      .from(courseProgress)
      .where(eq(courseProgress.profileId, profile!.id)),
    db
      .select({ materialId: bookmarks.materialId })
      .from(bookmarks)
      .where(eq(bookmarks.profileId, profile!.id)),
  ]);

  return NextResponse.json({
    progress: progressRows.map((row) => `${row.courseId}:${row.week}`),
    bookmarks: bookmarkRows.map((row) => row.materialId),
  });
}

/** Toggle/state endpoints for the signed-in student. */
export async function POST(request: Request) {
  const action = new URL(request.url).searchParams.get("action") || "";
  const { profile, response } = await requireApiProfile();
  if (response) return response;

  let payload: {
    courseId?: number;
    week?: number;
    materialId?: number;
    clientUpdatedAt?: string;
  } = {};
  try {
    const text = await request.text();
    if (text.trim()) payload = JSON.parse(text) as typeof payload;
  } catch {
    // actions that take no body (e.g. notifications-read) send nothing
  }

  if (action === "enrol") {
    const courseId = Number(payload.courseId);
    if (!Number.isFinite(courseId)) return NextResponse.json({ error: "Missing course." }, { status: 400 });
    const existing = await db
      .select({ id: enrolments.id })
      .from(enrolments)
      .where(and(eq(enrolments.profileId, profile!.id), eq(enrolments.courseId, courseId)))
      .limit(1);
    if (existing.length) {
      await db.delete(enrolments).where(and(eq(enrolments.profileId, profile!.id), eq(enrolments.courseId, courseId)));
      return NextResponse.json({ ok: true, enrolled: false });
    }
    await db.insert(enrolments).values({ profileId: profile!.id, courseId });
    return NextResponse.json({ ok: true, enrolled: true });
  }

  if (action === "progress") {
    const courseId = Number(payload.courseId);
    const week = Number(payload.week);
    if (!Number.isFinite(courseId) || !Number.isFinite(week)) {
      return NextResponse.json({ error: "Missing course or week." }, { status: 400 });
    }
    const clientAt = payload.clientUpdatedAt ? new Date(payload.clientUpdatedAt) : null;
    if (clientAt && Number.isNaN(clientAt.getTime())) {
      return NextResponse.json({ error: "Invalid sync timestamp." }, { status: 400 });
    }
    const existing = await db
      .select({ id: courseProgress.id, updatedAt: courseProgress.updatedAt })
      .from(courseProgress)
      .where(and(eq(courseProgress.profileId, profile!.id), eq(courseProgress.courseId, courseId), eq(courseProgress.week, week)))
      .limit(1);
    const row = existing[0];
    if (row) {
      // A newer server value means another device changed it after this action
      // was made offline. Keep the server value instead of overwriting it.
      if (clientAt && row.updatedAt.getTime() > clientAt.getTime() + 1000) {
        return NextResponse.json(
          { error: "conflict", server: { completed: true, updatedAt: row.updatedAt.toISOString() } },
          { status: 409 },
        );
      }
      await db.delete(courseProgress).where(eq(courseProgress.id, row.id));
      return NextResponse.json({ ok: true, completed: false });
    }
    await db.insert(courseProgress).values({ profileId: profile!.id, courseId, week, updatedAt: new Date() });
    return NextResponse.json({ ok: true, completed: true });
  }

  if (action === "bookmark") {
    const materialId = Number(payload.materialId);
    if (!Number.isFinite(materialId)) return NextResponse.json({ error: "Missing material." }, { status: 400 });
    const clientAt = payload.clientUpdatedAt ? new Date(payload.clientUpdatedAt) : null;
    if (clientAt && Number.isNaN(clientAt.getTime())) {
      return NextResponse.json({ error: "Invalid sync timestamp." }, { status: 400 });
    }
    const conflictResponse = (server: Record<string, unknown>) =>
      NextResponse.json({ error: "conflict", server }, { status: 409 });
    const existing = await db
      .select({ id: bookmarks.id, updatedAt: bookmarks.updatedAt })
      .from(bookmarks)
      .where(and(eq(bookmarks.profileId, profile!.id), eq(bookmarks.materialId, materialId)))
      .limit(1);
    const row = existing[0];
    if (row) {
      if (clientAt && row.updatedAt.getTime() > clientAt.getTime() + 1000) {
        return conflictResponse({ bookmarked: true, updatedAt: row.updatedAt.toISOString() });
      }
      await db.delete(bookmarks).where(eq(bookmarks.id, row.id));
      return NextResponse.json({ ok: true, bookmarked: false });
    }
    await db.insert(bookmarks).values({ profileId: profile!.id, materialId, updatedAt: new Date() });
    return NextResponse.json({ ok: true, bookmarked: true });
  }

  if (action === "notifications-read") {
    await db.update(notifications).set({ read: true }).where(eq(notifications.profileId, profile!.id));
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Unknown action." }, { status: 400 });
}
