import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { site } from "@/config/site";
import {
  SESSION_COOKIE,
  adminExists,
  createSession,
  destroySession,
  displayNameFor,
  hashPassword,
  normaliseEmail,
  validatePassword,
  verifyPassword,
} from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function cookieOptions(request: Request) {
  const protocol = request.headers.get("x-forwarded-proto")?.split(",")[0]?.trim() || new URL(request.url).protocol.replace(":", "");
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    path: "/",
    maxAge: 30 * 86_400,
    secure: protocol === "https",
  };
}

function sameSecret(provided: string, expected: string): boolean {
  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function POST(request: Request) {
  const action = new URL(request.url).searchParams.get("action") || "login";

  // Logout works with the empty body sent by the navigation controls.
  if (action === "logout") {
    const cookieStore = await cookies();
    await destroySession(cookieStore.get(SESSION_COOKIE)?.value);
    cookieStore.delete(SESSION_COOKIE);
    return NextResponse.json({ ok: true });
  }

  let payload: { name?: unknown; email?: unknown; password?: unknown; setupToken?: unknown } = {};
  try {
    payload = await request.json();
    if (!payload || typeof payload !== "object") throw new Error("Invalid payload");
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const email = normaliseEmail(typeof payload.email === "string" ? payload.email : "");
  const password = typeof payload.password === "string" ? payload.password : "";

  if (action === "register") {
    const name = displayNameFor(typeof payload.name === "string" ? payload.name : "");
    if (name.length < 2) return NextResponse.json({ error: "Please enter your full name." }, { status: 400 });
    if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
    }
    const weak = validatePassword(password);
    if (weak) return NextResponse.json({ error: weak }, { status: 400 });

    try {
      const [profile] = await db
        .insert(profiles)
        .values({ name, email, displayName: name, passwordHash: hashPassword(password), role: "student" })
        .returning({ id: profiles.id });
      const cookieStore = await cookies();
      cookieStore.set(SESSION_COOKIE, await createSession(profile.id), cookieOptions(request));
      return NextResponse.json({ ok: true, redirect: "/dashboard" });
    } catch (error) {
      if (typeof error === "object" && error && "code" in error && error.code === "23505") {
        return NextResponse.json({ error: "An account already exists for that email. Try signing in." }, { status: 409 });
      }
      throw error;
    }
  }

  if (action === "setup") {
    if (await adminExists()) {
      return NextResponse.json({ error: "An administrator account already exists. Please sign in instead." }, { status: 403 });
    }
    const expected = process.env.ADMIN_SETUP_TOKEN?.trim();
    if (!expected || expected.length < 32) {
      return NextResponse.json({ error: "Owner setup is not configured. Set a long ADMIN_SETUP_TOKEN on the server first." }, { status: 503 });
    }
    const provided = typeof payload.setupToken === "string" ? payload.setupToken : "";
    if (!sameSecret(provided, expected)) {
      return NextResponse.json({ error: "Invalid owner setup token." }, { status: 403 });
    }
    const allowedEmails = [site.contact.email, site.contact.schoolEmail].map(normaliseEmail);
    if (!allowedEmails.includes(email)) {
      return NextResponse.json({ error: "Only the configured owner's email can set up the administrator." }, { status: 403 });
    }
    const name = displayNameFor(typeof payload.name === "string" ? payload.name : "");
    if (name.length < 2) return NextResponse.json({ error: "Please enter your full name." }, { status: 400 });
    const weak = validatePassword(password);
    if (weak) return NextResponse.json({ error: weak }, { status: 400 });

    try {
      const [profile] = await db
        .insert(profiles)
        .values({ name, email, displayName: name, passwordHash: hashPassword(password), role: "admin" })
        .returning({ id: profiles.id });
      const cookieStore = await cookies();
      cookieStore.set(SESSION_COOKIE, await createSession(profile.id), cookieOptions(request));
      return NextResponse.json({ ok: true, redirect: "/admin" });
    } catch (error) {
      if (typeof error === "object" && error && "code" in error && error.code === "23505") {
        return NextResponse.json({ error: "An account already exists for this email or an administrator has already been created." }, { status: 409 });
      }
      throw error;
    }
  }

  if (action === "login") {
    const rows = await db.select().from(profiles).where(eq(profiles.email, email)).limit(1);
    const profile = rows[0];
    if (!profile || !verifyPassword(password, profile.passwordHash)) {
      return NextResponse.json({ error: "Incorrect email or password." }, { status: 401 });
    }
    const cookieStore = await cookies();
    cookieStore.set(SESSION_COOKIE, await createSession(profile.id), cookieOptions(request));
    return NextResponse.json({ ok: true, redirect: profile.role === "admin" ? "/admin" : "/dashboard" });
  }

  return NextResponse.json({ error: "Unknown action." }, { status: 400 });
}
