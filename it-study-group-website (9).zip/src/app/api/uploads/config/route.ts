import { NextResponse } from "next/server";
import { maxUploadBytes, uploadMode } from "@/lib/uploads";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({
    mode: uploadMode(),
    maxBytes: maxUploadBytes(),
    directToBlob: uploadMode() === "blob",
  });
}
