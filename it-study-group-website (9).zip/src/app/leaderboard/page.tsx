import Link from "next/link";
import { Crown, Medal, Trophy, Users } from "lucide-react";
import { getCourses, getQuizzes } from "@/lib/queries";
import { db } from "@/db";
import { attempts as attemptTable, profiles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { formatDuration, percent } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Leaderboard",
  description: "Rankings from real, account-linked exam attempts.",
};

export default async function LeaderboardPage({
  searchParams,
}: {
  searchParams: Promise<{ course?: string }>;
}) {
  const { course } = await searchParams;
  const [attempts, quizzes, courses] = await Promise.all([
    db.select({
      id: attemptTable.id,
      quizId: attemptTable.quizId,
      profileId: profiles.id,
      studentName: profiles.displayName,
      score: attemptTable.score,
      maxScore: attemptTable.maxScore,
      durationSeconds: attemptTable.durationSeconds,
    }).from(attemptTable).innerJoin(profiles, eq(attemptTable.profileId, profiles.id)),
    getQuizzes(),
    getCourses(),
  ]);

  const quizMap = new Map(quizzes.map((quiz) => [quiz.id, quiz]));
  const courseMap = new Map(courses.map((item) => [item.id, item]));
  const courseId = course ? Number(course) : undefined;
  const filtered = courseId ? attempts.filter((attempt) => quizMap.get(attempt.quizId)?.courseId === courseId) : attempts;

  const totals = new Map<number, { name: string; score: number; max: number; quizzes: number; seconds: number }>();
  for (const attempt of filtered) {
    const current = totals.get(attempt.profileId) ?? { name: attempt.studentName, score: 0, max: 0, quizzes: 0, seconds: 0 };
    current.score += attempt.score;
    current.max += attempt.maxScore;
    current.quizzes += 1;
    current.seconds += attempt.durationSeconds;
    totals.set(attempt.profileId, current);
  }

  const standings = [...totals.entries()]
    .map(([id, value]) => ({
      id, name: value.name,
      score: value.score,
      max: value.max,
      quizzes: value.quizzes,
      avg: percent(value.score, value.max),
      seconds: value.seconds,
    }))
    .sort((a, b) => b.avg - a.avg || b.score - a.score);

  const perQuiz = quizzes
    .filter((quiz) => !courseId || quiz.courseId === courseId)
    .map((quiz) => ({
      quiz,
      rows: filtered
        .filter((attempt) => attempt.quizId === quiz.id)
        .sort((a, b) => b.score - a.score || a.durationSeconds - b.durationSeconds)
        .slice(0, 5),
    }))
    .filter((entry) => entry.rows.length > 0);

  const chip = (value: string | undefined, label: string) => {
    const active = (course ?? "") === (value ?? "");
    return (
      <Link
        key={label}
        href={value ? `/leaderboard?course=${value}` : "/leaderboard"}
        className={`rounded-lg px-3 py-2 text-xs font-medium ring-1 transition ${
          active ? "bg-white/10 text-white ring-white/20" : "bg-white/5 text-slate-400 ring-white/10 hover:bg-white/10"
        }`}
      >
        {label}
      </Link>
    );
  };

  return (
    <div className="space-y-10 pt-6">
      <header className="max-w-3xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Leaderboard</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">Who keeps the group sharp</h1>
        <p className="mt-3 text-base leading-relaxed text-slate-400">
          Rankings from real attempts only — each test is marked on the server against your account.
          Display names are shown; no emails or private details.
        </p>
      </header>

      <div className="flex flex-wrap gap-2">
        {chip(undefined, "Overall")}
        {courses.map((item) => chip(String(item.id), item.code))}
      </div>

      {standings.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/12 p-12 text-center">
          <Users className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm text-slate-400">No ranked attempts yet — the board fills as students sit the tests.</p>
          <Link href="/quizzes" className="mt-4 inline-block rounded-xl bg-gradient-to-r from-emerald-400 to-sky-400 px-5 py-2.5 text-sm font-semibold text-canvas">
            Open the exams
          </Link>
        </div>
      ) : (
        <>
          <section>
            <h2 className="text-xl font-semibold text-white">Standings</h2>
            <div className="mt-5 overflow-x-auto rounded-2xl border border-white/10">
              <table className="w-full min-w-[36rem] text-left text-sm">
                <thead className="bg-white/[0.04] text-xs uppercase tracking-wide text-slate-400">
                  <tr>
                    <th className="px-4 py-3 font-medium">#</th>
                    <th className="px-4 py-3 font-medium">Student</th>
                    <th className="px-4 py-3 font-medium">Tests</th>
                    <th className="px-4 py-3 font-medium">Marks</th>
                    <th className="px-4 py-3 font-medium">Average</th>
                    <th className="hidden px-4 py-3 font-medium sm:table-cell">Time spent</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {standings.map((row, index) => (
                    <tr key={row.id} className="bg-white/[0.02]">
                      <td className="px-4 py-3">
                        {index === 0 ? <Crown className="h-4 w-4 text-amber-400" /> : index === 1 ? <Medal className="h-4 w-4 text-slate-300" /> : index === 2 ? <Medal className="h-4 w-4 text-orange-400/80" /> : <span className="text-slate-500">{index + 1}</span>}
                      </td>
                      <td className="px-4 py-3 font-medium text-white">{row.name}</td>
                      <td className="px-4 py-3 text-slate-400">{row.quizzes}</td>
                      <td className="px-4 py-3 text-slate-400">{row.score}/{row.max}</td>
                      <td className="px-4 py-3">
                        <span className={`font-semibold ${row.avg >= 70 ? "text-emerald-300" : row.avg >= 50 ? "text-amber-300" : "text-rose-300"}`}>{row.avg}%</span>
                      </td>
                      <td className="hidden px-4 py-3 text-slate-500 sm:table-cell">{formatDuration(row.seconds)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white">Best per test</h2>
            <div className="mt-5 space-y-4">
              {perQuiz.map(({ quiz, rows }) => (
                <div key={quiz.id} className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="font-semibold text-white">{quiz.title}</h3>
                    <span className="rounded-md bg-white/5 px-2 py-1 font-mono text-[11px] text-slate-400">{courseMap.get(quiz.courseId)?.code}</span>
                  </div>
                  <ol className="mt-4 space-y-2">
                    {rows.map((row, index) => (
                      <li key={row.id} className="flex items-center justify-between gap-3 rounded-xl bg-canvas/40 px-3.5 py-2.5">
                        <span className="flex items-center gap-2.5">
                          <span className="grid h-6 w-6 place-items-center rounded-lg bg-white/5 text-[11px] font-semibold text-slate-400">{index + 1}</span>
                          <span className="text-sm text-slate-200">{row.studentName}</span>
                        </span>
                        <span className="flex items-center gap-3 text-xs text-slate-400">
                          <span>{formatDuration(row.durationSeconds)}</span>
                          <span className="font-semibold text-emerald-300">{row.score}/{row.maxScore}</span>
                        </span>
                      </li>
                    ))}
                  </ol>
                  <Link href={`/quizzes/${quiz.id}`} className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-emerald-300 hover:text-emerald-200">
                    <Trophy className="h-4 w-4" /> Sit this test
                  </Link>
                </div>
              ))}
            </div>
          </section>
        </>
      )}
    </div>
  );
}
