import Link from "next/link";
import Image from "next/image";
import {
  ArrowRight,
  BookMarked,
  CalendarDays,
  ClipboardCheck,
  FileStack,
  GraduationCap,
  Layers,
  Sparkles,
  Trophy,
  Users,
} from "lucide-react";
import { site } from "@/config/site";
import { CourseCard } from "@/components/course-card";
import { MaterialRow } from "@/components/material-row";
import { ContactButtons } from "@/components/contact-buttons";
import { WeekStatusCard } from "@/components/week-status";
import {
  getAllMaterials,
  getAnnouncements,
  getCourses,
  getMaterialsByWeek,
  getQuizzes,
  getSemesterConfig,
  getSiteStats,
} from "@/lib/queries";
import { getSemesterStatus } from "@/lib/semester";
import { initials } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const semester = await getSemesterConfig();
  const status = getSemesterStatus(semester);

  const [courses, materials, quizzes, stats, weekRows, announcements] = await Promise.all([
    getCourses(),
    getAllMaterials(),
    getQuizzes(),
    getSiteStats(),
    getMaterialsByWeek(status.focusWeek),
    getAnnouncements(3),
  ]);

  const courseMap = new Map(courses.map((course) => [course.id, course]));
  const core = courses.filter((course) => course.track === "core");
  const electives = courses.filter((course) => course.track === "elective");

  const materialCounts = new Map<number, number>();
  for (const material of materials) {
    materialCounts.set(material.courseId, (materialCounts.get(material.courseId) ?? 0) + 1);
  }
  const quizCounts = new Map<number, number>();
  for (const quiz of quizzes) {
    quizCounts.set(quiz.courseId, (quizCounts.get(quiz.courseId) ?? 0) + 1);
  }

  const weekItems = weekRows.map((row) => ({ ...row.material, courseCode: row.courseCode }));
  const weekTests = quizzes
    .filter((quiz) => quiz.published && quiz.week === status.focusWeek)
    .map((quiz) => ({
      id: quiz.id,
      title: quiz.title,
      courseCode: courseMap.get(quiz.courseId)?.code ?? "",
      questionCount: quiz.questionCount,
      timeLimitMinutes: quiz.timeLimitMinutes,
    }));

  const latestMaterials = materials.slice(0, 4);
  const featuredQuizzes = quizzes.filter((quiz) => quiz.published).slice(0, 4);

  const statCards = [
    { label: "Courses", value: stats.courses, icon: Layers },
    { label: "Materials", value: stats.materials, icon: FileStack },
    { label: "Tests", value: stats.quizzes, icon: ClipboardCheck },
    { label: "Questions", value: stats.questions, icon: BookMarked },
    { label: "Students", value: stats.members, icon: Users },
    { label: "Attempts", value: stats.attempts, icon: Trophy },
  ];

  return (
    <div className="space-y-16 pt-6">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] px-6 py-12 sm:px-10 sm:py-16">
        <Image
          src="/images/hero-circuit.jpg"
          alt=""
          aria-hidden="true"
          fill
          priority
          sizes="100vw"
          className="pointer-events-none absolute inset-0 object-cover opacity-25"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-canvas via-canvas/85 to-canvas/40" />
        <div className="pointer-events-none absolute -right-24 -top-32 h-96 w-96 rounded-full bg-emerald-500/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 left-1/3 h-80 w-80 rounded-full bg-sky-500/15 blur-3xl" />

        <div className="relative max-w-3xl">
          <span className="inline-flex flex-wrap items-center gap-2 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-3 py-1 text-xs font-medium text-emerald-300">
            <Sparkles className="h-3.5 w-3.5" />
            {site.projectName} · {site.cohort} · {site.university}
          </span>

          <h1 className="mt-5 text-4xl font-semibold leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-6xl">
            Learn together. Rank honestly.
            <span className="bg-gradient-to-r from-emerald-300 via-sky-300 to-violet-300 bg-clip-text text-transparent">
              {" "}
              Graduate ready.
            </span>
          </h1>

          <p className="mt-5 max-w-2xl text-base leading-relaxed text-slate-300 sm:text-lg">
            The academic platform built for our {site.cohort} study group: DCIT 101, DCIT 103,
            DCIT 105, STAT 111 and ECON 101 for everyone — plus your UGRC 110 or 150 elective.
            Slides, past questions, auto-marked exams and a real forum, free for every member.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link
              href="/register"
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-sky-400 px-5 py-3 text-sm font-semibold text-canvas transition hover:brightness-110"
            >
              Create your free account <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href={`/weeks?w=${status.focusWeek}`}
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-slate-100 transition hover:bg-white/10"
            >
              <CalendarDays className="h-4 w-4" /> This week
            </Link>
            <Link
              href="/quizzes"
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-slate-100 transition hover:bg-white/10"
            >
              Take a practice test
            </Link>
          </div>

          <div className="mt-10 flex flex-col gap-4 rounded-2xl border border-white/10 bg-canvas/60 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex min-w-0 items-center gap-4">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-emerald-400 to-sky-500 text-sm font-black text-canvas">
                {initials(site.ownerName)}
              </span>
              <div className="min-w-0">
                <p className="text-xs uppercase tracking-[0.18em] text-slate-500">
                  Founder &amp; Developer
                </p>
                <p className="truncate text-base font-semibold text-white">{site.ownerName}</p>
                <p className="text-xs text-slate-400">
                  {site.ownerRole} · {site.ownerTitle}
                </p>
              </div>
            </div>
            <ContactButtons compact />
          </div>
        </div>
      </section>

      {/* This week */}
      <WeekStatusCard status={status} items={weekItems} tests={weekTests} />

      {/* Stats */}
      <section>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {statCards.map((stat) => (
            <div key={stat.label} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
              <stat.icon className="h-4 w-4 text-emerald-400/80" />
              <p className="mt-2 text-2xl font-semibold text-white">{stat.value}</p>
              <p className="text-xs text-slate-400">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Courses */}
      <section>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
              Our courses
            </p>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white sm:text-3xl">
              Five courses together, one UGRC elective
            </h2>
            <p className="mt-2 max-w-2xl text-sm text-slate-400">
              Everyone in the group takes DCIT 101, DCIT 103, DCIT 105, ECON 101 and
              STAT 111. For the sixth course, each member takes either UGRC 150 or
              UGRC 110.
            </p>
          </div>
          <Link
            href="/courses"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-emerald-300 hover:text-emerald-200"
          >
            See all courses <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {core.map((course) => (
            <CourseCard
              key={course.id}
              course={{
                ...course,
                materialCount: materialCounts.get(course.id) ?? 0,
                quizCount: quizCounts.get(course.id) ?? 0,
              }}
            />
          ))}
        </div>

        <div className="mt-8 rounded-3xl border border-white/10 bg-white/[0.03] p-6 sm:p-8">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-5 w-5 text-sky-400" />
            <h3 className="text-lg font-semibold text-white">
              6th course — your UGRC elective
            </h3>
          </div>
          <p className="mt-2 text-sm text-slate-400">
            University Required Courses: take one. Each has its own materials and
            practice tests.
          </p>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            {electives.map((course) => (
              <CourseCard
                key={course.id}
                course={{
                  ...course,
                  materialCount: materialCounts.get(course.id) ?? 0,
                  quizCount: quizCounts.get(course.id) ?? 0,
                }}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Materials + tests */}
      <section className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-lg font-semibold text-white">Latest materials</h2>
            <Link href="/materials" className="text-sm font-medium text-emerald-300 hover:text-emerald-200">
              Library
            </Link>
          </div>
          <ul className="mt-5 space-y-3">
            {latestMaterials.length === 0 ? (
              <li className="rounded-xl border border-dashed border-white/12 p-5 text-sm text-slate-500">
                No materials yet — {site.ownerFirstName} is uploading the first batch.
              </li>
            ) : (
              latestMaterials.map((material) => (
                <MaterialRow
                  key={material.id}
                  material={material}
                  courseCode={courseMap.get(material.courseId)?.code}
                  currentWeek={status.focusWeek}
                />
              ))
            )}
          </ul>
        </div>

        <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-lg font-semibold text-white">Practice tests</h2>
            <Link href="/quizzes" className="text-sm font-medium text-emerald-300 hover:text-emerald-200">
              All tests
            </Link>
          </div>
          <ul className="mt-5 space-y-3">
            {featuredQuizzes.length === 0 ? (
              <li className="rounded-xl border border-dashed border-white/12 p-5 text-sm text-slate-500">
                No tests yet — check back after the next revision session.
              </li>
            ) : (
              featuredQuizzes.map((quiz) => (
                <li key={quiz.id}>
                  <Link
                    href={`/quizzes/${quiz.id}`}
                    className="block rounded-xl border border-white/10 bg-canvas/40 p-4 transition hover:border-emerald-400/40 hover:bg-emerald-400/5"
                  >
                    <p className="text-sm font-semibold text-slate-100">{quiz.title}</p>
                    <p className="mt-1 text-xs text-slate-400">
                      {courseMap.get(quiz.courseId)?.code}
                      {quiz.week ? ` · week ${quiz.week}` : ""} · {quiz.questionCount}{" "}
                      questions · {quiz.timeLimitMinutes} min · {quiz.attemptCount} attempts
                    </p>
                  </Link>
                </li>
              ))
            )}
          </ul>
        </div>
      </section>

      {/* Announcements + join */}
      <section className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-lg font-semibold text-white">Latest announcements</h2>
            <Link href="/announcements" className="text-sm font-medium text-emerald-300 hover:text-emerald-200">
              All announcements
            </Link>
          </div>
          <ul className="mt-5 space-y-3">
            {announcements.length === 0 ? (
              <li className="rounded-xl border border-dashed border-white/12 p-5 text-sm text-slate-500">
                No announcements yet — {site.ownerFirstName} will post updates here.
              </li>
            ) : (
              announcements.map(({ announcement, courseCode }) => (
                <li key={announcement.id} className="rounded-xl border border-white/10 bg-canvas/40 p-4">
                  <p className="text-sm font-semibold text-slate-100">{announcement.title}</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-slate-400">{announcement.body}</p>
                  <p className="mt-2 text-[11px] text-slate-500">
                    {courseCode ? `${courseCode} · ` : "Everyone · "}
                    {new Date(announcement.createdAt).toUTCString().slice(5, 16)}
                  </p>
                </li>
              ))
            )}
          </ul>
        </div>

        <div className="rounded-3xl border border-emerald-400/25 bg-gradient-to-br from-emerald-500/15 via-white/[0.02] to-sky-500/10 p-6 sm:p-8">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-300">
            Your account
          </p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white">
            One account. Every course. Your dashboard.
          </h2>
          <ul className="mt-5 space-y-2.5 text-sm text-slate-300">
            {[
              "Sit auto-marked practice tests and formal exams",
              "Track your scores, enrolments and weekly progress",
              "Bookmark resources and save your seat on the leaderboard",
              "Submit assignments before the deadline",
              "Ask questions in the course forum",
            ].map((item) => (
              <li key={item} className="flex items-start gap-2">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400" />
                {item}
              </li>
            ))}
          </ul>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link
              href="/register"
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-sky-400 px-5 py-3 text-sm font-semibold text-canvas transition hover:brightness-110"
            >
              Create your account <ArrowRight className="h-4 w-4" />
            </Link>
            <Link href="/login" className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-slate-100 transition hover:bg-white/10">
              I already have one
            </Link>
          </div>

          <div className="mt-6 border-t border-white/10 pt-5">
            <p className="text-xs text-slate-500">
              Questions? Speak to {site.ownerFirstName} — WhatsApp or email
            </p>
            <div className="mt-3">
              <ContactButtons compact />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
