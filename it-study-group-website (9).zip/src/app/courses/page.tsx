import Link from "next/link";
import { BookOpen, CheckCircle2, Layers } from "lucide-react";
import { CourseCard } from "@/components/course-card";
import { getCourses, getAllMaterials, getQuizzes } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Courses",
  description:
    "The five core IT courses every study group member takes, plus the UGRC 150 / UGRC 110 elective track.",
};

export default async function CoursesPage({
  searchParams,
}: {
  searchParams: Promise<{ track?: string }>;
}) {
  const { track } = await searchParams;
  const [courses, materials, quizzes] = await Promise.all([
    getCourses(),
    getAllMaterials(),
    getQuizzes(),
  ]);

  const materialCounts = new Map<number, number>();
  for (const material of materials) {
    materialCounts.set(
      material.courseId,
      (materialCounts.get(material.courseId) ?? 0) + 1,
    );
  }
  const quizCounts = new Map<number, number>();
  for (const quiz of quizzes) {
    quizCounts.set(quiz.courseId, (quizCounts.get(quiz.courseId) ?? 0) + 1);
  }

  const core = courses.filter((course) => course.track === "core");
  const electives = courses.filter((course) => course.track === "elective");

  const filter = (value: string) =>
    track === value
      ? "bg-white/10 text-white ring-white/20"
      : "bg-white/5 text-slate-300 ring-white/10 hover:bg-white/10";

  return (
    <div className="space-y-10 pt-6">
      <header className="max-w-3xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
          Course catalogue
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          Six courses, one shared library
        </h1>
        <p className="mt-3 text-base leading-relaxed text-slate-400">
          Every member takes the five core courses below. For the sixth course,
          choose the elective track you registered for — UGRC 150 or UGRC 110.
        </p>
      </header>

      <div className="flex flex-wrap gap-2">
        <Link href="/courses" className={`rounded-lg px-3.5 py-2 text-sm font-medium ring-1 ${filter("all")}`}>
          All courses
        </Link>
        <Link
          href="/courses?track=core"
          className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-sm font-medium ring-1 ${filter("core")}`}
        >
          <BookOpen className="h-4 w-4" /> Core (5)
        </Link>
        <Link
          href="/courses?track=elective"
          className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-sm font-medium ring-1 ${filter("elective")}`}
        >
          <CheckCircle2 className="h-4 w-4" /> Elective (UGRC)
        </Link>
      </div>

      {(track === "core" || track === "all" || !track) && core.length > 0 ? (
        <section>
          <div className="flex items-center gap-2">
            <Layers className="h-5 w-5 text-sky-400" />
            <h2 className="text-xl font-semibold text-white">
              Core courses — taken by everyone
            </h2>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {core.map((course) => (
              <CourseCard
                key={course.id}
                course={{
                  ...course,
                  materialCount: materialCounts.get(course.id) ?? 0,
                  quizCount: quizCounts.get(course.id) ?? 0,
                }}
              />
            ))}
          </div>
        </section>
      ) : null}

      {(track === "elective" || track === "all" || !track) && electives.length > 0 ? (
        <section>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-amber-400" />
            <h2 className="text-xl font-semibold text-white">
              Elective track — choose one
            </h2>
          </div>
          <p className="mt-2 text-sm text-slate-400">
            UGRC 150 and UGRC 110 are University Required Courses — each member
            takes one, and each has its own materials and practice tests.
          </p>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            {electives.map((course) => (
              <CourseCard
                key={course.id}
                course={{
                  ...course,
                  materialCount: materialCounts.get(course.id) ?? 0,
                  quizCount: quizCounts.get(course.id) ?? 0,
                }}
              />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}
