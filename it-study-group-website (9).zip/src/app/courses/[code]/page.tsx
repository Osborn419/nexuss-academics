import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  ClipboardCheck,
  Clock,
  FileStack,
  Layers,
} from "lucide-react";
import { MaterialRow } from "@/components/material-row";
import { accentMeta } from "@/lib/materials";
import {
  getCourseByCode,
  getMaterialsByCourse,
  getQuizzes,
  getSemesterConfig,
} from "@/lib/queries";
import { getSemesterStatus } from "@/lib/semester";
import { formatDate } from "@/lib/format";
import { getCurrentProfile } from "@/lib/auth";
import { EnrolButton } from "@/components/enrol-button";
import { getEnrolledCourseIds } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ code: string }>;
}) {
  const { code } = await params;
  const course = await getCourseByCode(code);
  if (!course) return { title: "Course not found" };
  return {
    title: `${course.code} — ${course.title}`,
    description: course.summary,
  };
}

export default async function CourseDetailPage({
  params,
}: {
  params: Promise<{ code: string }>;
}) {
  const { code } = await params;
  const course = await getCourseByCode(code);
  if (!course) notFound();

  const [materials, allQuizzes, semester] = await Promise.all([
    getMaterialsByCourse(course.id),
    getQuizzes(),
    getSemesterConfig(),
  ]);
  const status = getSemesterStatus(semester);
  const profile = await getCurrentProfile();
  const enrolledIds = profile ? await getEnrolledCourseIds(profile.id) : new Set<number>();
  const todayWeek = status.phase === "teaching" ? status.currentWeek : undefined;
  const quizzes = allQuizzes.filter((quiz) => quiz.courseId === course.id && quiz.published);
  const accent = accentMeta(course.accent);

  const groups = new Map<number | null, typeof materials>();
  for (const material of materials) {
    const key = material.week ?? null;
    const list = groups.get(key) ?? [];
    list.push(material);
    groups.set(key, list);
  }
  const weekKeys = [...groups.keys()].sort((a, b) => (b ?? -1) - (a ?? -1));

  return (
    <div className="space-y-10 pt-6">
      <Link
        href="/courses"
        className="inline-flex items-center gap-1.5 text-sm text-slate-400 transition hover:text-emerald-300"
      >
        <ArrowLeft className="h-4 w-4" /> All courses
      </Link>

      <header className="relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] p-6 sm:p-10">
        <div
          className={`pointer-events-none absolute -right-20 -top-28 h-72 w-72 rounded-full bg-gradient-to-b ${accent.glow} to-transparent blur-3xl`}
        />
        <div className="relative">
          <div className="flex flex-wrap items-center gap-3">
            <span
              className={`rounded-lg px-3 py-1.5 font-mono text-sm font-semibold ring-1 ${accent.ring} ${accent.text}`}
            >
              {course.code}
            </span>
            <span className="rounded-lg bg-white/5 px-2.5 py-1 text-xs text-slate-400">
              Level {course.level}
            </span>
            <span className="rounded-lg bg-white/5 px-2.5 py-1 text-xs text-slate-400">
              {course.credits} credits
            </span>
            <span className="rounded-lg bg-white/5 px-2.5 py-1 text-xs text-slate-400">
              {course.track === "elective" ? "UGRC elective" : "Taken by everyone"}
            </span>
            {profile ? <EnrolButton courseId={course.id} enrolled={enrolledIds.has(course.id)} /> : null}
          </div>

          <h1 className="mt-4 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            {course.title}
          </h1>
          <p className="mt-3 max-w-3xl text-base leading-relaxed text-slate-300">
            {course.description || course.summary}
          </p>

          <div className="mt-6 flex flex-wrap gap-3 text-sm text-slate-400">
            <span className="inline-flex items-center gap-2 rounded-lg bg-white/5 px-3 py-2">
              <FileStack className="h-4 w-4 text-emerald-400" />
              {materials.length} materials
            </span>
            <span className="inline-flex items-center gap-2 rounded-lg bg-white/5 px-3 py-2">
              <ClipboardCheck className="h-4 w-4 text-sky-400" />
              {quizzes.length} tests
            </span>
            <Link
              href={`/weeks?w=${status.focusWeek}`}
              className="inline-flex items-center gap-2 rounded-lg bg-emerald-400/10 px-3 py-2 text-emerald-300 ring-1 ring-emerald-400/25 hover:bg-emerald-400/15"
            >
              <CalendarDays className="h-4 w-4" />
              {status.upcoming ? `Week ${status.focusWeek} starts Monday` : `Week ${status.focusWeek} plan`}
            </Link>
          </div>
        </div>
      </header>

      <section>
        <h2 className="text-xl font-semibold text-white">Learning materials</h2>
        <p className="mt-1.5 text-sm text-slate-400">
          Slides, notes, practicals and links for {course.code}, newest week first.
        </p>

        {materials.length === 0 ? (
          <p className="mt-6 rounded-2xl border border-dashed border-white/12 p-8 text-center text-sm text-slate-500">
            No materials posted for this course yet.
          </p>
        ) : (
          <div className="mt-6 space-y-8">
            {weekKeys.map((week) => {
              const items = groups.get(week) ?? [];
              const tag =
                week !== null && week === todayWeek
                  ? "This week"
                  : week !== null && status.upcoming && week === status.focusWeek
                    ? "Starts Monday"
                    : null;
              return (
                <div key={week ?? "general"}>
                  <div className="flex items-center gap-3">
                    <h3 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-300">
                      {week === null ? "General resources" : `Week ${week}`}
                    </h3>
                    {tag ? (
                      <span className="rounded-full bg-emerald-400/15 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-200 ring-1 ring-emerald-400/30">
                        {tag}
                      </span>
                    ) : null}
                    <span className="h-px flex-1 bg-white/10" />
                  </div>
                  <ul className="mt-3 space-y-3">
                    {items.map((material) => (
                      <MaterialRow key={material.id} material={material} currentWeek={todayWeek} />
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <section>
        <div className="flex items-center gap-2">
          <Layers className="h-5 w-5 text-sky-400" />
          <h2 className="text-xl font-semibold text-white">Tests for this course</h2>
        </div>

        {quizzes.length === 0 ? (
          <p className="mt-6 rounded-2xl border border-dashed border-white/12 p-8 text-center text-sm text-slate-500">
            No tests yet for {course.code}.
          </p>
        ) : (
          <ul className="mt-6 grid gap-4 sm:grid-cols-2">
            {quizzes.map((quiz) => (
              <li key={quiz.id}>
                <Link
                  href={`/quizzes/${quiz.id}`}
                  className="group flex h-full flex-col rounded-2xl border border-white/10 bg-white/[0.03] p-5 transition hover:border-emerald-400/40 hover:bg-emerald-400/5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="text-base font-semibold text-slate-100">{quiz.title}</h3>
                    <ArrowRight className="h-4 w-4 shrink-0 text-slate-600 transition group-hover:translate-x-0.5 group-hover:text-emerald-300" />
                  </div>
                  {quiz.description ? (
                    <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-400">
                      {quiz.description}
                    </p>
                  ) : null}
                  <p className="mt-4 flex flex-wrap items-center gap-3 text-xs text-slate-500">
                    {quiz.week ? <span>Week {quiz.week}</span> : null}
                    <span>{quiz.questionCount} questions</span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {quiz.timeLimitMinutes} min
                    </span>
                    <span>{quiz.attemptCount} attempts</span>
                    <span>{formatDate(quiz.createdAt)}</span>
                  </p>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
