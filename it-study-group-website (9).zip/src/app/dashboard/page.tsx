import Link from "next/link";
import { redirect } from "next/navigation";
import {
  ArrowRight,
  Bell,
  Bookmark,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  FileUp,
  GraduationCap,
  TrendingUp,
} from "lucide-react";
import { MaterialRow } from "@/components/material-row";
import { MarkAllReadButton } from "@/components/profile-forms";
import { getCurrentProfile } from "@/lib/auth";
import {
  getAssignments,
  getAttempts,
  getBookmarkedMaterials,
  getCourses,
  getEnrolments,
  getMySubmissions,
  getNotifications,
  getProgressWeeks,
  getQuizzes,
  getStudySessions,
} from "@/lib/queries";
import { formatBytes, formatDate, formatDuration, formatShortDate, percent } from "@/lib/format";
import { getSemesterConfig } from "@/lib/queries";
import { getSemesterStatus } from "@/lib/semester";
import { site } from "@/config/site";

export const dynamic = "force-dynamic";

export const metadata = { title: "My dashboard" };

export default async function DashboardPage() {
  const profile = await getCurrentProfile();
  if (!profile) redirect("/login?next=/dashboard");

  const [enrolments, progressRows, attempts, bookmarked, notifications, assignments, submissions, sessions, quizzes, semester, courseList] =
    await Promise.all([
      getEnrolments(profile.id),
      getProgressWeeks(profile.id),
      getAttempts(undefined, profile.id),
      getBookmarkedMaterials(profile.id),
      getNotifications(profile.id, 8),
      getAssignments(),
      getMySubmissions(profile.id),
      getStudySessions(),
      getQuizzes(),
      getSemesterConfig(),
      getCourses(),
    ]);
  const status = getSemesterStatus(semester);

  const quizMap = new Map(quizzes.map((quiz) => [quiz.id, quiz]));
  const submittedIds = new Set(submissions.map((row) => row.assignment.id));
  const progressByCourse = new Map<number, Set<number>>();
  for (const row of progressRows) {
    if (!progressByCourse.has(row.courseId)) progressByCourse.set(row.courseId, new Set());
    progressByCourse.get(row.courseId)!.add(row.week);
  }

  const attemptPercents = attempts.map((attempt) => percent(attempt.score, attempt.maxScore));
  const average =
    attemptPercents.length > 0
      ? Math.round(attemptPercents.reduce((sum, value) => sum + value, 0) / attemptPercents.length)
      : 0;
  const weeksDone = progressRows.length;
  const totalWeeks = semester.weeks;
  const totalProgress = totalWeeks * Math.max(enrolments.length, 1);

  const nowMs = new Date().getTime();
  const upcomingAssignments = assignments
    .filter(({ assignment }) => assignment.dueDate && assignment.dueDate.getTime() >= nowMs - 86_400_000)
    .slice(0, 4);
  const nextSession = sessions[0] ?? null;

  const statCards = [
    { label: "Enrolled courses", value: enrolments.length, icon: GraduationCap },
    { label: "Exams taken", value: attempts.length, icon: ClipboardCheck },
    { label: "Average score", value: attempts.length ? `${average}%` : "—", icon: TrendingUp },
    { label: "Weeks completed", value: `${weeksDone}/${totalProgress}`, icon: CheckCircle2 },
    { label: "Saved resources", value: bookmarked.length, icon: Bookmark },
    { label: "New notifications", value: notifications.filter((n) => !n.read).length, icon: Bell },
  ];

  return (
    <div className="space-y-8 pt-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">My dashboard</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">
            Akwaaba, {profile.displayName.split(" ")[0]}
          </h1>
          <p className="mt-2 text-sm text-slate-400">
            {status.phase === "teaching"
              ? `Week ${status.currentWeek} of ${semester.weeks} · ${semester.label}`
              : semester.label}
          </p>
        </div>
        <Link href="/courses" className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-sky-400 px-4 py-2.5 text-sm font-semibold text-canvas">
          Browse courses <ArrowRight className="h-4 w-4" />
        </Link>
      </header>

      <section className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {statCards.map((card) => (
          <div key={card.label} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <card.icon className="h-4 w-4 text-emerald-400/80" />
            <p className="mt-2 text-2xl font-semibold text-white">{card.value}</p>
            <p className="text-xs text-slate-400">{card.label}</p>
          </div>
        ))}
      </section>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Enrolments + progress */}
        <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-6 lg:col-span-2">
          <h2 className="text-lg font-semibold text-white">My courses</h2>
          {enrolments.length === 0 ? (
            <div className="mt-4 rounded-2xl border border-dashed border-white/12 p-6 text-center">
              <p className="text-sm text-slate-400">You are not enrolled in any course yet.</p>
              <Link href="/courses" className="mt-3 inline-flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2 text-sm font-medium text-white ring-1 ring-white/15">
                Enrol now <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          ) : (
            <ul className="mt-4 space-y-3">
              {enrolments.map(({ course }) => {
                const done = progressByCourse.get(course.id)?.size ?? 0;
                const pct = Math.round((done / totalWeeks) * 100);
                return (
                  <li key={course.id} className="rounded-2xl border border-white/10 bg-canvas/40 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <Link href={`/courses/${course.code.toLowerCase().replace(/\s+/g, "-")}`} className="min-w-0">
                        <span className="font-mono text-xs text-emerald-300">{course.code}</span>
                        <span className="block truncate text-sm font-medium text-slate-100">{course.title}</span>
                      </Link>
                      <span className="text-xs text-slate-500">{done}/{totalWeeks} weeks</span>
                    </div>
                    <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10">
                      <div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-sky-400" style={{ width: `${pct}%` }} />
                    </div>
                  </li>
                );
              })}
            </ul>
          )}

          <h2 className="mt-8 text-lg font-semibold text-white">Recent exam activity</h2>
          {attempts.length === 0 ? (
            <p className="mt-3 text-sm text-slate-500">No attempts yet — sit your first practice test from the Exams page.</p>
          ) : (
            <ul className="mt-3 divide-y divide-white/5">
              {attempts.slice(0, 8).map((attempt) => {
                const quiz = quizMap.get(attempt.quizId);
                return (
                  <li key={attempt.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                    <span className="min-w-0">
                      <Link href={quiz ? `/quizzes/${quiz.id}/result/${attempt.id}` : "/quizzes"} className="block truncate font-medium text-slate-200 hover:text-emerald-300">
                        {quiz?.title ?? "Removed exam"}
                      </Link>
                      <span className="text-xs text-slate-500">
                        {quiz?.week ? `Week ${quiz.week} · ` : ""}{formatDate(attempt.createdAt)} · {formatDuration(attempt.durationSeconds)}
                      </span>
                    </span>
                    <span className={`shrink-0 text-sm font-semibold ${percent(attempt.score, attempt.maxScore) >= 50 ? "text-emerald-300" : "text-rose-300"}`}>
                      {percent(attempt.score, attempt.maxScore)}%
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        {/* Notifications + deadlines */}
        <section className="space-y-6">
          <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-lg font-semibold text-white">Notifications</h2>
              {notifications.some((notification) => !notification.read) ? <MarkAllReadButton /> : null}
            </div>
            {notifications.length === 0 ? (
              <p className="mt-3 text-sm text-slate-500">Nothing yet — you will be notified about new assignments, announcements and sessions.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {notifications.map((notification) => (
                  <li key={notification.id}>
                    <Link href={notification.link ?? "/dashboard"} className={`block rounded-xl border px-3.5 py-2.5 text-sm transition ${notification.read ? "border-white/5 bg-canvas/30 text-slate-400" : "border-emerald-400/20 bg-emerald-400/5 text-slate-200"}`}>
                      <span className="font-medium">{notification.title}</span>
                      {notification.body ? <span className="mt-0.5 block text-xs text-slate-500">{notification.body}</span> : null}
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-white"><Clock className="h-5 w-5 text-amber-400" /> Coming up</h2>
            {upcomingAssignments.length === 0 && !nextSession ? (
              <p className="mt-3 text-sm text-slate-500">No deadlines or sessions right now. Enjoy the peace.</p>
            ) : (
              <ul className="mt-3 space-y-2 text-sm">
                {upcomingAssignments.map(({ assignment, courseCode }) => {
                  const submitted = submittedIds.has(assignment.id);
                  return (
                    <li key={assignment.id} className="rounded-xl border border-white/10 bg-canvas/40 px-3.5 py-2.5">
                      <span className="font-mono text-[10px] uppercase text-slate-500">{courseCode} · assignment</span>
                      <Link href="/assignments" className="block truncate font-medium text-slate-100 hover:text-emerald-300">{assignment.title}</Link>
                      <span className="mt-0.5 flex items-center gap-2 text-xs text-slate-500">
                        {assignment.dueDate ? formatShortDate(new Date(assignment.dueDate)) : "No deadline"}
                        {submitted ? <span className="text-emerald-300">· submitted</span> : <span className="text-amber-300">· pending</span>}
                      </span>
                    </li>
                  );
                })}
                {nextSession ? (
                  <li className="rounded-xl border border-sky-400/20 bg-sky-400/5 px-3.5 py-2.5">
                    <span className="font-mono text-[10px] uppercase text-sky-400/80">Study session</span>
                    <p className="truncate font-medium text-slate-100">{nextSession.session.title}</p>
                    <p className="text-xs text-slate-500">{formatShortDate(new Date(nextSession.session.sessionAt))}</p>
                  </li>
                ) : null}
              </ul>
            )}
          </div>
        </section>
      </div>

      {/* Bookmarks */}
      {bookmarked.length > 0 ? (
        <section>
          <h2 className="flex items-center gap-2 text-lg font-semibold text-white"><FileUp className="hidden" /><Bookmark className="h-5 w-5 text-amber-400" /> Saved resources</h2>
          <ul className="mt-3 space-y-3">
            {bookmarked.slice(0, 6).map(({ material, courseCode }) => (
              <MaterialRow key={material.id} material={material} courseCode={courseCode} />
            ))}
          </ul>
        </section>
      ) : null}

      <p className="text-center text-xs text-slate-600">Progress is stored on {site.projectName} — it persists across devices when you sign in.</p>
    </div>
  );
}
