import Link from "next/link";
import { Megaphone } from "lucide-react";
import { getAnnouncements } from "@/lib/queries";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Announcements",
  description: "Platform and course announcements from the administrator.",
};

export default async function AnnouncementsPage() {
  const announcements = await getAnnouncements(60);

  return (
    <div className="mx-auto max-w-3xl space-y-6 pt-6">
      <header>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Announcements</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">News from the study group</h1>
      </header>

      {announcements.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/12 p-12 text-center">
          <Megaphone className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm text-slate-400">No announcements yet.</p>
        </div>
      ) : (
        <ul className="space-y-4">
          {announcements.map(({ announcement, courseCode }) => (
            <li key={announcement.id} className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                <span className={`rounded px-1.5 py-0.5 font-mono ${courseCode ? "bg-white/5 text-emerald-300" : "bg-amber-400/10 text-amber-300"}`}>
                  {courseCode ?? "EVERYONE"}
                </span>
                <span>{formatDate(announcement.createdAt)}</span>
              </div>
              <h2 className="mt-2 text-lg font-semibold text-white">{announcement.title}</h2>
              <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-slate-300">{announcement.body}</p>
            </li>
          ))}
        </ul>
      )}
      <p className="text-center text-xs text-slate-600"><Link href="/dashboard" className="hover:text-emerald-300">Back to my dashboard</Link></p>
    </div>
  );
}
