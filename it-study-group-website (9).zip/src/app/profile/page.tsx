import Link from "next/link";
import { redirect } from "next/navigation";
import { ShieldCheck, UserRound } from "lucide-react";
import { ChangePasswordForm, DisplayNameForm } from "@/components/profile-forms";
import { getCurrentProfile } from "@/lib/auth";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "My profile" };

export default async function ProfilePage() {
  const profile = await getCurrentProfile();
  if (!profile) redirect("/login?next=/profile");

  return (
    <div className="mx-auto max-w-2xl space-y-6 pt-8">
      <header className="flex items-center gap-4">
        <span className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-emerald-400 to-sky-500 text-xl font-black text-canvas">
          {profile.displayName.charAt(0).toUpperCase()}
        </span>
        <div>
          <h1 className="text-2xl font-semibold text-white">{profile.displayName}</h1>
          <p className="text-sm text-slate-400">{profile.email}</p>
          <p className="mt-1 inline-flex items-center gap-1.5 rounded-full bg-white/5 px-2.5 py-0.5 text-[11px] font-medium text-slate-400 ring-1 ring-white/10">
            {profile.role === "admin" ? <ShieldCheck className="h-3.5 w-3.5 text-amber-300" /> : <UserRound className="h-3.5 w-3.5 text-emerald-300" />}
            {profile.role === "admin" ? "Administrator" : "Student"}
          </p>
        </div>
      </header>

      <section className="rounded-2xl border border-white/10 bg-white/[0.03] p-6">
        <h2 className="text-lg font-semibold text-white">Profile</h2>
        <p className="mt-1 text-sm text-slate-400">Your display name appears next to exam results and in the forum.</p>
        <div className="mt-4">
          <DisplayNameForm name={profile.displayName} />
        </div>
      </section>

      <section className="rounded-2xl border border-white/10 bg-white/[0.03] p-6">
        <h2 className="text-lg font-semibold text-white">Change password</h2>
        <div className="mt-4">
          <ChangePasswordForm />
        </div>
      </section>

      <p className="text-center text-xs text-slate-600">
        Questions about your account? <Link href="/dashboard" className="text-emerald-300 hover:text-emerald-200">Contact the administrator</Link>
      </p>
    </div>
  );
}
