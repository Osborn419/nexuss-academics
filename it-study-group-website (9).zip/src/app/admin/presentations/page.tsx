import { redirect } from "next/navigation";
import { Presentation } from "lucide-react";
import { AdminNav } from "@/components/admin/nav";
import { DeleteContentButton, PresentationForm } from "@/components/admin/simple-forms";
import { isAdminProfile, getSessionProfile } from "@/lib/admin-guard";
import { getCourses, getPresentations } from "@/lib/queries";
import { formatShortDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Presentations" };

export default async function AdminPresentationsPage() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login?next=/admin/presentations");
  if (!(await isAdminProfile(profile))) redirect("/dashboard");

  const [courses, presentations] = await Promise.all([getCourses(), getPresentations()]);

  return (
    <div className="space-y-6 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Presentation centre</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Presentation schedule</h1>
          <p className="mt-2 max-w-xl text-sm text-slate-400">Link any uploaded slide deck by its material ID to attach it to the schedule.</p>
        </div>
        <AdminNav />
      </header>

      <PresentationForm courses={courses.map((course) => ({ id: course.id, code: course.code }))} />

      <section>
        <h2 className="flex items-center gap-2 text-lg font-semibold text-white"><Presentation className="h-5 w-5 text-violet-300" /> Scheduled ({presentations.length})</h2>
        <ul className="mt-3 space-y-3">
          {presentations.map(({ presentation, courseCode }) => (
            <li key={presentation.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-5 py-4">
              <div className="min-w-0">
                <p className="font-mono text-[10px] uppercase text-slate-500">{courseCode ?? "General"}{presentation.week ? ` · week ${presentation.week}` : ""}{presentation.sessionDate ? ` · ${formatShortDate(new Date(presentation.sessionDate))}` : ""}</p>
                <p className="mt-0.5 font-medium text-white">{presentation.title}</p>
                {presentation.presenter ? <p className="text-xs text-slate-500">{presentation.presenter}</p> : null}
              </div>
              <DeleteContentButton kind="presentation" id={presentation.id} confirmMessage={`Delete "${presentation.title}"?`} />
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
