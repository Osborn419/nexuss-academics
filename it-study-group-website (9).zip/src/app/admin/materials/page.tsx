import Link from "next/link";
import { redirect } from "next/navigation";
import { AdminNav } from "@/components/admin/nav";
import { MaterialForm } from "@/components/admin/material-form";
import { DeleteButton } from "@/components/admin/delete-button";
import { MaterialEditor } from "@/components/admin/material-editor";
import { KindBadge } from "@/components/icons";
import { isAdmin } from "@/lib/admin-guard";
import { getAllMaterials, getCourses, getSemesterConfig } from "@/lib/queries";
import { getSemesterStatus } from "@/lib/semester";
import { formatBytes, formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Manage materials" };

export default async function AdminMaterialsPage() {
  if (!(await isAdmin())) redirect("/admin/login");

  const [courses, materials, semester] = await Promise.all([
    getCourses(),
    getAllMaterials(true),
    getSemesterConfig(),
  ]);
  const status = getSemesterStatus(semester);
  const courseMap = new Map(courses.map((course) => [course.id, course]));

  return (
    <div className="space-y-8 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
            Content
          </p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Materials</h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-400">
            Upload slides, notes and past questions — select many files at once and they
            upload one after another. New uploads default to week {status.focusWeek}.
          </p>
        </div>
        <AdminNav />
      </header>

      <MaterialForm
        defaultWeek={status.focusWeek}
        totalWeeks={status.totalWeeks}
        courses={courses.map((course) => ({
          id: course.id,
          code: course.code,
          title: course.title,
        }))}
      />

      <section>
        <h2 className="text-lg font-semibold text-white">
          Posted materials ({materials.length})
        </h2>
        <div className="mt-4 overflow-x-auto rounded-2xl border border-white/10">
          <table className="w-full min-w-[48rem] text-left text-sm">
            <thead className="bg-white/[0.04] text-xs uppercase tracking-wide text-slate-400">
              <tr>
                <th className="px-4 py-3 font-medium">Title</th>
                <th className="px-4 py-3 font-medium">Course</th>
                <th className="px-4 py-3 font-medium">Week</th>
                <th className="px-4 py-3 font-medium">Type</th>
                <th className="px-4 py-3 font-medium">Posted</th>
                <th className="px-4 py-3 font-medium">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {materials.map((material) => (
                <tr key={material.id} className="bg-white/[0.02]">
                  <td className="px-4 py-3">
                    <Link
                      href={`/materials/${material.id}`}
                      className="block font-medium text-slate-100 hover:text-emerald-300"
                    >
                      {material.title}
                    </Link>
                    <span className="block max-w-md truncate text-xs text-slate-500">
                      {material.fileId ? `File · ${formatBytes(material.sizeBytes)}` : ""}
                      {material.fileId && material.description ? " · " : ""}
                      {material.description}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-400">
                    {courseMap.get(material.courseId)?.code ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-400">
                    {material.week ? `Week ${material.week}` : "—"}
                  </td>
                  <td className="px-4 py-3">
                    <KindBadge kind={material.kind} />
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-500">
                    {formatDate(material.createdAt)}
                  </td>
                   <td className="px-4 py-3">
                     <MaterialEditor material={{ id: material.id, title: material.title, description: material.description, url: material.url, content: material.content, kind: material.kind, week: material.week, published: material.published }} />
                     <DeleteButton
                       endpoint={`/api/admin/materials?id=${material.id}`}
                      confirmMessage={`Delete "${material.title}"?`}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
