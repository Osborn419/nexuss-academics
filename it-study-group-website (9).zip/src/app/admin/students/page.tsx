import { redirect } from "next/navigation";
import { Users } from "lucide-react";
import { desc, eq, sql } from "drizzle-orm";
import { AdminNav } from "@/components/admin/nav";
import { StudentActions } from "@/components/admin/simple-forms";
import { isAdminProfile, getSessionProfile } from "@/lib/admin-guard";
import { db } from "@/db";
import { attempts, profiles } from "@/db/schema";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Students" };

export default async function AdminStudentsPage() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login?next=/admin/students");
  if (!(await isAdminProfile(profile))) redirect("/dashboard");

  const students = await db
    .select({
      id: profiles.id,
      name: profiles.name,
      displayName: profiles.displayName,
      email: profiles.email,
      role: profiles.role,
      createdAt: profiles.createdAt,
      attempts: sql<number>`(select count(*)::int from ${attempts} a where a.profile_id = ${profiles.id})`,
    })
    .from(profiles)
    .orderBy(desc(profiles.createdAt));

  return (
    <div className="space-y-6 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Students</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Manage accounts</h1>
          <p className="mt-2 max-w-xl text-sm text-slate-400">
            {students.filter((s) => s.role === "student").length} students and{" "}
            {students.filter((s) => s.role === "admin").length} administrator. Emails are private to this page.
          </p>
        </div>
        <AdminNav />
      </header>

      <div className="overflow-x-auto rounded-2xl border border-white/10">
        <table className="w-full min-w-[52rem] text-left text-sm">
          <thead className="bg-white/[0.04] text-xs uppercase tracking-wide text-slate-400">
            <tr>
              <th className="px-4 py-3 font-medium">Student</th>
              <th className="px-4 py-3 font-medium">Email</th>
              <th className="px-4 py-3 font-medium">Joined</th>
              <th className="px-4 py-3 font-medium">Attempts</th>
              <th className="px-4 py-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {students.map((student) => (
              <tr key={student.id} className="bg-white/[0.02] align-top">
                <td className="px-4 py-3">
                  <span className="block font-medium text-slate-100">
                    {student.displayName}
                    {student.role === "admin" ? <span className="ml-2 rounded bg-amber-400/15 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-amber-300">admin</span> : null}
                  </span>
                  <span className="text-xs text-slate-500">{student.name}</span>
                </td>
                <td className="px-4 py-3 text-xs text-slate-400">{student.email}</td>
                <td className="px-4 py-3 text-xs text-slate-500">{formatDate(student.createdAt)}</td>
                <td className="px-4 py-3 text-xs text-slate-400">{student.attempts}</td>
                <td className="px-4 py-3">
                  {student.role === "admin" ? (
                    <span className="text-xs text-slate-600">Administrator</span>
                  ) : (
                    <StudentActions profileId={student.id} name={student.displayName} />
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="flex items-center gap-2 text-xs text-slate-500"><Users className="h-4 w-4" /> Reset links expire after one hour and can only be used once.</p>
    </div>
  );
}
