import Link from "next/link";
import { redirect } from "next/navigation";
import { ExternalLink } from "lucide-react";
import { AdminNav } from "@/components/admin/nav";
import { CourseForm } from "@/components/admin/course-form";
import { CourseEditor } from "@/components/admin/course-editor";
import { DeleteButton } from "@/components/admin/delete-button";
import { isAdmin } from "@/lib/admin-guard";
import { getCourses } from "@/lib/queries";
import { slugify } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Manage courses" };

export default async function AdminCoursesPage() {
  if (!(await isAdmin())) redirect("/admin/login");

  const courses = await getCourses();

  return (
    <div className="space-y-8 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
            Catalogue
          </p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">
            Courses
          </h1>
          <p className="mt-2 text-sm text-slate-400">
            Five core courses that everyone takes, plus the UGRC elective
            tracks.
          </p>
        </div>
        <AdminNav />
      </header>

      <CourseForm />

      <section>
        <h2 className="text-lg font-semibold text-white">
          Course list ({courses.length})
        </h2>
        <ul className="mt-4 grid gap-3 sm:grid-cols-2">
          {courses.map((course) => (
            <li
              key={course.id}
              className="rounded-2xl border border-white/10 bg-white/[0.03] p-5"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-mono text-xs text-emerald-300">
                    {course.code}
                  </p>
                  <p className="mt-1 truncate font-semibold text-white">
                    {course.title}
                  </p>
                  <p className="mt-1 line-clamp-2 text-xs text-slate-400">
                    {course.summary}
                  </p>
                </div>
                <span className="shrink-0 rounded-md bg-white/5 px-2 py-1 text-[11px] text-slate-400">
                  {course.track === "elective" ? "Elective" : "Core"}
                </span>
              </div>
              <div className="mt-4 flex items-center gap-2">
                <Link
                  href={`/courses/${slugify(course.code)}`}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-300 ring-1 ring-white/10 transition hover:bg-white/10"
                >
                  <ExternalLink className="h-3.5 w-3.5" /> View
                </Link>
                 <CourseEditor course={course} />
                 <DeleteButton
                   endpoint={`/api/admin/courses?id=${course.id}`}
                  confirmMessage={`Remove ${course.code} and all of its materials and tests?`}
                />
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
