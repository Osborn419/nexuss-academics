import { redirect } from "next/navigation";
import { CalendarClock } from "lucide-react";
import { AdminNav } from "@/components/admin/nav";
import { DeleteContentButton, SessionForm } from "@/components/admin/simple-forms";
import { isAdminProfile, getSessionProfile } from "@/lib/admin-guard";
import { getCourses, getStudySessions } from "@/lib/queries";
import { formatShortDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Study sessions" };

export default async function AdminSessionsPage() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login?next=/admin/sessions");
  if (!(await isAdminProfile(profile))) redirect("/dashboard");

  const [courses, sessions] = await Promise.all([getCourses(), getStudySessions(true)]);

  const nowMs = new Date().getTime();
  return (
    <div className="space-y-6 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Study sessions</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Schedule live sessions</h1>
          <p className="mt-2 max-w-xl text-sm text-slate-400">Paste a real Google Meet / Zoom / Teams link — students see it on the calendar and get notified.</p>
        </div>
        <AdminNav />
      </header>

      <SessionForm courses={courses.map((course) => ({ id: course.id, code: course.code }))} />

      <section>
        <h2 className="flex items-center gap-2 text-lg font-semibold text-white"><CalendarClock className="h-5 w-5 text-sky-400" /> All sessions ({sessions.length})</h2>
        <ul className="mt-3 space-y-3">
          {sessions.map(({ session, courseCode }) => {
            const past = new Date(session.sessionAt).getTime() < nowMs;
            return (
              <li key={session.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-5 py-4">
                <div className="min-w-0">
                  <p className="font-mono text-[10px] uppercase text-slate-500">{courseCode ?? "General"} · {past ? "past" : "upcoming"}</p>
                  <p className="mt-0.5 font-medium text-white">{session.title}</p>
                  <p className="text-xs text-slate-500">{formatShortDate(new Date(session.sessionAt))}{session.meetingUrl ? ` · ${session.meetingUrl}` : ""}</p>
                </div>
                <DeleteContentButton kind="session" id={session.id} confirmMessage={`Delete "${session.title}"?`} />
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
