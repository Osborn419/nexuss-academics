import { redirect } from "next/navigation";
import { SquareStack } from "lucide-react";
import { AdminNav } from "@/components/admin/nav";
import { DeleteContentButton, FlashcardForm } from "@/components/admin/simple-forms";
import { isAdminProfile, getSessionProfile } from "@/lib/admin-guard";
import { getCourses, getFlashcards } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata = { title: "Flashcards" };

export default async function AdminFlashcardsPage() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login?next=/admin/flashcards");
  if (!(await isAdminProfile(profile))) redirect("/dashboard");

  const [courses, cards] = await Promise.all([getCourses(), getFlashcards()]);
  const courseMap = new Map(courses.map((course) => [course.id, course.code]));

  return (
    <div className="space-y-6 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Flashcards</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Revision decks</h1>
          <p className="mt-2 max-w-xl text-sm text-slate-400">Short question/answer pairs students flip through on the Flashcards page.</p>
        </div>
        <AdminNav />
      </header>

      <FlashcardForm courses={courses.map((course) => ({ id: course.id, code: course.code }))} />

      <section>
        <h2 className="flex items-center gap-2 text-lg font-semibold text-white"><SquareStack className="h-5 w-5 text-emerald-300" /> Cards ({cards.length})</h2>
        <ul className="mt-3 grid gap-2 sm:grid-cols-2">
          {cards.map((card) => (
            <li key={card.id} className="flex items-start justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-xs">
              <div className="min-w-0">
                <p className="font-mono text-[10px] uppercase text-slate-500">{courseMap.get(card.courseId)}{card.week ? ` · week ${card.week}` : ""}</p>
                <p className="mt-1 truncate font-medium text-slate-100" title={card.front}>{card.front}</p>
                <p className="truncate text-slate-500" title={card.back}>→ {card.back}</p>
              </div>
              <DeleteContentButton kind="flashcard" id={card.id} confirmMessage="Delete this card?" />
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
