import { redirect } from "next/navigation";
import { Megaphone } from "lucide-react";
import { AdminNav } from "@/components/admin/nav";
import { AnnouncementForm, DeleteContentButton } from "@/components/admin/simple-forms";
import { isAdminProfile, getSessionProfile } from "@/lib/admin-guard";
import { getAnnouncements, getCourses } from "@/lib/queries";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Announcements" };

export default async function AdminAnnouncementsPage() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login?next=/admin/announcements");
  if (!(await isAdminProfile(profile))) redirect("/dashboard");

  const [courses, announcements] = await Promise.all([getCourses(), getAnnouncements(40)]);

  return (
    <div className="space-y-6 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Announcements</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Broadcast to the group</h1>
          <p className="mt-2 max-w-xl text-sm text-slate-400">Every student is notified. Post course-specific or platform-wide messages.</p>
        </div>
        <AdminNav />
      </header>

      <AnnouncementForm courses={courses.map((course) => ({ id: course.id, code: course.code }))} />

      <section>
        <h2 className="text-lg font-semibold text-white">Published ({announcements.length})</h2>
        <ul className="mt-3 space-y-3">
          {announcements.map(({ announcement, courseCode }) => (
            <li key={announcement.id} className="flex flex-wrap items-start justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-5 py-4">
              <div className="min-w-0">
                <p className="text-[10px] text-slate-500">{courseCode ?? "Everyone"} · {formatDate(announcement.createdAt)}</p>
                <p className="mt-0.5 font-medium text-white">{announcement.title}</p>
                <p className="mt-1 line-clamp-2 max-w-2xl text-xs text-slate-400">{announcement.body}</p>
              </div>
              <DeleteContentButton kind="announcement" id={announcement.id} confirmMessage={`Delete "${announcement.title}"?`} />
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
