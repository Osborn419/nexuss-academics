import Link from "next/link";
import { redirect } from "next/navigation";
import {
  ArrowUpRight,
  ClipboardCheck,
  FileStack,
  Layers,
  Trophy,
  Users,
  BarChart3,
  Megaphone,
  CalendarClock,
  Presentation,
  SquareStack,
  MessagesSquare,
  ClipboardList,
  GraduationCap,
} from "lucide-react";
import { AdminNav } from "@/components/admin/nav";
import { SemesterForm } from "@/components/admin/semester-form";
import { getSessionProfile, isAdminProfile } from "@/lib/admin-guard";
import {
  getAdminAnalytics,
  getAttempts,
  getSemesterConfig,
  getSiteStats,
} from "@/lib/queries";
import { percent, formatDate } from "@/lib/format";
import { site } from "@/config/site";

export const dynamic = "force-dynamic";

export const metadata = { title: "Administrator" };

const manageLinks = [
  { href: "/admin/materials", title: "Materials", copy: "Upload slides, notes, past questions.", icon: FileStack },
  { href: "/admin/quizzes", title: "Exams & practice", copy: "Build auto-marked practice tests and formal exams.", icon: ClipboardCheck },
  { href: "/admin/courses", title: "Courses", copy: "Update course names, descriptions and tracks.", icon: Layers },
  { href: "/admin/students", title: "Students", copy: "Manage accounts and issue password-reset links.", icon: Users },
  { href: "/admin/assignments", title: "Assignments", copy: "Set deadlines, review submissions, give feedback.", icon: ClipboardList },
  { href: "/admin/announcements", title: "Announcements", copy: "Broadcast updates to every student.", icon: Megaphone },
  { href: "/admin/sessions", title: "Study sessions", copy: "Schedule live study sessions with meeting links.", icon: CalendarClock },
  { href: "/admin/presentations", title: "Presentations", copy: "Manage the presentation timetable and slides.", icon: Presentation },
  { href: "/admin/flashcards", title: "Flashcards", copy: "Add question cards for revision decks.", icon: SquareStack },
  { href: "/admin/forum", title: "Forum reports", copy: "Review reported posts and moderate the forum.", icon: MessagesSquare },
];

export default async function AdminDashboard() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login?next=/admin");
  if (!(await isAdminProfile(profile))) redirect("/dashboard");

  const [stats, analytics, attempts, semester] = await Promise.all([
    getSiteStats(),
    getAdminAnalytics(),
    getAttempts(),
    getSemesterConfig(),
  ]);

  const cards = [
    { label: "Students", value: analytics.students, icon: Users },
    { label: "Courses", value: stats.courses, icon: Layers },
    { label: "Materials", value: stats.materials, icon: FileStack },
    { label: "Exams", value: stats.quizzes, icon: ClipboardCheck },
    { label: "Attempts", value: stats.attempts, icon: Trophy },
    { label: "Enrolments", value: analytics.enrolments, icon: GraduationCap },
    { label: "Assignments in", value: analytics.submissions, icon: ClipboardList },
    { label: "Forum threads", value: analytics.threads, icon: MessagesSquare },
  ];

  return (
    <div className="space-y-8 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
            Administrator · {site.ownerRole}
          </p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">
            Welcome, {profile.displayName.split(" ")[0]}
          </h1>
          <p className="mt-2 text-sm text-slate-400">
            One administrator, total control: content, exams, students, forum and
            calendar. Keep this page bookmarked.
          </p>
        </div>
        <AdminNav />
      </header>

      <SemesterForm config={semester} nowISO={new Date().toISOString()} />

      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
        {cards.map((card) => (
          <div key={card.label} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <card.icon className="h-4 w-4 text-emerald-400/80" />
            <p className="mt-2 text-2xl font-semibold text-white">{card.value}</p>
            <p className="text-xs text-slate-400">{card.label}</p>
          </div>
        ))}
      </section>

      <section>
        <h2 className="flex items-center gap-2 text-lg font-semibold text-white">
          <BarChart3 className="h-5 w-5 text-sky-400" /> Manage the platform
        </h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {manageLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="group rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-emerald-400/40 hover:bg-emerald-400/5"
            >
              <link.icon className="h-5 w-5 text-emerald-300/80" />
              <p className="mt-2 flex items-center justify-between gap-1 text-sm font-semibold text-white">
                {link.title}
                <ArrowUpRight className="h-4 w-4 text-slate-600 transition group-hover:text-emerald-300" />
              </p>
              <p className="mt-1 text-xs leading-relaxed text-slate-400">{link.copy}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <h2 className="text-lg font-semibold text-white">Exam performance</h2>
          {analytics.quizStats.length === 0 ? (
            <p className="mt-4 text-sm text-slate-500">No exams yet.</p>
          ) : (
            <ul className="mt-4 space-y-2">
              {analytics.quizStats.map((quiz) => (
                <li
                  key={quiz.id}
                  className="flex items-center justify-between gap-3 rounded-xl bg-canvas/40 px-3.5 py-2.5 text-sm"
                >
                  <span className="min-w-0">
                    <span className="block truncate font-medium text-slate-200">
                      <span className="font-mono text-xs text-emerald-300">{quiz.courseCode}</span> · {quiz.title}
                    </span>
                    <span className="text-xs text-slate-500">{quiz.attempts} attempts</span>
                  </span>
                  <span className="shrink-0 text-xs font-semibold text-sky-300">
                    avg {quiz.average}%
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <h2 className="text-lg font-semibold text-white">Recent attempts</h2>
          {attempts.length === 0 ? (
            <p className="mt-4 text-sm text-slate-500">
              No attempts recorded yet — results appear here as students sit exams.
            </p>
          ) : (
            <ul className="mt-4 space-y-2">
              {attempts.slice(0, 8).map((attempt) => (
                <li
                  key={attempt.id}
                  className="flex items-center justify-between gap-3 rounded-xl bg-canvas/40 px-3.5 py-2.5 text-sm"
                >
                  <span className="min-w-0">
                    <span className="block truncate font-medium text-slate-200">{attempt.studentName}</span>
                    <span className="text-xs text-slate-500">{formatDate(attempt.createdAt)}</span>
                  </span>
                  <span className="shrink-0 text-xs font-semibold text-emerald-300">
                    {percent(attempt.score, attempt.maxScore)}%
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}
