import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft, FileDown, FileText } from "lucide-react";
import { FeedbackForm } from "@/components/admin/feedback-form";
import { AdminNav } from "@/components/admin/nav";
import { isAdminProfile, getSessionProfile } from "@/lib/admin-guard";
import { getAssignmentById, getSubmissionsForAssignment } from "@/lib/queries";
import { formatBytes, formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Submissions" };

export default async function AdminSubmissionsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login?next=/admin/assignments");
  if (!(await isAdminProfile(profile))) redirect("/dashboard");

  const { id } = await params;
  const assignmentId = Number(id);
  if (!Number.isFinite(assignmentId)) notFound();

  const [row, submissions] = await Promise.all([
    getAssignmentById(assignmentId),
    getSubmissionsForAssignment(assignmentId),
  ]);
  if (!row) notFound();

  return (
    <div className="space-y-6 pt-6">
      <Link href="/admin/assignments" className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-emerald-300">
        <ArrowLeft className="h-4 w-4" /> All assignments
      </Link>
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="font-mono text-xs text-emerald-300">{row.courseCode}</p>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight text-white">{row.assignment.title}</h1>
          <p className="mt-1 max-w-2xl text-sm text-slate-400">{row.assignment.description}</p>
          <p className="mt-2 text-xs text-slate-500">{row.assignment.maxPoints} points · {submissions.length} submission{submissions.length === 1 ? "" : "s"}</p>
        </div>
        <AdminNav />
      </header>

      {submissions.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-white/12 p-10 text-center text-sm text-slate-500">
          Nobody has submitted yet.
        </p>
      ) : (
        <ul className="space-y-4">
          {submissions.map(({ submission, studentName, email }) => (
            <li key={submission.id} className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-semibold text-white">{studentName}</p>
                  <p className="text-xs text-slate-500">{email} · submitted {formatDate(submission.submittedAt)}</p>
                  <a href={`/api/submissions/${submission.id}`} className="mt-2 inline-flex items-center gap-2 rounded-lg bg-emerald-400/10 px-3 py-1.5 text-xs font-medium text-emerald-200 ring-1 ring-emerald-400/25 hover:bg-emerald-400/20">
                    <FileDown className="h-3.5 w-3.5" /> {submission.fileName} ({formatBytes(submission.sizeBytes)})
                  </a>
                  {submission.note ? <p className="mt-2 max-w-xl text-xs leading-relaxed text-slate-400">Student note: {submission.note}</p> : null}
                </div>
                {submission.grade !== null ? (
                  <span className="rounded-full bg-sky-400/10 px-3 py-1 text-xs font-semibold text-sky-300 ring-1 ring-sky-400/30">
                    Graded {submission.grade}/{row.assignment.maxPoints}
                  </span>
                ) : (
                  <span className="rounded-full bg-amber-400/10 px-3 py-1 text-xs font-semibold text-amber-300 ring-1 ring-amber-400/30">Awaiting grade</span>
                )}
              </div>
              <FeedbackForm
                submissionId={submission.id}
                initialGrade={submission.grade}
                initialFeedback={submission.feedback}
                maxPoints={row.assignment.maxPoints}
              />
            </li>
          ))}
        </ul>
      )}
      <p className="flex items-center gap-2 text-xs text-slate-600"><FileText className="h-4 w-4" /> Only students and the administrator can open these files.</p>
    </div>
  );
}
