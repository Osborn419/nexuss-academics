import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, Trash2 } from "lucide-react";
import { AdminNav } from "@/components/admin/nav";
import { AssignmentCreateForm, DeleteContentButton } from "@/components/admin/simple-forms";
import { isAdminProfile, getSessionProfile } from "@/lib/admin-guard";
import { countSubmissions, getAssignments, getCourses } from "@/lib/queries";
import { formatShortDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Assignments" };

export default async function AdminAssignmentsPage() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login?next=/admin/assignments");
  if (!(await isAdminProfile(profile))) redirect("/dashboard");

  const [courses, assignments, submissionCounts] = await Promise.all([
    getCourses(),
    getAssignments(),
    countSubmissions(),
  ]);

  return (
    <div className="space-y-6 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Assignments</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Set and mark work</h1>
          <p className="mt-2 max-w-xl text-sm text-slate-400">Publish deadlines, receive private file submissions and grade with feedback. Students are notified automatically.</p>
        </div>
        <AdminNav />
      </header>

      <AssignmentCreateForm courses={courses.map((course) => ({ id: course.id, code: course.code }))} />

      <section>
        <h2 className="text-lg font-semibold text-white">All assignments ({assignments.length})</h2>
        {assignments.length === 0 ? (
          <p className="mt-3 text-sm text-slate-500">Nothing yet — create the first one above.</p>
        ) : (
          <ul className="mt-4 space-y-3">
            {assignments.map(({ assignment, courseCode }) => (
              <li key={assignment.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-5 py-4">
                <div className="min-w-0">
                  <p className="font-mono text-[11px] text-emerald-300">{courseCode}</p>
                  <p className="mt-0.5 font-medium text-white">{assignment.title}</p>
                  <p className="mt-0.5 text-xs text-slate-500">
                    {assignment.dueDate ? `Due ${formatShortDate(new Date(assignment.dueDate))}` : "No deadline"} · {assignment.maxPoints} pts · {submissionCounts.get(assignment.id) ?? 0} submitted
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Link href={`/admin/assignments/${assignment.id}`} className="inline-flex items-center gap-1.5 rounded-lg bg-white/5 px-3 py-2 text-xs font-medium text-slate-200 ring-1 ring-white/10 hover:bg-white/10">
                    Review <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                  <DeleteContentButton kind="assignment" id={assignment.id} endpoint={`/api/assignments?id=${assignment.id}`} confirmMessage={`Delete "${assignment.title}" and ALL student submissions for it?`} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
