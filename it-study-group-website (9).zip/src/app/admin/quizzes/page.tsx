import Link from "next/link";
import { redirect } from "next/navigation";
import { ExternalLink } from "lucide-react";
import { AdminNav } from "@/components/admin/nav";
import { QuizBuilder } from "@/components/admin/quiz-builder";
import { QuizPublishButton } from "@/components/admin/quiz-publish-button";
import { DeleteButton } from "@/components/admin/delete-button";
import { isAdmin } from "@/lib/admin-guard";
import { getCourses, getQuizzes, getSemesterConfig } from "@/lib/queries";
import { getSemesterStatus } from "@/lib/semester";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Manage tests" };

export default async function AdminQuizzesPage() {
  if (!(await isAdmin())) redirect("/admin/login");

  const [courses, quizzes, semester] = await Promise.all([
    getCourses(),
    getQuizzes(undefined, true),
    getSemesterConfig(),
  ]);
  const status = getSemesterStatus(semester);
  const courseMap = new Map(courses.map((course) => [course.id, course]));

  return (
    <div className="space-y-8 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
            Assessment
          </p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">
            Practice tests
          </h1>
          <p className="mt-2 text-sm text-slate-400">
            Every question is graded on the server the moment a student
            submits.
          </p>
        </div>
        <AdminNav />
      </header>

      <QuizBuilder
        defaultWeek={status.focusWeek}
        totalWeeks={status.totalWeeks}
        courses={courses.map((course) => ({
          id: course.id,
          code: course.code,
          title: course.title,
        }))}
      />

      <section>
        <h2 className="text-lg font-semibold text-white">
          Published tests ({quizzes.length})
        </h2>
        <ul className="mt-4 space-y-2">
          {quizzes.map((quiz) => (
            <li
              key={quiz.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3"
            >
              <div className="min-w-0">
                <p className="truncate font-medium text-white">{quiz.title}</p>
                <p className="text-xs text-slate-500">
                  {courseMap.get(quiz.courseId)?.code ?? "—"} ·{" "}
                  {quiz.questionCount} questions · {quiz.timeLimitMinutes} min ·{" "}
                  {quiz.attemptCount} attempts · {formatDate(quiz.createdAt)}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <Link
                  href={`/quizzes/${quiz.id}`}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-300 ring-1 ring-white/10 transition hover:bg-white/10"
                >
                  <ExternalLink className="h-3.5 w-3.5" /> Open
                </Link>
                 <QuizPublishButton id={quiz.id} published={quiz.published} />
                 <DeleteButton
                   endpoint={`/api/admin/quizzes?id=${quiz.id}`}
                  confirmMessage={`Delete "${quiz.title}" and all its attempts?`}
                />
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
