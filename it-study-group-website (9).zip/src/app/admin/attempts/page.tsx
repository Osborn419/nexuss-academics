import { redirect } from "next/navigation";
import { AdminNav } from "@/components/admin/nav";
import { isAdmin } from "@/lib/admin-guard";
import { getAttempts, getQuizzes } from "@/lib/queries";
import { formatDate, formatDuration, percent } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Attempts" };

export default async function AdminAttemptsPage() {
  if (!(await isAdmin())) redirect("/admin/login");

  const [attempts, quizzes] = await Promise.all([getAttempts(), getQuizzes()]);
  const quizMap = new Map(quizzes.map((quiz) => [quiz.id, quiz]));

  const average =
    attempts.length > 0
      ? Math.round(
          attempts.reduce(
            (total, attempt) => total + percent(attempt.score, attempt.maxScore),
            0,
          ) / attempts.length,
        )
      : 0;

  return (
    <div className="space-y-8 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
            Insights
          </p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">
            Attempts
          </h1>
          <p className="mt-2 text-sm text-slate-400">
            {attempts.length} attempts recorded · class average {average}%
          </p>
        </div>
        <AdminNav />
      </header>

      {attempts.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-white/12 p-12 text-center text-sm text-slate-500">
          No attempts yet. Publish a test and share the link with the group.
        </p>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-white/10">
          <table className="w-full min-w-[46rem] text-left text-sm">
            <thead className="bg-white/[0.04] text-xs uppercase tracking-wide text-slate-400">
              <tr>
                <th className="px-4 py-3 font-medium">Student</th>
                <th className="px-4 py-3 font-medium">Test</th>
                <th className="px-4 py-3 font-medium">Track</th>
                <th className="px-4 py-3 font-medium">Score</th>
                <th className="px-4 py-3 font-medium">Time</th>
                <th className="px-4 py-3 font-medium">Submitted</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {attempts.map((attempt) => (
                <tr key={attempt.id} className="bg-white/[0.02]">
                  <td className="px-4 py-3 font-medium text-slate-100">
                    {attempt.studentName}
                  </td>
                  <td className="px-4 py-3 text-slate-400">
                    {quizMap.get(attempt.quizId)?.title ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-500">
                    {attempt.track || "—"}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`font-semibold ${
                        percent(attempt.score, attempt.maxScore) >= 70
                          ? "text-emerald-300"
                          : percent(attempt.score, attempt.maxScore) >= 50
                            ? "text-amber-300"
                            : "text-rose-300"
                      }`}
                    >
                      {attempt.score}/{attempt.maxScore}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-500">
                    {formatDuration(attempt.durationSeconds)}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-500">
                    {formatDate(attempt.createdAt)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
