import { redirect } from "next/navigation";
import { Trash2, ShieldCheck, MessagesSquare } from "lucide-react";
import { AdminNav } from "@/components/admin/nav";
import { DeleteModerationButton, DismissReportButton } from "@/components/admin/moderation-buttons";
import { isAdminProfile, getSessionProfile } from "@/lib/admin-guard";
import { getForumReports, getForumThreads } from "@/lib/queries";
import { db } from "@/db";
import { forumReplies, forumThreads } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = { title: "Forum moderation" };

export default async function AdminForumPage() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login?next=/admin/forum");
  if (!(await isAdminProfile(profile))) redirect("/dashboard");

  const [reports, recentThreads] = await Promise.all([getForumReports(), getForumThreads({})]);
  const threadIds = reports.map((r) => r.report.threadId).filter((id): id is number => id !== null);
  const replyIds = reports.map((r) => r.report.replyId).filter((id): id is number => id !== null);

  const reportedThreads = threadIds.length
    ? await db.select({ id: forumThreads.id, title: forumThreads.title, body: forumThreads.body }).from(forumThreads).where(inArray(forumThreads.id, threadIds))
    : [];
  const reportedReplies = replyIds.length
    ? await db.select({ id: forumReplies.id, body: forumReplies.body, threadId: forumReplies.threadId }).from(forumReplies).where(inArray(forumReplies.id, replyIds))
    : [];
  const threadMap = new Map(reportedThreads.map((t) => [t.id, t]));
  const replyMap = new Map(reportedReplies.map((r) => [r.id, r]));

  return (
    <div className="space-y-6 pt-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Forum</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Moderation</h1>
          <p className="mt-2 max-w-xl text-sm text-slate-400">Review reports, remove bad content or dismiss them. Deleting content is permanent.</p>
        </div>
        <AdminNav />
      </header>

      <section>
        <h2 className="flex items-center gap-2 text-lg font-semibold text-white"><ShieldCheck className="h-5 w-5 text-amber-300" /> Open reports ({reports.length})</h2>
        {reports.length === 0 ? (
          <p className="mt-3 text-sm text-slate-500">Nothing reported — the forum is behaving.</p>
        ) : (
          <ul className="mt-3 space-y-3">
            {reports.map(({ report, reporterName }) => {
              const target = replyMap.get(report.replyId ?? -1) ?? (report.threadId ? threadMap.get(report.threadId) : undefined);
              return (
                <li key={report.id} className="rounded-2xl border border-amber-400/20 bg-amber-400/5 p-4 text-sm">
                  <p className="text-[10px] uppercase tracking-wider text-amber-300">
                    {report.replyId ? "Reply" : "Thread"} reported by {reporterName} · {formatDate(report.createdAt)}
                  </p>
                  <p className="mt-1.5 line-clamp-3 text-slate-200">
                    {"title" in (target ?? {}) ? (target as { title: string }).title : (target as { body?: string })?.body ?? "(content already deleted)"}
                  </p>
                  <p className="mt-1 text-xs text-slate-500">Reason: {report.reason}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <DeleteModerationButton kind={report.replyId ? "reply" : "thread"} id={(report.replyId ?? report.threadId)!} label="Delete content" />
                    <DismissReportButton id={report.id} />
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <section>
        <h2 className="flex items-center gap-2 text-lg font-semibold text-white"><MessagesSquare className="h-5 w-5 text-sky-400" /> Recent threads</h2>
        <ul className="mt-3 space-y-2">
          {recentThreads.slice(0, 15).map(({ thread, authorName, courseCode, replyCount }) => (
            <li key={thread.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm">
              <div className="min-w-0">
                <p className="truncate font-medium text-slate-100">{thread.title}</p>
                <p className="text-xs text-slate-500">{courseCode ?? "General"} · {authorName} · {replyCount} replies · {formatDate(thread.createdAt)}</p>
              </div>
              <DeleteModerationButton kind="thread" id={thread.id} label="Delete" />
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
