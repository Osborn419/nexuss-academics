import Link from "next/link";
import { Presentation, MonitorPlay } from "lucide-react";
import { getPresentations } from "@/lib/queries";
import { formatShortDate } from "@/lib/format";
import { slugify } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Presentation centre",
  description: "Presentations, slides and the group presentation schedule.",
};

export default async function PresentationsPage() {
  const presentations = await getPresentations();

  return (
    <div className="space-y-6 pt-6">
      <header className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Presentation centre</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Presentations &amp; slide decks</h1>
        <p className="mt-2 text-sm text-slate-400">
          The group timetable, course presentations and shared decks — open any deck in the slide viewer.
        </p>
      </header>

      {presentations.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/12 p-12 text-center">
          <MonitorPlay className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm text-slate-400">No presentations scheduled yet — the administrator adds them here.</p>
        </div>
      ) : (
        <ul className="grid gap-4 md:grid-cols-2">
          {presentations.map(({ presentation, courseCode }) => (
            <li key={presentation.id} className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                {courseCode ? <span className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-emerald-300">{courseCode}</span> : null}
                {presentation.week ? <span>Week {presentation.week}</span> : null}
                {presentation.sessionDate ? <span>· {formatShortDate(new Date(presentation.sessionDate))}</span> : null}
              </div>
              <h2 className="mt-2 flex items-start gap-2 text-lg font-semibold text-white">
                <Presentation className="mt-1 h-5 w-5 shrink-0 text-violet-300" />
                {presentation.title}
              </h2>
              {presentation.presenter ? <p className="mt-1 text-sm text-slate-400">By {presentation.presenter}</p> : null}
              {presentation.notes ? <p className="mt-2 text-sm leading-relaxed text-slate-400">{presentation.notes}</p> : null}
              {presentation.materialId ? (
                <Link href={`/slides/${presentation.materialId}`} className="mt-4 inline-flex items-center gap-2 rounded-xl bg-violet-400/15 px-4 py-2 text-xs font-semibold text-violet-200 ring-1 ring-violet-400/30 hover:bg-violet-400/25">
                  Open the slides
                </Link>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
