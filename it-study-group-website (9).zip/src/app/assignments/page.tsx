import Link from "next/link";
import { CalendarClock, ClipboardList, GraduationCap } from "lucide-react";
import { AssignmentSubmitForm } from "@/components/assignment-submit";
import { getCurrentProfile } from "@/lib/auth";
import { getAssignments, getMySubmissions } from "@/lib/queries";
import { formatDate, formatShortDate, formatBytes } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Assignments",
  description: "Deadlines, file submissions and administrator feedback for the group.",
};

export default async function AssignmentsPage() {
  const profile = await getCurrentProfile();
  const [assignments, submissions] = await Promise.all([
    getAssignments(),
    profile ? getMySubmissions(profile.id) : Promise.resolve([]),
  ]);
  const submissionMap = new Map(submissions.map((row) => [row.assignment.id, row.submission]));

  const nowMs = new Date().getTime();
  return (
    <div className="space-y-6 pt-6">
      <header className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Assignments</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Submit real work, get real feedback</h1>
        <p className="mt-2 text-sm text-slate-400">
          Your submissions are private — only you and the administrator can open them.
        </p>
        {!profile ? (
          <Link href="/login?next=/assignments" className="mt-4 inline-flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2 text-sm text-white ring-1 ring-white/15">
            Sign in to submit
          </Link>
        ) : null}
      </header>

      {assignments.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/12 p-12 text-center">
          <ClipboardList className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm text-slate-400">No assignments published yet.</p>
        </div>
      ) : (
        <ul className="space-y-5">
          {assignments.map(({ assignment, courseCode, courseTitle }) => {
            const submission = submissionMap.get(assignment.id);
            const dueDate = assignment.dueDate ? new Date(assignment.dueDate) : null;
            const overdue = dueDate && dueDate.getTime() < nowMs;
            return (
              <li key={assignment.id} className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-mono text-[11px] text-emerald-300">{courseCode} · {courseTitle}</p>
                    <h2 className="mt-1 text-lg font-semibold text-white">{assignment.title}</h2>
                    {assignment.description ? <p className="mt-1.5 max-w-3xl whitespace-pre-wrap text-sm leading-relaxed text-slate-400">{assignment.description}</p> : null}
                    <p className="mt-3 flex flex-wrap items-center gap-3 text-xs text-slate-500">
                      <span className="inline-flex items-center gap-1.5"><CalendarClock className="h-3.5 w-3.5" />{dueDate ? `Due ${formatShortDate(dueDate)}` : "No deadline"}{overdue && !submission ? " · closed" : ""}</span>
                      <span>{assignment.maxPoints} points</span>
                    </p>
                  </div>
                  <span className={`shrink-0 rounded-full px-3 py-1 text-[11px] font-semibold ring-1 ${
                    submission
                      ? submission.grade !== null
                        ? "bg-sky-400/10 text-sky-300 ring-sky-400/30"
                        : "bg-emerald-400/10 text-emerald-300 ring-emerald-400/30"
                      : "bg-white/5 text-slate-400 ring-white/15"
                  }`}>
                    {submission ? (submission.grade !== null ? `Marked: ${submission.grade}/${assignment.maxPoints}` : "Submitted") : "Not submitted"}
                  </span>
                </div>

                {submission ? (
                  <div className="mt-4 rounded-xl border border-white/10 bg-canvas/40 px-4 py-3 text-sm">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <a href={`/api/submissions/${submission.id}`} className="font-medium text-emerald-300 hover:text-emerald-200">
                        {submission.fileName} · {formatBytes(submission.sizeBytes)}
                      </a>
                      <span className="text-xs text-slate-500">submitted {formatDate(submission.submittedAt)}</span>
                    </div>
                    {submission.note ? <p className="mt-2 text-xs text-slate-400">Your note: {submission.note}</p> : null}
                    {submission.feedback ? (
                      <div className="mt-3 rounded-lg border border-sky-400/20 bg-sky-400/5 px-3 py-2">
                        <p className="text-[10px] font-semibold uppercase tracking-wider text-sky-300">Administrator feedback</p>
                        <p className="mt-1 whitespace-pre-wrap text-sm text-slate-200">{submission.feedback}</p>
                      </div>
                    ) : null}
                  </div>
                ) : null}

                {profile && !overdue ? <AssignmentSubmitForm assignmentId={assignment.id} submitted={Boolean(submission)} /> : null}
              </li>
            );
          })}
        </ul>
      )}

      <p className="flex items-center gap-2 text-xs text-slate-600"><GraduationCap className="h-4 w-4" /> Files are stored privately and are only visible to you and the administrator.</p>
    </div>
  );
}
