import Link from "next/link";
import { FileStack, Search, SlidersHorizontal } from "lucide-react";
import { MaterialRow } from "@/components/material-row";
import { getCourses, getSemesterConfig, searchMaterials } from "@/lib/queries";
import { getSemesterStatus } from "@/lib/semester";
import { kindMeta, materialKinds } from "@/lib/materials";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Material library",
  description:
    "Every slide deck, lecture note, past question, practical and link shared by the study group.",
};

export default async function MaterialsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; course?: string; kind?: string; week?: string }>;
}) {
  const { q, course, kind, week } = await searchParams;
  const [courses, semester] = await Promise.all([getCourses(), getSemesterConfig()]);
  const status = getSemesterStatus(semester);
  const weekNumber = Number(week);
  const results = await searchMaterials({
    query: q?.trim() || undefined,
    courseId: course ? Number(course) : undefined,
    kind: kind || undefined,
    week: Number.isFinite(weekNumber) && weekNumber > 0 ? weekNumber : undefined,
  });
  const courseCodeById = new Map(courses.map((item) => [item.id, item.code]));
  const todayWeek = status.phase === "teaching" ? status.currentWeek : undefined;

  const selectClass =
    "rounded-xl border border-white/12 bg-canvas/70 px-3.5 py-2.5 text-sm text-white outline-none transition focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20";

  return (
    <div className="space-y-8 pt-6">
      <header className="max-w-3xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">
          Material library
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          Everything we have shared
        </h1>
        <p className="mt-3 text-base leading-relaxed text-slate-400">
          Slides, notes, past questions, practicals and links for all six courses.
          Search by title, topic or course code, or filter by week.
        </p>
      </header>

      <form method="get" className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 sm:p-5">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <input
              name="q"
              defaultValue={q ?? ""}
              placeholder="Search slides, notes, past questions…"
              className="w-full rounded-xl border border-white/12 bg-canvas/70 py-2.5 pl-10 pr-4 text-sm text-white outline-none transition placeholder:text-slate-600 focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20"
            />
          </div>

          <select name="course" defaultValue={course ?? ""} className={selectClass}>
            <option value="">All courses</option>
            {courses.map((item) => (
              <option key={item.id} value={item.id}>
                {item.code} — {item.title}
              </option>
            ))}
          </select>

          <select name="week" defaultValue={week ?? ""} className={selectClass}>
            <option value="">All weeks</option>
            {Array.from({ length: status.totalWeeks + 3 }, (_, index) => index + 1).map((value) => (
              <option key={value} value={value}>
                Week {value}
                {value === todayWeek ? " (this week)" : ""}
              </option>
            ))}
          </select>

          <select name="kind" defaultValue={kind ?? ""} className={selectClass}>
            <option value="">All types</option>
            {materialKinds.map((item) => (
              <option key={item} value={item}>
                {kindMeta(item).label}
              </option>
            ))}
          </select>

          <button
            type="submit"
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-sky-400 px-5 py-2.5 text-sm font-semibold text-canvas transition hover:brightness-110"
          >
            <SlidersHorizontal className="h-4 w-4" /> Filter
          </button>
        </div>
      </form>

      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-slate-400">
          {results.length} material{results.length === 1 ? "" : "s"} found
        </p>
        {q || course || kind || week ? (
          <Link href="/materials" className="text-sm font-medium text-emerald-300 hover:text-emerald-200">
            Clear filters
          </Link>
        ) : null}
      </div>

      {results.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/12 p-12 text-center">
          <FileStack className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm text-slate-400">
            Nothing matched that search. Try a different keyword or clear the filters.
          </p>
        </div>
      ) : (
        <ul className="space-y-3">
          {results.map((row) => (
            <MaterialRow
              key={row.material.id}
              material={row.material}
              courseCode={courseCodeById.get(row.material.courseId) ?? row.courseCode}
              currentWeek={todayWeek}
            />
          ))}
        </ul>
      )}
    </div>
  );
}
