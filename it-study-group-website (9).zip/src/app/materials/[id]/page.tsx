import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Download, ExternalLink, FileText, Presentation } from "lucide-react";
import { KindBadge, WeekBadge } from "@/components/icons";
import { getCourseById, getFileMeta, getMaterialById } from "@/lib/queries";
import { getCurrentProfile } from "@/lib/auth";
import { BookmarkButton } from "@/components/bookmark-button";
import { renderMarkdown } from "@/lib/markdown";
import { formatBytes, formatDate, slugify } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const material = await getMaterialById(Number(id));
  if (!material) return { title: "Material not found" };
  return { title: material.title, description: material.description };
}

export default async function MaterialPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const material = await getMaterialById(Number(id));
  if (!material) notFound();

  const profile = await getCurrentProfile();
  const [course, file] = await Promise.all([
    getCourseById(material.courseId),
    material.fileId ? getFileMeta(material.fileId) : Promise.resolve(null),
  ]);

  const lowerName = file?.filename.toLowerCase() ?? "";
  const isPdf = file ? file.mimeType === "application/pdf" || lowerName.endsWith(".pdf") : false;
  const isImage = file ? file.mimeType.startsWith("image/") : false;
  const isVideo = file ? file.mimeType.startsWith("video/") : false;
  const isDeck = material.kind === "slides" && Boolean(material.content);

  return (
    <div className="space-y-8 pt-6">
      <Link
        href={course ? `/courses/${slugify(course.code)}` : "/materials"}
        className="inline-flex items-center gap-1.5 text-sm text-slate-400 transition hover:text-emerald-300"
      >
        <ArrowLeft className="h-4 w-4" /> Back to {course?.code ?? "the library"}
      </Link>

      <header className="max-w-3xl">
        <div className="flex flex-wrap items-center gap-2">
          <KindBadge kind={material.kind} />
          <WeekBadge week={material.week} />
          {course ? (
            <span className="rounded-md bg-white/5 px-2 py-0.5 font-mono text-[11px] text-slate-400">
              {course.code}
            </span>
          ) : null}
        </div>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          {material.title}
        </h1>
        {material.description ? (
          <p className="mt-3 text-base leading-relaxed text-slate-400">{material.description}</p>
        ) : null}
        <p className="mt-3 text-xs text-slate-500">
          Posted by {material.postedBy} · {formatDate(material.createdAt)}
          {file ? ` · ${file.filename} · ${formatBytes(file.sizeBytes)}` : ""}
        </p>

        <div className="mt-5 flex flex-wrap gap-3">
          {isDeck ? (
            <Link
              href={`/slides/${material.id}`}
              className="inline-flex items-center gap-2 rounded-xl bg-amber-400/15 px-4 py-2.5 text-sm font-semibold text-amber-200 ring-1 ring-amber-400/30 transition hover:bg-amber-400/25"
            >
              <Presentation className="h-4 w-4" /> Present as slides
            </Link>
          ) : null}
          {file ? (
            <>
              <a
                href={`/api/files/${file.id}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-xl bg-emerald-400/15 px-4 py-2.5 text-sm font-semibold text-emerald-200 ring-1 ring-emerald-400/30 transition hover:bg-emerald-400/25"
              >
                <ExternalLink className="h-4 w-4" /> Open in new tab
              </a>
              <a
                href={`/api/files/${file.id}?download=1`}
                className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm font-semibold text-slate-100 transition hover:bg-white/10"
              >
                <Download className="h-4 w-4" /> Download
              </a>
            </>
          ) : null}
          {profile ? <BookmarkButton materialId={material.id} compact={false} /> : null}
          {material.url ? (
            <a
              href={material.url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm font-semibold text-slate-100 transition hover:bg-white/10"
            >
              <ExternalLink className="h-4 w-4" /> Open the link
            </a>
          ) : null}
        </div>
      </header>

      {file && isPdf ? (
        <div className="space-y-2">
          <iframe
            src={`/api/files/${file.id}`}
            title={material.title}
            className="h-[80vh] w-full rounded-2xl border border-white/10 bg-white"
          />
          <p className="text-xs text-slate-500">
            On a phone and the preview is blank? Use “Open in new tab” or “Download”.
          </p>
        </div>
      ) : null}

      {file && isImage ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={`/api/files/${file.id}`}
          alt={material.title}
          className="max-h-[80vh] w-auto rounded-2xl border border-white/10"
        />
      ) : null}

      {file && isVideo ? (
        <video
          src={`/api/files/${file.id}`}
          controls
          className="w-full rounded-2xl border border-white/10 bg-black"
        />
      ) : null}

      {file && !isPdf && !isImage && !isVideo ? (
        <div className="flex items-start gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-6">
          <FileText className="mt-0.5 h-6 w-6 shrink-0 text-emerald-300" />
          <div>
            <p className="font-semibold text-white">{file.filename}</p>
            <p className="mt-1 text-sm text-slate-400">
              This file type can&apos;t be previewed in the browser. Download it and
              open it with Word, PowerPoint, Excel or the matching app.
            </p>
          </div>
        </div>
      ) : null}

      {material.content ? (
        <article className="rounded-3xl border border-white/10 bg-white/[0.03] px-6 py-8 sm:px-10">
          <div
            className="note-body max-w-none"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(material.content) }}
          />
        </article>
      ) : null}
    </div>
  );
}
