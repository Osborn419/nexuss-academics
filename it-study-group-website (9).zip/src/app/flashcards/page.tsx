import Link from "next/link";
import { SquareStack } from "lucide-react";
import { FlashcardDeck } from "@/components/flashcard-deck";
import { getCourses, getFlashcards } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Flashcards",
  description: "Revision flashcards for all seven courses.",
};

export default async function FlashcardsPage({
  searchParams,
}: {
  searchParams: Promise<{ course?: string }>;
}) {
  const { course } = await searchParams;
  const courses = await getCourses();
  const courseId = course ? Number(course) : undefined;
  const cards = await getFlashcards(Number.isFinite(Number(courseId)) ? courseId : undefined);
  const selected = courses.find((item) => String(item.id) === course);

  return (
    <div className="mx-auto max-w-3xl space-y-6 pt-6">
      <header>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-400/90">Flashcards</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white">Rapid revision decks</h1>
        <p className="mt-2 text-sm text-slate-400">Flip through bite-size questions. Arrow keys move, Space flips.</p>
      </header>

      <div className="flex flex-wrap gap-2">
        <Link href="/flashcards" className={`rounded-lg px-3 py-2 text-xs font-medium ring-1 ${!course ? "bg-white/10 text-white ring-white/20" : "bg-white/5 text-slate-300 ring-white/10 hover:bg-white/10"}`}>All cards ({cards.length})</Link>
        {courses.map((item) => (
          <Link key={item.id} href={`/flashcards?course=${item.id}`} className={`rounded-lg px-3 py-2 font-mono text-xs font-medium ring-1 ${course === String(item.id) ? "bg-white/10 text-white ring-white/20" : "bg-white/5 text-slate-300 ring-white/10 hover:bg-white/10"}`}>
            {item.code}
          </Link>
        ))}
      </div>

      <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
        {selected ? <p className="mb-4 text-sm font-medium text-slate-400">{selected.code} — {selected.title}</p> : null}
        {cards.length === 0 ? (
          <div className="py-8 text-center">
            <SquareStack className="mx-auto h-8 w-8 text-slate-600" />
            <p className="mt-3 text-sm text-slate-500">No cards here yet — the administrator can add them from the admin panel.</p>
          </div>
        ) : (
          <FlashcardDeck key={course ?? "all"} cards={cards.map((card) => ({ id: card.id, front: card.front, back: card.back }))} />
        )}
      </div>
    </div>
  );
}
