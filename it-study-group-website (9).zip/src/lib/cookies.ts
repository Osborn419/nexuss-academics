/** Shared cookie name (no server-only imports so middleware/proxy can use it). */
export const SESSION_COOKIE = "nexus_session";
