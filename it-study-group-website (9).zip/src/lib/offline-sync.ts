/**
 * Offline action queue for the signed-in student.
 *
 * Rules:
 *  - bookmark / progress changes made without a connection are queued locally
 *  - the queue is replayed in order when the connection returns or the tab regains focus
 *  - every request carries the moment the student made the change; if the server
 *    already holds a NEWER change (another device), the server answers 409 and we
 *    keep the server's state instead of overwriting it
 *  - failed items are retried, and repeatedly failing items are surfaced rather
 *    than silently dropped
 *
 * Client-only module: never import from server code.
 */

export type SyncKind = "bookmark" | "progress";

export interface PendingAction {
  id: string;
  kind: SyncKind;
  payload: { materialId?: number; courseId?: number; week?: number };
  clientUpdatedAt: string;
  attempts: number;
  lastError?: string;
}

export interface SyncStatus {
  online: boolean;
  pending: number;
  syncing: boolean;
  conflicts: number;
  failed: number;
  needsAuth: boolean;
  lastSyncedAt: number | null;
  notice: string | null;
}

type Listener = (status: SyncStatus) => void;

const STORAGE_KEY = "nexus_pending_sync_v1";
const listeners = new Set<Listener>();

const status: SyncStatus = {
  online: typeof navigator === "undefined" ? true : navigator.onLine,
  pending: 0,
  syncing: false,
  conflicts: 0,
  failed: 0,
  needsAuth: false,
  lastSyncedAt: null,
  notice: null,
};

function notify() {
  for (const listener of listeners) listener({ ...status });
}

export function subscribeSync(listener: Listener): () => void {
  listeners.add(listener);
  listener({ ...status });
  return () => listeners.delete(listener);
}

function safeStorage(): Storage | null {
  try {
    const probe = "__nexus_sync_probe__";
    window.localStorage.setItem(probe, "1");
    window.localStorage.removeItem(probe);
    return window.localStorage;
  } catch {
    return null;
  }
}

export function readQueue(): PendingAction[] {
  const storage = safeStorage();
  if (!storage) return [];
  try {
    const raw = storage.getItem(STORAGE_KEY);
    const parsed = raw ? (JSON.parse(raw) as PendingAction[]) : [];
    status.pending = Array.isArray(parsed) ? parsed.length : 0;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeQueue(queue: PendingAction[]) {
  const storage = safeStorage();
  status.pending = queue.length;
  if (storage) storage.setItem(STORAGE_KEY, JSON.stringify(queue));
}

function setNotice(notice: string | null) {
  status.notice = notice;
  notify();
}

function clearNoticeAfter(ms: number) {
  window.setTimeout(() => {
    if (status.notice) {
      status.notice = null;
      notify();
    }
  }, ms);
}

export function reportOfflineChange(description: string) {
  setNotice(`Offline — ${description} saved on this device`);
  clearNoticeAfter(6000);
}

export function reportOnlineRequired(description: string) {
  setNotice(`${description} needs an internet connection`);
  clearNoticeAfter(6000);
}

async function send(action: PendingAction): Promise<Response> {
  return fetch(`/api/me?action=${action.kind}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...action.payload, clientUpdatedAt: action.clientUpdatedAt }),
  });
}

function enqueue(action: PendingAction) {
  const queue = readQueue();
  queue.push(action);
  writeQueue(queue);
  notify();
}

/**
 * Apply one change now when online, or queue it when offline.
 * Never silently overwrites a newer server value: a 409 is returned to the caller.
 */
export async function postStudentAction(
  kind: SyncKind,
  payload: PendingAction["payload"],
): Promise<
  | { outcome: "ok"; data: Record<string, unknown> }
  | { outcome: "queued" }
  | { outcome: "conflict"; server: Record<string, unknown> }
  | { outcome: "auth" }
  | { outcome: "error"; message: string }
> {
  const action: PendingAction = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    kind,
    payload,
    clientUpdatedAt: new Date().toISOString(),
    attempts: 0,
  };

  const offline = typeof navigator !== "undefined" && navigator.onLine === false;
  if (offline) {
    enqueue(action);
    return { outcome: "queued" };
  }

  try {
    const response = await send(action);
    if (response.status === 401) return { outcome: "auth" };
    if (response.status === 409) {
      const data = (await response.json().catch(() => ({}))) as { server?: Record<string, unknown> };
      setNotice("That item changed on another device — showing the newest online state");
      clearNoticeAfter(7000);
      return { outcome: "conflict", server: data.server ?? {} };
    }
    const data = (await response.json().catch(() => ({}))) as Record<string, unknown>;
    if (!response.ok) {
      throw new Error(String(data.error || `Server error (${response.status})`));
    }
    return { outcome: "ok", data };
  } catch (error) {
    // Request never reached the server: keep the change, retry when we reconnect.
    enqueue(action);
    const message = error instanceof Error ? error.message : "Connection failed";
    status.failed = 0;
    setNotice(`Offline — queued to sync when the connection returns`);
    clearNoticeAfter(6000);
    void message;
    return { outcome: "queued" };
  }
}

let flushing = false;

/** Replay queued changes in the order they were made. */
export async function flushPending(): Promise<void> {
  if (flushing) return;
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    status.online = false;
    notify();
    return;
  }

  const queue = readQueue();
  if (queue.length === 0) {
    status.syncing = false;
    notify();
    return;
  }

  flushing = true;
  status.syncing = true;
  status.needsAuth = false;
  notify();

  const remaining: PendingAction[] = [];
  let conflicts = 0;
  let synced = 0;

  for (const action of queue) {
    try {
      const response = await send(action);
      if (response.status === 401) {
        // Not signed in: keep everything queued so nothing is lost.
        status.needsAuth = true;
        remaining.push(action, ...queue.slice(queue.indexOf(action) + 1));
        break;
      }
      if (response.status === 409) {
        const data = (await response.json().catch(() => ({}))) as { server?: Record<string, unknown> };
        conflicts += 1;
        void data.server;
        continue;
      }
      if (!response.ok) {
        action.attempts += 1;
        action.lastError = `HTTP ${response.status}`;
        if (action.attempts < 5) remaining.push(action);
        else status.failed += 1;
        continue;
      }
      synced += 1;
    } catch {
      // Connection dropped mid-sync: keep this and every later action queued.
      remaining.push(action, ...queue.slice(queue.indexOf(action) + 1));
      break;
    }
  }

  writeQueue(remaining);
  status.syncing = false;
  if (synced > 0) status.lastSyncedAt = Date.now();
  if (conflicts > 0) {
    status.conflicts += conflicts;
    status.notice = `${conflicts} change${conflicts === 1 ? "" : "s"} synced to the newest online state (another device was newer)`;
    clearNoticeAfter(9000);
  } else if (remaining.length === 0 && synced > 0) {
    status.notice = `${synced} offline change${synced === 1 ? "" : "s"} synced`;
    clearNoticeAfter(5000);
  } else if (remaining.length > 0) {
    status.notice = `${remaining.length} change${remaining.length === 1 ? "" : "s"} still waiting to sync`;
    clearNoticeAfter(7000);
  } else {
    status.notice = null;
  }
  flushing = false;
  notify();
}

/** Wire browser connectivity events once from the UI layer. */
export function initSyncRuntime(): () => void {
  const goOnline = () => {
    status.online = true;
    notify();
    void flushPending();
  };
  const goOffline = () => {
    status.online = false;
    notify();
  };
  const onFocus = () => void flushPending();

  window.addEventListener("online", goOnline);
  window.addEventListener("offline", goOffline);
  window.addEventListener("focus", onFocus);
  void flushPending();

  return () => {
    window.removeEventListener("online", goOnline);
    window.removeEventListener("offline", goOffline);
    window.removeEventListener("focus", onFocus);
  };
}
