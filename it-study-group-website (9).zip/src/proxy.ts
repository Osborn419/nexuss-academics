import { NextRequest, NextResponse } from "next/server";
import { pool } from "@/db";
import { SESSION_COOKIE } from "@/lib/cookies";

/**
 * Reject cross-origin browser mutations to cookie-authenticated API routes.
 * Browser fetch/form POST includes Origin; server-side/curl clients without
 * Origin remain possible for maintenance. Cookie SameSite=Lax is defence 2.
 */
function checkOrigin(request: NextRequest): NextResponse | null {
  if (!["POST", "PATCH", "PUT", "DELETE"].includes(request.method)) return null;
  const origin = request.headers.get("origin");
  if (!origin) return null;
  const forwarded = request.headers.get("x-forwarded-host")?.split(",")[0]?.trim();
  const host = forwarded || request.headers.get("host") || request.nextUrl.host;
  try {
    if (new URL(origin).host.toLowerCase() !== host.toLowerCase()) {
      return NextResponse.json({ error: "Cross-origin request rejected." }, { status: 403 });
    }
  } catch {
    return NextResponse.json({ error: "Invalid Origin header." }, { status: 403 });
  }
  return null;
}

type SessionState = "admin" | "student" | "none";

/** Verify the session in the database and return the account's role. Fails closed. */
async function sessionState(token: string | undefined): Promise<SessionState> {
  if (!token) return "none";
  try {
    const result = await pool.query(
      `select p.role from sessions s
       join profiles p on p.id = s.profile_id
       where s.token = $1 and s.expires_at > now()
       limit 1`,
      [token],
    );
    if (result.rows.length === 0) return "none";
    return result.rows[0].role === "admin" ? "admin" : "student";
  } catch (error) {
    console.error("Admin route session check failed", error);
    return "none";
  }
}

function redirectTo(request: NextRequest, pathname: string, search = ""): NextResponse {
  const url = request.nextUrl.clone();
  url.pathname = pathname;
  url.search = search;
  return NextResponse.redirect(url, 307);
}

export async function proxy(request: NextRequest) {
  const originBlocked = checkOrigin(request);
  if (originBlocked) return originBlocked;

  const { pathname } = request.nextUrl;

  // /admin/login is only a pass-through to /login; guard every other admin page.
  if (pathname.startsWith("/admin") && pathname !== "/admin/login") {
    const token = request.cookies.get(SESSION_COOKIE)?.value;
    const state = await sessionState(token);
    if (state === "none") {
      const response = redirectTo(
        request,
        "/login",
        `?next=${encodeURIComponent(pathname)}`,
      );
      response.cookies.delete(SESSION_COOKIE);
      return response;
    }
    if (state === "student") {
      return redirectTo(request, "/dashboard");
    }
  }

  return NextResponse.next();
}

export const config = { matcher: ["/api/:path*", "/admin/:path*"] };
