"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Bookmark, Loader2 } from "lucide-react";
import { postStudentAction } from "@/lib/offline-sync";

export function BookmarkButton({
  materialId,
  bookmarked: initial,
  compact = false,
}: {
  materialId: number;
  bookmarked?: boolean;
  compact?: boolean;
}) {
  const router = useRouter();
  const [bookmarked, setBookmarked] = useState(Boolean(initial));
  const [seenInitial, setSeenInitial] = useState(Boolean(initial));
  const [loading, setLoading] = useState(false);

  if (seenInitial !== Boolean(initial)) {
    setSeenInitial(Boolean(initial));
    setBookmarked(Boolean(initial));
  }

  useEffect(() => {
    const onSyncState = (event: Event) => {
      const detail = (event as CustomEvent<{ bookmarks?: number[] }>).detail;
      if (!detail || !Array.isArray(detail.bookmarks)) return;
      const serverValue = detail.bookmarks.includes(Number(materialId));
      setSeenInitial(serverValue);
      setBookmarked(serverValue);
    };
    window.addEventListener("nexus:sync-state", onSyncState);
    return () => window.removeEventListener("nexus:sync-state", onSyncState);
  }, [materialId]);
  const [hidden, setHidden] = useState(false);


  const toggle = async () => {
    setLoading(true);
    setHidden(false);
    const next = !bookmarked;
    // Apply the intent immediately; offline it is queued and replayed on reconnect.
    setBookmarked(next);
    try {
      const result = await postStudentAction("bookmark", { materialId });
      if (result.outcome === "auth") {
        router.push(`/login?next=${encodeURIComponent(`/materials/${materialId}`)}`);
        return;
      }
      if (result.outcome === "conflict") {
        // Another device was newer: keep the server state, never overwrite it.
        setBookmarked(Boolean(result.server.bookmarked));
        router.refresh();
        return;
      }
      if (result.outcome === "ok") setBookmarked(Boolean(result.data.bookmarked));
    } finally {
      setLoading(false);
    }
  };

  if (hidden) return null;

  return (
    <button
      type="button"
      onClick={() => void toggle()}
      disabled={loading}
      aria-pressed={bookmarked}
      title={bookmarked ? "Remove from saved resources" : "Save to your dashboard"}
      className={`inline-flex items-center gap-2 rounded-xl text-sm font-semibold ring-1 transition ${
        compact ? "p-2" : "px-4 py-2.5"
      } ${
        bookmarked
          ? "bg-amber-400/15 text-amber-200 ring-amber-400/40"
          : "bg-white/5 text-slate-200 ring-white/12 hover:bg-white/10"
      }`}
    >
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bookmark className={`h-4 w-4 ${bookmarked ? "fill-amber-400 text-amber-400" : ""}`} />}
      {compact ? null : bookmarked ? "Saved" : "Save"}
    </button>
  );
}
