"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  CheckCircle2,
  CloudUpload,
  Download,
  Loader2,
  RefreshCw,
  TriangleAlert,
  Wifi,
  WifiOff,
} from "lucide-react";
import {
  flushPending,
  initSyncRuntime,
  subscribeSync,
  type SyncStatus,
} from "@/lib/offline-sync";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

/**
 * Registers the service worker and shows the live offline / sync state.
 * Rendered once by the root layout.
 */
export function PwaStatus() {
  const router = useRouter();
  const lastConflicts = useRef(0);
  const [status, setStatus] = useState<SyncStatus>({
    online: true,
    pending: 0,
    syncing: false,
    conflicts: 0,
    failed: 0,
    needsAuth: false,
    lastSyncedAt: null,
    notice: null,
  });
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;

    // Service worker registration (production builds only; avoids dev HMR clashes).
    if (process.env.NODE_ENV === "production" && "serviceWorker" in navigator) {
      navigator.serviceWorker
        .register("/sw.js", { scope: "/" })
        .catch((error) => console.error("Service worker registration failed", error));
    }

    const unsubscribe = subscribeSync(setStatus);
    const stopRuntime = initSyncRuntime();

    const onInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallEvent(event as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onInstallPrompt);

    return () => {
      unsubscribe();
      stopRuntime();
      window.removeEventListener("beforeinstallprompt", onInstallPrompt);
    };
  }, []);

  // A conflict means the server kept a newer value. Fetch that truth, hand it
  // to any open toggle, then refresh the server-rendered page.
  useEffect(() => {
    if (status.conflicts <= lastConflicts.current) return;
    lastConflicts.current = status.conflicts;
    let cancelled = false;
    (async () => {
      try {
        const response = await fetch("/api/me");
        if (response.ok) {
          const state = await response.json();
          window.dispatchEvent(new CustomEvent("nexus:sync-state", { detail: state }));
        }
      } catch {
        // router.refresh() below still pulls whatever the server can render.
      }
      if (!cancelled) router.refresh();
    })();
    return () => {
      cancelled = true;
    };
  }, [status.conflicts, router]);

  const install = async () => {
    if (!installEvent) return;
    await installEvent.prompt();
    await installEvent.userChoice;
    setInstallEvent(null);
  };

  const online = status.online;
  const pending = status.pending;
  const syncing = status.syncing;

  return (
    <>
      <div
        aria-live="polite"
        className={`fixed bottom-4 right-4 z-50 flex max-w-[min(22rem,calc(100vw-2rem))] flex-col items-end gap-2 text-right ${
          status.notice || installEvent ? "" : "pointer-events-none"
        }`}
      >
        {installEvent ? (
          <button
            type="button"
            onClick={() => void install()}
            className="pointer-events-auto inline-flex items-center gap-2 rounded-xl border border-sky-400/30 bg-sky-400/15 px-3.5 py-2 text-xs font-semibold text-sky-200 shadow-lg shadow-black/40 backdrop-blur transition hover:bg-sky-400/25"
          >
            <Download className="h-4 w-4" /> Install Nexus Academics
          </button>
        ) : null}

        {status.notice ? (
          <span className="pointer-events-auto inline-flex max-w-full items-start gap-2 rounded-xl border border-white/15 bg-slate-950/85 px-3.5 py-2 text-left text-xs text-slate-200 shadow-lg shadow-black/50 backdrop-blur">
            {status.conflicts > 0 ? (
              <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
            ) : status.needsAuth ? (
              <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
            ) : online ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
            ) : (
              <CloudUpload className="mt-0.5 h-4 w-4 shrink-0 text-sky-400" />
            )}
            <span className="break-words">{status.notice}</span>
          </span>
        ) : null}

        <span
          className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider shadow-lg shadow-black/40 ring-1 backdrop-blur ${
            !online
              ? "bg-amber-500/20 text-amber-200 ring-amber-400/40"
              : pending > 0
                ? "bg-sky-500/20 text-sky-200 ring-sky-400/40"
                : "bg-emerald-500/15 text-emerald-200 ring-emerald-400/35"
          }`}
          title={
            online
              ? "Connected — changes are being stored online"
              : "No internet connection — your changes are stored on this device"
          }
        >
          {!online ? (
            <WifiOff className="h-3.5 w-3.5" />
          ) : syncing ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : pending > 0 ? (
            <CloudUpload className="h-3.5 w-3.5" />
          ) : status.lastSyncedAt ? (
            <CheckCircle2 className="h-3.5 w-3.5" />
          ) : (
            <Wifi className="h-3.5 w-3.5" />
          )}
          {!online
            ? `Offline${pending > 0 ? ` · ${pending} queued` : ""}`
            : syncing
              ? "Syncing…"
              : pending > 0
                ? `${pending} to sync`
                : status.lastSyncedAt
                  ? "Online · synced"
                  : "Online"}
        </span>
      </div>

      {/* Keyboard-accessible retry used by tests and by anyone whose sync stalled. */}
      <button
        type="button"
        hidden={!status.failed}
        onClick={() => void flushPending()}
        className="hidden"
      >
        Retry sync
      </button>
    </>
  );
}
