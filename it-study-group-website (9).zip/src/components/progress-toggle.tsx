"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Circle, Loader2 } from "lucide-react";
import { postStudentAction } from "@/lib/offline-sync";

export function ProgressToggle({
  courseId,
  week,
  completed,
  label,
}: {
  courseId: number;
  week: number;
  completed: boolean;
  label?: string;
}) {
  const router = useRouter();
  const [done, setDone] = useState(completed);
  const [seenCompleted, setSeenCompleted] = useState(completed);
  const [loading, setLoading] = useState(false);

  // Adopt the newest server value after a refresh (e.g. a conflict was resolved).
  if (seenCompleted !== completed) {
    setSeenCompleted(completed);
    setDone(completed);
  }

  // After a sync conflict the newest online state is broadcast here so an open
  // toggle flips back to server truth instead of keeping the offline intent.
  useEffect(() => {
    const onSyncState = (event: Event) => {
      const detail = (event as CustomEvent<{ progress?: string[] }>).detail;
      if (!detail || !Array.isArray(detail.progress)) return;
      const serverValue = detail.progress.includes(`${courseId}:${week}`);
      setSeenCompleted(serverValue);
      setDone(serverValue);
    };
    window.addEventListener("nexus:sync-state", onSyncState);
    return () => window.removeEventListener("nexus:sync-state", onSyncState);
  }, [courseId, week]);

  const toggle = async () => {
    setLoading(true);
    const next = !done;
    setDone(next); // optimistic; offline changes are queued, conflicts resolve to server state
    try {
      const result = await postStudentAction("progress", { courseId, week });
      if (result.outcome === "auth") {
        router.push("/login");
        return;
      }
      if (result.outcome === "conflict") {
        setDone(Boolean(result.server.completed));
        router.refresh();
        return;
      }
      if (result.outcome === "ok") {
        setDone(Boolean(result.data.completed));
        router.refresh();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      type="button"
      onClick={() => void toggle()}
      disabled={loading}
      aria-pressed={done}
      className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-medium ring-1 transition ${
        done
          ? "bg-emerald-400/15 text-emerald-200 ring-emerald-400/40"
          : "bg-white/5 text-slate-400 ring-white/10 hover:bg-white/10 hover:text-slate-200"
      }`}
    >
      {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : done ? <Check className="h-3.5 w-3.5" /> : <Circle className="h-3.5 w-3.5" />}
      {label ?? (done ? "Completed" : "Mark done")}
    </button>
  );
}
