"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Pencil, Save } from "lucide-react";

export function CourseEditor({ course }: { course: {
  id: number; code: string; title: string; summary: string; description: string;
  track: string; credits: number; level: number; accent: string;
} }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState(course.title);
  const [summary, setSummary] = useState(course.summary);
  const [description, setDescription] = useState(course.description);
  const [track, setTrack] = useState(course.track);
  const [credits, setCredits] = useState(course.credits);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setSaved(false);
    try {
      const response = await fetch("/api/admin/courses", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: course.id, code: course.code, title, summary, description, track, credits, level: course.level, accent: course.accent }),
      });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Could not update course.");
      setSaved(true); router.refresh();
    } catch (error) { setError(error instanceof Error ? error.message : "Could not update course."); }
    finally { setBusy(false); }
  }
  const input = "w-full rounded-lg border border-white/15 bg-canvas/80 px-3 py-2 text-sm text-white outline-none focus:border-sky-400/60";
  return <div className="w-full">
    <button type="button" onClick={() => setOpen((value) => !value)} aria-expanded={open} className="inline-flex items-center gap-1 rounded-lg bg-sky-400/10 px-3 py-1.5 text-xs text-sky-300 ring-1 ring-sky-400/25 hover:bg-sky-400/20"><Pencil className="h-3.5 w-3.5" /> {open ? "Close edit" : "Edit"}</button>
    {open && <form onSubmit={(event) => void save(event)} className="mt-3 space-y-2 rounded-xl border border-white/10 bg-canvas p-3">
      <p className="font-mono text-xs text-sky-300">{course.code} · code stays fixed</p>
      <label className="block text-xs text-slate-400">Title<input className={input} value={title} onChange={(event) => setTitle(event.target.value)} required /></label>
      <label className="block text-xs text-slate-400">Summary<textarea className={input} value={summary} onChange={(event) => setSummary(event.target.value)} rows={2} /></label>
      <label className="block text-xs text-slate-400">Description<textarea className={input} value={description} onChange={(event) => setDescription(event.target.value)} rows={4} /></label>
      <div className="flex flex-wrap gap-2"><label className="block flex-1 text-xs text-slate-400">Track<select className={input} value={track} onChange={(event) => setTrack(event.target.value)}><option value="core">Core</option><option value="elective">Elective</option></select></label>
      <label className="block w-20 text-xs text-slate-400">Credits<input type="number" min="1" max="12" className={input} value={credits} onChange={(event) => setCredits(Number(event.target.value))} /></label></div>
      {error && <p role="alert" className="text-xs text-rose-300">{error}</p>}{saved && <p role="status" className="text-xs text-emerald-300">Updated.</p>}
      <button type="submit" disabled={busy} className="inline-flex items-center gap-1 rounded-lg bg-sky-400/15 px-3 py-2 text-xs text-sky-200 ring-1 ring-sky-400/30 disabled:opacity-50">{busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Save course</button>
    </form>}
  </div>;
}
