"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Pencil, Save } from "lucide-react";

export function MaterialEditor({ material }: { material: {
  id: number; title: string; description: string; url: string | null; content: string | null;
  kind: string; week: number | null; published: boolean;
} }) {
  const router = useRouter();
  const [title, setTitle] = useState(material.title);
  const [description, setDescription] = useState(material.description);
  const [url, setUrl] = useState(material.url ?? "");
  const [content, setContent] = useState(material.content ?? "");
  const [week, setWeek] = useState(String(material.week ?? ""));
  const [published, setPublished] = useState(material.published);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError(""); setSaved(false);
    try {
      const response = await fetch("/api/admin/materials", {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: material.id, title, description, url, content, week: week || null, published }),
      });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "Could not save resource.");
      setSaved(true);
      router.refresh();
    } catch (error) { setError(error instanceof Error ? error.message : "Could not save resource."); }
    finally { setBusy(false); }
  }

  const inputClass = "w-full rounded-lg border border-white/15 bg-canvas/80 px-3 py-2 text-sm text-white outline-none focus:border-sky-400/60";
  return (
    <div className="mb-1">
      <button type="button" onClick={() => setOpen((value) => !value)} aria-expanded={open} className="inline-flex items-center gap-1 rounded-lg bg-sky-400/10 px-3 py-1.5 text-xs text-sky-300 ring-1 ring-sky-400/25 hover:bg-sky-400/20">
        <Pencil className="h-3.5 w-3.5" /> {open ? "Close" : "Edit"}
      </button>
      {!material.published && <span className="ml-2 text-[11px] font-semibold text-amber-300">DRAFT</span>}
      {open && <form onSubmit={(event) => void save(event)} className="mt-2 min-w-[15rem] space-y-2 rounded-xl border border-white/10 bg-canvas p-3">
        <label className="block text-xs text-slate-400">Title<input value={title} onChange={(event) => setTitle(event.target.value)} className={inputClass} required /></label>
        <label className="block text-xs text-slate-400">Description<textarea value={description} onChange={(event) => setDescription(event.target.value)} className={inputClass} rows={2} /></label>
        <label className="block text-xs text-slate-400">Week<input type="number" min="1" max="30" value={week} onChange={(event) => setWeek(event.target.value)} className={inputClass} placeholder="No week" /></label>
        <label className="block text-xs text-slate-400">External URL<input type="url" value={url} onChange={(event) => setUrl(event.target.value)} className={inputClass} placeholder="https://" /></label>
        {material.content !== null && <label className="block text-xs text-slate-400">Markdown<textarea value={content} onChange={(event) => setContent(event.target.value)} className={`${inputClass} font-mono`} rows={5} /></label>}
        <label className="flex items-center gap-2 text-xs text-slate-300"><input type="checkbox" checked={published} onChange={(event) => setPublished(event.target.checked)} /> Published publicly</label>
        {error && <p role="alert" className="text-xs text-rose-300">{error}</p>}
        {saved && <p role="status" className="text-xs text-emerald-300">Saved.</p>}
        <button type="submit" disabled={busy} className="inline-flex items-center gap-1.5 rounded-lg bg-sky-400/15 px-3 py-2 text-xs font-medium text-sky-200 ring-1 ring-sky-400/30 disabled:opacity-50">
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Save changes
        </button>
      </form>}
    </div>
  );
}
