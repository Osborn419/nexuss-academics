"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Loader2 } from "lucide-react";

export function QuizPublishButton({ id, published }: { id: number; published: boolean }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function toggle() {
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/admin/quizzes", {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, published: !published }),
      });
      if (!response.ok) throw new Error("Could not update this assessment.");
      router.refresh();
    } catch (error) { setError(error instanceof Error ? error.message : "Could not update."); }
    finally { setBusy(false); }
  }
  return <span className="inline-flex flex-col items-start gap-1">
    <button type="button" disabled={busy} onClick={() => void toggle()} className="inline-flex items-center gap-1.5 rounded-lg bg-sky-400/10 px-3 py-1.5 text-xs font-medium text-sky-300 ring-1 ring-sky-400/25 hover:bg-sky-400/20 disabled:opacity-50">
      {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : published ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
      {published ? "Unpublish" : "Publish"}
    </button>{error && <span role="alert" className="text-xs text-rose-300">{error}</span>}
  </span>;
}
